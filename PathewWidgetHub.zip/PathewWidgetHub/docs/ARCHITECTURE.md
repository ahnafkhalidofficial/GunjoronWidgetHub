# আর্কিটেকচার

## মূল ধারণা: একই কোডে উইজেট ও প্রিভিউ
উইজেটের ছবি আঁকে `widget/WidgetRenderer.draw(...)`। হোম-স্ক্রিন উইজেট (বিটম্যাপ) আর হাবের লাইভ প্রিভিউ (`hub/ui/PreviewView`) — দুটোতেই একই কোড চলে, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু এক।
- `live = false` (হোম স্ক্রিন): ঘণ্টা:মিনিট বিটম্যাপে আঁকা; সেকেন্ড ও কাউন্টডাউনের জায়গা ফাঁকা রেখে `Overlay` ফেরত দেয় — ওখানে লঞ্চারের `TextClock`/`Chronometer` বসে (ব্যাটারি খরচ নেই)।
- `live = true` (প্রিভিউ): সবকিছু সরাসরি আঁকা।

## ডেটার পথ
```
Prefs (সেটিং) ─┐
PrayerCalc ────┼─► Snapshot.build()  ─►  WidgetRenderer.draw()  ─►  ClassicDesign / … / DialDesign
Calendars/Bn ──┤        (এক মুহূর্তের তথ্য)         │
RemoteConfig ──┘                                    └─► Overlay (লাইভ অংশের রঙ/জায়গা)
```
- `data/Snapshot.kt` — বর্তমান ওয়াক্ত, বাকি সময়, তারিখ (ইংরেজি/হিজরি/বাংলা), নিষিদ্ধ সময় (`forbid`), পরের রিফ্রেশের সময়। UI-মুক্ত, কোনো ডিজাইন সম্পর্কে জানে না।
- `widget/WidgetUpdater.kt` — Snapshot + Look থেকে ছবি বানায়, লেআউট বাছে, RemoteViews পাঠায়, পরের আপডেটের অ্যালার্ম বসায়।
- `widget/PrayerWidgetProvider.kt` — সিস্টেম ইভেন্ট (টিক, আনলক, তারিখ/সময় বদল) ধরে `WidgetUpdater`-কে ডাকে।

## widget/ ভেতরে
| ফোল্ডার | কাজ |
|---|---|
| `designs/` | প্রতি ডিজাইনের আঁকার কোড, একটা ফাইলে একটা ডিজাইন (`internal object XxxDesign { fun draw(...) }`) |
| `render/DrawKit.kt` | সব ডিজাইনের শেয়ার করা ছোট সরঞ্জাম: `text`, `measure`, `fit`, `tile`, `barK`, `medal`, `logoRing`, `remLine`, `slimClock` ইত্যাদি |
| `render/Overlay.kt` | `Overlay`/`TextSpec` — লাইভ অংশের জায়গা/রঙ |
| `theme/` | `Look` (কোন ডিজাইন + কোন থিম), `Palettes` (রঙের তালিকা), `Variant` (গ্লাস/লাইট/ট্রান্সপারেন্ট) |
| `assets/` | `Art` (webp আর্ট ছবি লোড), `Fonts` (ফন্ট লোড) |

`WidgetRenderer` নিজে শুধু কার্ডের মাপ (`cardW/cardH`), কার্ডের ব্যাকগ্রাউন্ড (গ্লাস/প্যানেল) আর কোন ডিজাইন ডাকা হবে সেটা ঠিক করে।

## ডিজাইন ও ফাইলের মিল
| ডিজাইন | ফাইল |
|---|---|
| ১ ক্লাসিক, ২ এসেনশিয়াল | `designs/ClassicDesign.kt` |
| ৩ ত্রি-ক্যালেন্ডার | `designs/TripleCalendarDesign.kt` |
| ৪ মিনিমাল | `designs/MinimalDesign.kt` |
| ৫ ড্যাশবোর্ড | `designs/DashboardDesign.kt` |
| ৬ সান-আর্ক (+ আনলক-অ্যানিমেশন ফ্রেম) | `designs/SunArcDesign.kt` |
| ৭ এডিটোরিয়াল | `designs/EditorialDesign.kt` |
| ৮ স্ট্যাক | `designs/StackDesign.kt` |
| ৯ ডায়াল | `designs/DialDesign.kt` |

## নতুন ডিজাইন যোগ করা (ধাপে ধাপে)
1. `widget/designs/` এ নতুন `XxxDesign.kt` (একটা `internal object` + `fun draw(...)`) — অন্যটা দেখে নিন।
2. `WidgetRenderer.kt`: `cardW/cardH/cardRx` এ মাপ, `draw()`-এর ডিসপ্যাচে নতুন ডিজাইন।
3. `tools/genlayout.py`: `CARD`, (লাইভ অংশ থাকলে) `OV`/`REM`/`FMT`, ভার্শন বাড়ান (`wv…`) → `python3 tools/genlayout.py`।
4. `WidgetUpdater.kt`: `LAYOUT_W/LAYOUT_H` এ নতুন লেআউট; `res/xml/widget_info.xml` এর `initialLayout`/`README` এর ভার্শন মিলান।
5. `data/Prefs.kt` এ ডিজাইন সংখ্যার সীমা, `hub/HubScreen.kt` এ `designTitles`।

## হাব (hub/)
`HubScreen.kt` পুরো স্ক্রিন বানায় (প্রিভিউ → থিম → ডিজাইন কার্ড → তারিখ সেটিং → বাটন)। ছোট UI অংশগুলো `hub/ui/` এ।

## ডেটা (data/)
`prayer/` নামাজের সময় (করাচি ১৮°/১৮°, হানাফি আসর, অফলাইন) · `calendar/` বাংলা সংখ্যা ও তারিখ · `remote/` ফায়ারবেজ ও লোকেশন।
