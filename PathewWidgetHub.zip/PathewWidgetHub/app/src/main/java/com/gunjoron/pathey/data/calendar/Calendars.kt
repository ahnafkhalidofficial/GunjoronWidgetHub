package com.gunjoron.pathey.data.calendar

import java.time.LocalDate
import java.time.chrono.HijrahDate

/** তারিখ রূপান্তর: বাংলা (সংশোধিত, বাংলাদেশ) ও হিজরি। */
object Calendars {
    class BnDate(val day: Int, val month: Int, val year: Int)

    private fun isLeap(y: Int) = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0

    fun bangla(d: LocalDate): BnDate {
        val y = d.year
        val newYear = LocalDate.of(y, 4, 14)
        val bnYear: Int
        val start: LocalDate
        if (!d.isBefore(newYear)) {
            bnYear = y - 593
            start = newYear
        } else {
            bnYear = y - 594
            start = LocalDate.of(y - 1, 4, 14)
        }
        // সংশোধিত পঞ্জিকায় ফাল্গুন লিপ-ইয়ারে ৩০ দিন (পরের ইংরেজি বছর লিপ হলে)
        val nextGregYear = start.year + 1
        val lens = intArrayOf(31, 31, 31, 31, 31, 30, 30, 30, 30, 30, if (isLeap(nextGregYear)) 30 else 29, 30)
        var rem = (d.toEpochDay() - start.toEpochDay()).toInt()
        var m = 0
        while (m < 11 && rem >= lens[m]) { rem -= lens[m]; m++ }
        return BnDate(rem + 1, m, bnYear)
    }

    class HjDate(val day: Int, val month: Int, val year: Int)

    /** adjust: বাংলাদেশে সাধারণত সৌদির চেয়ে ১ দিন পিছিয়ে — তাই ডিফল্ট −১ (সেটিংসে বদলানো যায়)। */
    fun hijri(d: LocalDate, adjust: Int): HjDate {
        val h = HijrahDate.from(d.plusDays(adjust.toLong()))
        return HjDate(h.get(java.time.temporal.ChronoField.DAY_OF_MONTH),
            h.get(java.time.temporal.ChronoField.MONTH_OF_YEAR) - 1,
            h.get(java.time.temporal.ChronoField.YEAR))
    }
}
