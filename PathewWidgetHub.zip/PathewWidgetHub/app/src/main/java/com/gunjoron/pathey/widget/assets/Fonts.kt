package com.gunjoron.pathey.widget.assets

import android.content.Context
import android.graphics.Typeface
import com.gunjoron.pathey.R

/** ফন্ট একবারই লোড হয় (static TTF — ভেরিয়েবল ফন্ট নয়, তাই পুরনো ফোনেও উইজেট ভাঙে না)। */
object Fonts {
    @Volatile private var ready = false
    lateinit var regular: Typeface; private set   // গুঞ্জরণ রেগুলার
    lateinit var bold: Typeface; private set      // গুঞ্জরণ বোল্ড
    lateinit var bebas: Typeface; private set     // ডিজিটাল সংখ্যা
    lateinit var clockBold: Typeface; private set // ডিজাইন ৩-এর বড় ঘড়ি (EB Garamond Bold)
    lateinit var clockReg: Typeface; private set  // AM/PM ও সেকেন্ড (EB Garamond Regular)
    lateinit var outfit: Typeface; private set    // ডিজাইন ৪/৫-এর পাতলা আধুনিক ঘড়ি (Outfit Light)
    lateinit var ui: Typeface; private set        // হাব অ্যাপের UI ফন্ট (গুঞ্জরণ ব্র্যান্ড ফন্ট — Normal)
    lateinit var uiBold: Typeface; private set    // হাব অ্যাপের UI ফন্ট (গুঞ্জরণ ব্র্যান্ড ফন্ট — Bold)

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val r = ctx.applicationContext.resources
            regular = r.getFont(R.font.gunjoron_regular)
            bold = r.getFont(R.font.gunjoron_bold)
            bebas = r.getFont(R.font.bebas_neue)
            clockBold = r.getFont(R.font.ebgaramond_bold)
            clockReg = r.getFont(R.font.ebgaramond_regular)
            outfit = r.getFont(R.font.outfit_light)
            ui = r.getFont(R.font.gunjoron_font_normal)
            uiBold = r.getFont(R.font.gunjoron_font_bold)
            ready = true
        }
    }
}
