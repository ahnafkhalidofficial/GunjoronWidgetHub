package com.gunjoron.pathey.widget.theme

import android.graphics.Color
import com.gunjoron.pathey.data.Prefs

/**
 * কোন ডিজাইন, কোন ভেরিয়েন্ট, আর কাস্টম থিমে পেছনের রঙিন প্যানেল (ARGB; ০ = নেই)।
 * হাবের wdVariantKey() ও wdBgStyle()-এর সমতুল্য।
 */
class Look(val design: Int, val variant: Variant, val panelColor: Int) {
    companion object {
        fun from(p: Prefs, design: Int = p.design, theme: String = p.theme): Look {
            return when (theme) {
                "light" -> Look(design, Variant.LIGHT, 0)
                "nobg" -> Look(design, if (p.nobgMode == "light") Variant.NOBG_LIGHT else Variant.NOBG_DARK, 0)
                "custom" -> {
                    val a = (p.customOpacity * 255 / 100).coerceIn(0, 255)
                    val c = p.customBg
                    Look(design, if (p.customIsLightTone()) Variant.NOBG_LIGHT else Variant.NOBG_DARK,
                        Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)))
                }
                else -> Look(design, Variant.GLASS, 0)
            }
        }
    }
}
