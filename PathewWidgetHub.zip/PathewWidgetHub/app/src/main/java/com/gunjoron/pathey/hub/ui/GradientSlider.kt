package com.gunjoron.pathey.hub.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** গ্রেডিয়েন্ট ট্র্যাকের স্লাইডার (উজ্জ্বলতা / স্বচ্ছতা)। */
class GradientSlider(ctx: Context, private val min: Int, private val max: Int) : View(ctx) {
    var value = min
        set(v) { field = v.coerceIn(min, max); invalidate() }
    var colorStart = Color.BLACK
        set(v) { field = v; invalidate() }
    var colorEnd = Color.WHITE
        set(v) { field = v; invalidate() }
    var borderColor = 0xFF263349.toInt()
    var thumbBorder = 0xFF3B82F6.toInt()
    var onChange: ((Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (28 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val pad = 12f * d
        val l = pad; val r = width - pad; val cy = height / 2f; val th = 5f * d
        track.shader = LinearGradient(l, 0f, r, 0f, colorStart, colorEnd, Shader.TileMode.CLAMP)
        val rect = RectF(l, cy - th, r, cy + th)
        c.drawRoundRect(rect, th, th, track)
        border.strokeWidth = d; border.color = borderColor
        c.drawRoundRect(rect, th, th, border)
        val x = l + (r - l) * (value - min) / (max - min).toFloat()
        thumb.color = Color.WHITE
        c.drawCircle(x, cy, 10f * d, thumb)
        thumbRing.strokeWidth = 2f * d; thumbRing.color = thumbBorder
        c.drawCircle(x, cy, 9f * d, thumbRing)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = 12f * d
                val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
                val nv = (min + f * (max - min)).toInt()
                if (nv != value) { value = nv; onChange?.invoke(nv) }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); return true }
        }
        return super.onTouchEvent(e)
    }
}
