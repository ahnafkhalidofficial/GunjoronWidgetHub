package com.gunjoron.pathey.hub.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.render.*

/** হাবের ডার্ক/লাইট রঙের টোকেন — HTML-এর CSS ভেরিয়েবলের (--h-*) হুবহু অনুবাদ। */
class Tok(val dark: Boolean) {
    val bg = if (dark) 0xFF040C21.toInt() else 0xFFF2F5FA.toInt()
    val ink = if (dark) 0xFFEDF3FF.toInt() else 0xFF0A1C46.toInt()
    val mut = if (dark) 0xFF8497BC.toInt() else 0xFF6B7C9C.toInt()
    val line = if (dark) 0xFF15275A.toInt() else 0xFFE2E9F3.toInt()
    val seg = if (dark) 0xFF0A1838.toInt() else 0xFFE6ECF5.toInt()
    val card = if (dark) 0xFF0A1838.toInt() else 0xFFFFFFFF.toInt()
    val segBg = if (dark) 0xFF040C21.toInt() else 0xFFE6ECF5.toInt()
    val segBd = if (dark) 0xFF15275A.toInt() else 0xFFD6E1F0.toInt()
    val segC = if (dark) 0xFF8497BC.toInt() else 0xFF5B6E94.toInt()
    val inBg = if (dark) 0xFF07122B.toInt() else 0xFFF3F7FC.toInt()
    val inBd = if (dark) 0xFF15275A.toInt() else 0xFFE2E9F3.toInt()
    val inHv = if (dark) 0xFF27427F.toInt() else 0xFFC3D2E8.toInt()
    val ghostC = if (dark) 0xFFC5D3F0.toInt() else 0xFF0A1C46.toInt()
    val ghostBd = if (dark) 0xFF1C3370.toInt() else 0xFFD6E1F0.toInt()
    val acc = if (dark) 0xFF4DB5F5.toInt() else 0xFF046CA9.toInt()
    val subActC = if (dark) 0xFFFFFFFF.toInt() else 0xFF046CA9.toInt()
    val subActBg = if (dark) 0x401D4ED8 else 0x1A046CA9
    val subActBd = if (dark) 0xFF4DB5F5.toInt() else 0xFF2F9BE0.toInt()
    val live = if (dark) 0xFF34D399.toInt() else 0xFF0B8F55.toInt()
    val liveBg = if (dark) 0x1A34D399 else 0x1A0B8F55
    val liveBd = if (dark) 0x4734D399 else 0x4D0B8F55
    val dash = if (dark) 0xFF1C3370.toInt() else 0xFFD6E1F0.toInt()
    val ring = if (dark) 0xFF15275A.toInt() else 0xFFE2E9F3.toInt()
    val chipRing = if (dark) 0xFF27427F.toInt() else 0xFFC3D2E8.toInt()
    val hexBg = if (dark) 0xFF040C21.toInt() else 0xFFFFFFFF.toInt()
    val navy = 0xFF02205C.toInt()
}

object Ui {
    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    fun dpf(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    fun shape(ctx: Context, fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Float = 0f): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(fill)
        g.cornerRadius = dpf(ctx, radiusDp)
        if (strokeColor != 0 && strokeDp > 0f) g.setStroke(maxOf(1, dp(ctx, strokeDp)), strokeColor)
        return g
    }

    fun gradient(ctx: Context, colors: IntArray, radiusDp: Float, strokeColor: Int = 0, strokeDp: Float = 0f,
                 orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR): GradientDrawable {
        val g = GradientDrawable(orientation, colors)
        g.cornerRadius = dpf(ctx, radiusDp)
        if (strokeColor != 0 && strokeDp > 0f) g.setStroke(maxOf(1, dp(ctx, strokeDp)), strokeColor)
        return g
    }

    fun text(ctx: Context, s: CharSequence, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(color)
        t.typeface = if (bold) Fonts.uiBold else Fonts.ui
        t.includeFontPadding = false
        return t
    }

    fun icon(ctx: Context, res: Int, tint: Int, sizeDp: Float): ImageView {
        val i = ImageView(ctx)
        i.setImageResource(res)
        i.setColorFilter(tint)
        i.layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        return i
    }

    fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    fun lpw(ctx: Context, wDp: Float, hDp: Float) = LinearLayout.LayoutParams(dp(ctx, wDp), dp(ctx, hDp))
    fun hStack(ctx: Context): LinearLayout = LinearLayout(ctx).also { it.orientation = LinearLayout.HORIZONTAL; it.gravity = Gravity.CENTER_VERTICAL }
    fun vStack(ctx: Context): LinearLayout = LinearLayout(ctx).also { it.orientation = LinearLayout.VERTICAL }

    fun margin(v: View, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) {
        val p = v.layoutParams as ViewGroup.MarginLayoutParams
        p.setMargins(l, t, r, b)
        v.layoutParams = p
    }

    fun frame(ctx: Context) = FrameLayout(ctx)
    fun transparent() = Color.TRANSPARENT
}
