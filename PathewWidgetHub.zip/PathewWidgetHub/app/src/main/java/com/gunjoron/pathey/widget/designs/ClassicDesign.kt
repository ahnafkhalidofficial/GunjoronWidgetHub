package com.gunjoron.pathey.widget.designs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.data.calendar.Bn
import com.gunjoron.pathey.widget.assets.Art
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.render.*
import com.gunjoron.pathey.widget.theme.Look
import com.gunjoron.pathey.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ১ (ক্লাসিক) ও ডিজাইন ২ (এসেনশিয়াল): ডিজাইন-শিটের আর্ট (webp) + তার ওপর গতিশীল লেখা। দুটোর কোড একই, ডিজাইন ২-এ নিচের অংশ ১৬০ ইউনিট ওপরে। */
internal object ClassicDesign {
    // ডিজাইন ১/২: ৫ ওয়াক্তের কলামের কেন্দ্র (ফজর, যোহর, আসর, মাগরিব, ইশা)
    private val COL_CX = floatArrayOf(137.35f, 342.5f, 542.72f, 771.11f, 984.43f)

    private const val HL_W = 185.78f

    private const val HL_H = 145.83f

    private const val HL_RX = 21.19f

    private const val HL_NAME_DY = -5.82f

    private const val HL_TIME_DY = -6.21f

    // ------------------------------------------------------------------------------------------
    /** সূর্যোদয় ও ইফতার (সূর্যাস্ত) পিল সামান্য ডানে — আর্টের ওই দুই টুকরো আলাদা সরিয়ে আঁকা। */
    private const val PILL_SHIFT = 14f

    private val SUNRISE_R = Rect(820, 25, 1072, 175)

    private val IFTAR_R = Rect(806, 222, 1060, 358)

    private val LOGO2_R = Rect(26, 16, 208, 198)   // ডিজাইন ২-এর আর্টে বসানো নীল চৌকো লোগো (এটা বাদ দিয়ে নতুন লোগো আঁকা হয়)

    private val D1_TILES = arrayOf(floatArrayOf(63f, 222f, 191f, 350f), floatArrayOf(204f, 222f, 332f, 350f), floatArrayOf(344f, 281f, 412f, 349f))

    fun drawArt(c: Canvas, p: Paint, art: Bitmap, d: Int, cw: Float, chh: Float, softTiles: Boolean = false) {
        c.save()
        c.clipOutRect(SUNRISE_R.left.toFloat(), SUNRISE_R.top.toFloat(), SUNRISE_R.right.toFloat(), SUNRISE_R.bottom.toFloat())
        c.clipOutRect(LOGO2_R.left.toFloat(), LOGO2_R.top.toFloat(), LOGO2_R.right.toFloat(), LOGO2_R.bottom.toFloat())
        if (d == 1) c.clipOutRect(IFTAR_R.left.toFloat(), IFTAR_R.top.toFloat(), IFTAR_R.right.toFloat(), IFTAR_R.bottom.toFloat())
        if (softTiles) for (t in D1_TILES) c.clipOutRect(t[0] - 2f, t[1] - 2f, t[2] + 2f, t[3] + 2f)
        c.drawBitmap(art, null, RectF(0f, 0f, cw, chh), p)
        c.restore()
        if (softTiles) {   // হালকা মোডে ঘড়ির টাইল গাঢ় নীলের বদলে নরম হালকা নীল — চোখে লাগে না
            p.style = Paint.Style.FILL; p.shader = null; p.color = 0x24244866   // কার্ডের রঙের ওপর খুব হালকা নীলচে ছায়া — শুধু বোঝা যায় শেপ আছে
            for (t in D1_TILES) c.drawRoundRect(t[0] - 0.5f, t[1] - 0.5f, t[2] + 0.5f, t[3] + 0.5f, 22f, 22f, p)
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
        }
        fun piece(r: Rect) = c.drawBitmap(art, r, RectF(r.left + PILL_SHIFT, r.top.toFloat(), r.right + PILL_SHIFT, r.bottom.toFloat()), p)
        piece(SUNRISE_R)
        if (d == 1) piece(IFTAR_R)
    }

    // ------------------------------------------------------------------------------------------
    fun draw(ctx: Context, c: Canvas, p: Paint, d: Int, look: Look, snap: Snapshot, live: Boolean,
                        nowMs: Long, ov: Overlay) {
        val pal = Palettes.of12(d, look.variant)
        val yOff = if (d == 1) 0f else -160f   // নিচের অংশ ডিজাইন ২-এ ১৬০ ইউনিট উপরে

        // ---- হিজরি দিন (বড়) + হিজরি মাস-সাল
        val dayX = 216.32f
        // ইংরেজি-আগে ট্রগল চালু থাকলে বড় অংশে ইংরেজি তারিখ, নিচের লাইনে হিজরি (আগের ইংরেজির জায়গায়)
        val bigDay = if (snap.gregFirst) snap.gregDay else snap.hijriDay
        val bigMonth = if (snap.gregFirst) snap.gregMonth + " " + snap.gregYear else snap.hijriMonthYear
        text(c, p, bigDay, dayX, 103.57f, 110f, pal.day, Fonts.bold)
        val dayAdv = measure(p, bigDay, Fonts.bold, 110f)
        val hx = dayX + dayAdv + 10.53f
        var hs = 55f
        val hw = measure(p, bigMonth, Fonts.bold, hs)
        val hAvail = 825f - hx
        if (hw > hAvail) hs = 55f * hAvail / hw
        text(c, p, bigMonth, hx, 102.29f, hs, pal.hijri, Fonts.bold)

        // ---- ইংরেজি তারিখ | বাংলা তারিখ (মাঝে ডিভাইডার)
        var ds = 52f
        val g1 = if (snap.gregFirst) snap.hijriLine else snap.gregorianLine; val g2 = snap.banglaLine
        var w1 = measure(p, g1, Fonts.bold, ds); var w2 = measure(p, g2, Fonts.bold, ds)
        val total = w1 + DATE_SEP + w2
        val maxW = 612f
        val f = if (total > maxW) maxW / total else 1f
        if (f < 1f) { ds *= f; w1 *= f; w2 *= f }
        text(c, p, g1, dayX, 162.99f, ds, pal.date, Fonts.bold)
        // দাগ = লেখার রঙ, একটু ফিকে; দুই পাশে ফাঁক যাতে আলাদা বোঝা যায়
        p.style = Paint.Style.FILL; p.color = (pal.date and 0xFFFFFF) or 0xBF000000.toInt()
        val dvx = dayX + w1 + (DATE_SEP - 2.2f) / 2f * f
        c.drawRect(dvx, 123.4f, dvx + 2.2f * f, 123.4f + 45.19f, p)
        text(c, p, g2, dayX + w1 + DATE_SEP * f, 162.99f, ds, pal.date, Fonts.bold)

        // ---- সূর্যোদয় পিল
        text(c, p, snap.sunLabel, 1006.18f + PILL_SHIFT, 89.51f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.sunTime, 1005.07f + PILL_SHIFT, 146.66f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

        // ---- ডিজাইন ১/২: নতুন লোগো — গোল-কোণার চৌকো (স্কুইরকল) আকারে, ভেতরে আমাদের লোগোর পাথ
        run {
            val lightLogo = lum(pal.date) > 150f
            val ink = pal.date
            val lx = 116f; val ly = 107f; val half = 79f; val rr = 46f
            p.shader = null
            p.style = Paint.Style.FILL; p.color = (ink and 0xFFFFFF) or 0x14000000
            c.drawRoundRect(lx - half, ly - half, lx + half, ly + half, rr, rr, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = ink
            c.drawRoundRect(lx - half, ly - half, lx + half, ly + half, rr, rr, p)
            p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
            val lg = Art.logoPath(ctx, lightLogo)
            val lh = 104f; val lw = lh * lg.width / lg.height
            c.drawBitmap(lg, null, RectF(lx - lw / 2f, ly - lh / 2f, lx + lw / 2f, ly + lh / 2f), p)
        }

        // ---- ডিজাইন ১: ঘড়ি ও সাহরী/ইফতার
        if (d == 1) {
            text(c, p, "সেহরি", 698.77f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.sehri, 703.71f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)
            text(c, p, "ইফতার", 995.9f + PILL_SHIFT, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.iftar, 992.11f + PILL_SHIFT, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

            val ampm = if (snap.isPm) "PM" else "AM"
            text(c, p, ampm, 424.41f, 299.25f, 40f, pal.pm, Fonts.bebas)
            // ঘণ্টা ও মিনিট বিটম্যাপেই (ডিজাইনের ফন্টে) আঁকা — প্রতি মিনিটের শুরুতে উইজেট নতুন করে আঁকা হয়।
            // শুধু সেকেন্ড লাইভ (TextClock), কারণ প্রতি সেকেন্ডে অ্যাপ জাগানো যাবে না।
            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
            text(c, p, if (hh < 10) "0$hh" else "$hh", 65.32f, 332.48f, 136.17f, pal.clock, Fonts.bebas)
            text(c, p, pad2a(cal.get(Calendar.MINUTE)), 218.54f, 334.48f, 125f, pal.clock, Fonts.bebas)
            if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), 353.03f, 340.13f, 65f, pal.clock, Fonts.bebas)
            else ov.ss = TextSpec(0f, 0f, 0f, pal.clock)
        }

        // ---- পাঁচ ওয়াক্ত
        val nameY = 448.74f + yOff
        val timeY = 502.65f + yOff
        val hlY = 381.16f + yOff
        for (i in 0 until 5) {
            val cx = COL_CX[i]
            val hl = (snap.current == i) && snap.forbid == 0
            if (hl) {
                p.style = Paint.Style.FILL; p.color = pal.hlFill
                c.drawRoundRect(cx - HL_W / 2f, hlY, cx + HL_W / 2f, hlY + HL_H, HL_RX, HL_RX, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, nameY + (if (hl) HL_NAME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.name, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, timeY + (if (hl) HL_TIME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.time, Fonts.bold, Paint.Align.CENTER)
        }

        if (snap.forbid == 2) return   // "–" সময়: শুধু নিচের কাউন্টডাউন লাইন বাদ (কার্ডও ছোট); ওয়াক্তের নাম-সময় থাকে

        // ---- নিচের লাইন: "<ওয়াক্ত> -এর সময় অতিবাহিত: 00:20:59"
        val nowY = 577.67f + yOff
        val inForbid = snap.forbid == 1
        val warn = if (lum(pal.name) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val prefix = if (inForbid) "নিষিদ্ধ সময় বাকি:"
                     else if (snap.running) snap.currentName + " -এর সময় অতিবাহিত:"
                     else snap.currentName + " -এর সময় শুরু হতে বাকি:"
        var ps = 50f; val ds2 = 40f
        val digitsText = if (live) formatHms(
            if (inForbid) snap.forbidEndMs - nowMs else if (snap.running) nowMs - snap.periodStartMs else snap.periodEndMs - nowMs) else ""
        // অঙ্ক সবসময় একই জায়গায় (লাইভ Chronometer-এর বক্স স্থির), লেবেল তার বাঁ-পাশে ডান-সারিবদ্ধ
        val labelEnd = CH12_X - CH12_GAP
        var pw = measure(p, prefix, if (inForbid) Fonts.bold else Fonts.regular, ps)
        val maxLabel = labelEnd - 40f
        if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel }
        text(c, p, prefix, labelEnd - pw, nowY, ps, if (inForbid) warn else pal.now, if (inForbid) Fonts.bold else Fonts.regular)
        if (live) text(c, p, digitsText, CH12_X, nowY, ds2, pal.nowTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.nowTime)
    }

    // লাইভ কাউন্টারের স্থির বাম-কিনারা (ডিজাইন-ইউনিট) ও লেবেলের ফাঁক
    const val CH12_X = 710f; const val CH12_GAP = 10f

    private const val DATE_SEP = 30f      // ইংরেজি ও বাংলা তারিখের মাঝে মোট ফাঁক (দাগসহ)
}
