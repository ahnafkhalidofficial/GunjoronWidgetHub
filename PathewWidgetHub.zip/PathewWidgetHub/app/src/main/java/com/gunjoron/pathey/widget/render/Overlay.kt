package com.gunjoron.pathey.widget.render

/** ওভারলে (লাইভ) টেক্সটের জায়গা — ডিজাইন-ইউনিটে, কার্ডের বাম-উপরের কোণ থেকে; y = বেসলাইন। */
class TextSpec(val x: Float, val y: Float, val size: Float, val color: Int)

class Overlay {
    var ss: TextSpec? = null
    var s3: TextSpec? = null      // ডিজাইন ৩: ":ss"
    var chrono: TextSpec? = null  // কাউন্টডাউন / কাউন্ট-আপ
}

