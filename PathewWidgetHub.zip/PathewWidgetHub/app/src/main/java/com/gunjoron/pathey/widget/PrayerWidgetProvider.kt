package com.gunjoron.pathey.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.update(context, appWidgetManager, appWidgetIds)
    }

    // ইউজার উইজেট রিসাইজ করলে নতুন মাপে আবার আঁকা হয়
    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle
    ) {
        WidgetUpdater.update(context, appWidgetManager, intArrayOf(appWidgetId))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            // ফোন আনলক: ডিজাইন ৬-এ সূর্য/চাঁদের ছোট অ্যানিমেশন (কাজ পাশের থ্রেডে; শেষে pendingResult.finish())
            Intent.ACTION_USER_PRESENT -> {
                val pr = goAsync()
                Thread {
                    try { WidgetUpdater.playUnlockAnim(context.applicationContext) } catch (_: Throwable) {} finally { pr.finish() }
                }.start()
            }
            WidgetUpdater.ACTION_TICK,
            WidgetUpdater.ACTION_REFRESH,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> WidgetUpdater.updateAll(context)
        }
    }

    override fun onDisabled(context: Context) {
        WidgetUpdater.cancel(context)
    }
}
