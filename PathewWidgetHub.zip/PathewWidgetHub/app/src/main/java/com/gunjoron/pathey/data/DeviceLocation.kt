package com.gunjoron.pathey.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build

/** ডিভাইসের লোকেশন অটো নেয় (ম্যানুয়াল সিলেকশন নেই)। পারমিশন/লোকেশন না পেলে সর্বশেষ সেভ করা বা ঢাকা। */
object DeviceLocation {
    fun hasPermission(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** লোকেশন বদলালে true (মূল থ্রেডে ডাকা যায়; নতুন ফিক্স এলে onChanged ডাকে)। */
    fun refresh(ctx: Context, onChanged: () -> Unit) {
        if (!hasPermission(ctx)) return
        val app = ctx.applicationContext
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return
        val prefs = Prefs.get(app)
        fun save(l: Location) {
            val moved = Math.abs(l.latitude - prefs.lat) > 0.02 || Math.abs(l.longitude - prefs.lng) > 0.02
            if (moved) { prefs.lat = l.latitude; prefs.lng = l.longitude; onChanged() }
        }
        try {
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best!!.time) best = l
            }
            best?.let { save(it) }
            if (best == null && Build.VERSION.SDK_INT >= 30) {
                val p = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
                        else if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else return
                lm.getCurrentLocation(p, null, app.mainExecutor) { l -> if (l != null) save(l) }
            }
        } catch (_: Throwable) {}
    }
}
