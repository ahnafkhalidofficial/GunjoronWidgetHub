package com.gunjoron.pathey.widget.designs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.data.calendar.Bn
import com.gunjoron.pathey.widget.WidgetRenderer.cardW
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.render.*
import com.gunjoron.pathey.widget.theme.Look
import com.gunjoron.pathey.widget.theme.Palettes
import java.util.Calendar

/** ডিজাইন ৪ (মিনিমাল): বড় পাতলা ঘড়ি, চলমান ওয়াক্ত, প্রগ্রেস বার, পাঁচ ওয়াক্ত। */
internal object MinimalDesign {
    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(4)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val ampm = if (snap.isPm) "PM" else "AM"
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val L = 40f; val R = cw - 40f
        val colW = (R - L) / 5f

        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f4 = snap.forbid          // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত

        // ওপরের সারি: বাঁয়ে লোগো + ইংরেজি তারিখ (ব্র্যান্ড-লকআপ) | ডানে হিজরি তারিখ — বোল্ড
        val dsz = 39f
        logoRing(ctx, c, p, m, L + 29f, 64f, 29f)
        text(c, p, snap.gregorianLine, L + 74f, 80f, dsz, m.secondary, Fonts.bold)
        text(c, p, snap.hijriDay + " " + snap.hijriMonthYear, R, 80f, dsz, m.secondary, Fonts.bold, Paint.Align.RIGHT)

        // বড় পাতলা ঘড়ি (ডান কিনারা স্থির) + ডানে AM/PM, তার ঠিক নিচে লাইভ সেকেন্ড
        val clockSize = 172f
        val clockEnd = L - 6f + (measure(p, "00", Fonts.outfit, clockSize) * 2f + measure(p, ":", Fonts.outfit, clockSize))
        val hmNow = hm
        val cwNow = measure(p, hmNow.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hmNow.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hmNow, clockEnd - cwNow, 250f, clockSize, m.primary)
        val sx = clockEnd + 22f + measure(p, "00", Fonts.outfit, 44f) / 2f
        text(c, p, ampm, sx, 202f, 44f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), sx, 250f, 44f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ডানে চলমান ওয়াক্ত: নাম বড়, ডানে গোল-কোণা "চলমান" বক্স। নিষিদ্ধ সময়ে "নিষিদ্ধ সময়"; মাঝের ফাঁকে নাম ও টাইমার "–"
        val bx0 = clockEnd + 22f + 90f
        val chipTxt = "চলমান"; val chipSz = 26f
        val chipW = measure(p, chipTxt, Fonts.bold, chipSz) + 32f
        when (f4) {
            0 -> {
                val maxName = R - bx0 - chipW - 16f
                val nsz = fit(p, snap.currentName, Fonts.bold, 84f, maxName)
                val nw = measure(p, snap.currentName, Fonts.bold, nsz)
                val x0 = R - chipW - 16f - nw
                text(c, p, snap.currentName, x0, 204f, nsz, m.accent, Fonts.bold)
                val cx0 = R - chipW
                tile(c, p, cx0, 156f, R, 200f, 22f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x80000000.toInt())
                text(c, p, chipTxt, cx0 + chipW / 2f, 188f, chipSz, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 898f, 254f, 44f, 38f, m.primary, m.primary)
            }
            1 -> {
                val nsz = fit(p, "নিষিদ্ধ সময়", Fonts.bold, 84f, R - bx0)
                text(c, p, "নিষিদ্ধ সময়", R, 204f, nsz, warn, Fonts.bold, Paint.Align.RIGHT)
                remLine(c, p, ov, live, snap, nowMs, 898f, 254f, 44f, 38f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, "–", R, 204f, 84f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
                text(c, p, "–", R, 254f, 50f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
        }

        // প্রগ্রেস বার: স্বাভাবিকে ওয়াক্তের; নিষিদ্ধ সময়ে ওই সময়ের (লাল-কমলা); মাঝের ফাঁকে শুধু ফাঁকা ট্র্যাক
        val barFrac = when (f4) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        bar(c, p, L, R, 296f, 8f, barFrac, m.track, if (f4 == 1) warn else m.accent)

        // পাঁচ ওয়াক্ত (নিষিদ্ধ সময়ে ও মাঝের ফাঁকে কোনোটাই নির্বাচিত/হাইলাইট নয়)
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = f4 == 0 && snap.current == i
            text(c, p, snap.prayerNames[i], cx, 360f, 39f, if (on) m.accent else m.secondary, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 416f, 48f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }
}
