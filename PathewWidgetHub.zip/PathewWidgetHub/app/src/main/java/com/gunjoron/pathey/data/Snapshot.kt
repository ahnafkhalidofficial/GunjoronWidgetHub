package com.gunjoron.pathey.data

import android.content.Context
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar

/**
 * একটি নির্দিষ্ট মুহূর্তের সব প্রদর্শনযোগ্য তথ্য। রেন্ডারার শুধু এটাই পড়ে।
 *
 * current: ০=ফজর ১=যোহর ২=আসর ৩=মাগরিব ৪=ইশা, -১ = সূর্যোদয় থেকে যোহর পর্যন্ত (কোনো ওয়াক্ত চলছে না)।
 */
class Snapshot(
    val nowMs: Long,
    val hijriMonthYear: String,      // "রবিউস সানি ১৪৪৭"
    val gregDay: String,             // "১৯"
    val gregMonth: String,           // "অক্টোবর"
    val gregYear: String,            // "২০২৬"
    val banglaDay: String,
    val banglaMonth: String,
    val banglaYear: String,
    val hijriDay: String,
    val hijriMonth: String,
    val hijriYear: String,
    val prayerTimes: Array<String>,  // ০৪:৫৫ ফরম্যাট, ফজর/যোহর/আসর/মাগরিব/ইশা
    val sunrise: String,             // ৬:৫৯
    val sehri: String,
    val iftar: String,
    val current: Int,
    val currentName: String,         // চলমান (বা পরবর্তী) ওয়াক্তের নাম
    val running: Boolean,            // true = ওয়াক্ত চলছে; false = সূর্যোদয়-যোহর বিরতি
    val periodStartMs: Long,         // চলমান ওয়াক্তের শুরু (বা বিরতির শুরু)
    val periodEndMs: Long,           // চলমান ওয়াক্তের শেষ (বা যোহরের শুরু)
    val isPm: Boolean,
    val nextChangeMs: Long           // উইজেট কখন আবার রিফ্রেশ করতে হবে
) {
    val gregorianLine: String get() = "$gregDay $gregMonth $gregYear"
    val banglaLine: String get() = "$banglaDay $banglaMonth $banglaYear"

    companion object {
        private fun clock12(ms: Long, pad: Boolean): String {
            val c = Calendar.getInstance(); c.timeInMillis = ms
            var h = c.get(Calendar.HOUR); if (h == 0) h = 12
            val m = c.get(Calendar.MINUTE)
            return Bn.digits((if (pad && h < 10) "0$h" else "$h") + ":" + Bn.pad2(m))
        }

        fun build(ctx: Context, nowMs: Long = System.currentTimeMillis()): Snapshot {
            val prefs = Prefs.get(ctx)
            val zone = ZoneId.systemDefault()
            val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
            val city = Cities.LIST[prefs.cityIndex]
            val t0 = PrayerCalc.compute(today, city.lat, city.lng, zone)
            val tPrev = PrayerCalc.compute(today.minusDays(1), city.lat, city.lng, zone)
            val tNext = PrayerCalc.compute(today.plusDays(1), city.lat, city.lng, zone)

            val cur: Int; val start: Long; val end: Long; val running: Boolean
            when {
                nowMs < t0.fajr -> { cur = 4; start = tPrev.isha; end = t0.fajr; running = true }
                nowMs < t0.sunrise -> { cur = 0; start = t0.fajr; end = t0.sunrise; running = true }
                nowMs < t0.dhuhr -> { cur = -1; start = t0.sunrise; end = t0.dhuhr; running = false }
                nowMs < t0.asr -> { cur = 1; start = t0.dhuhr; end = t0.asr; running = true }
                nowMs < t0.maghrib -> { cur = 2; start = t0.asr; end = t0.maghrib; running = true }
                nowMs < t0.isha -> { cur = 3; start = t0.maghrib; end = t0.isha; running = true }
                else -> { cur = 4; start = t0.isha; end = tNext.fajr; running = true }
            }
            val name = if (cur >= 0) Bn.PRAYER_NAMES[cur] else Bn.PRAYER_NAMES[1]

            val ld = today
            val bn = Calendars.bangla(ld)
            val hj = Calendars.hijri(ld, prefs.hijriAdjust)

            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            val isPm = cal.get(Calendar.HOUR_OF_DAY) >= 12

            // পরবর্তী রিফ্রেশ: ওয়াক্তের সীমা, ১ ঘণ্টা/১০ ঘণ্টা পার হলে Chronometer-এর ফরম্যাট বদল,
            // দুপুর ১২টা ও মধ্যরাত (AM/PM ও তারিখ)।
            val noon = t0.dayStartMs + 12 * 3600_000L
            val midnight = tNext.dayStartMs
            val cands = ArrayList<Long>()
            cands += listOf(t0.fajr, t0.sunrise, t0.dhuhr, t0.asr, t0.maghrib, t0.isha, tNext.fajr, noon, midnight)
            // কাউন্ট-ডাউন (বিরতিকালে ও d3-তে): শেষ − ১ ঘণ্টা / − ১০ ঘণ্টা; কাউন্ট-আপ: শুরু + ১ ঘণ্টা / + ১০ ঘণ্টা
            for (h in longArrayOf(3600_000L, 36000_000L)) { cands += end - h; cands += start + h }
            var next = Long.MAX_VALUE
            for (c in cands) if (c > nowMs + 500 && c < next) next = c
            if (next == Long.MAX_VALUE) next = nowMs + 60_000L

            return Snapshot(
                nowMs = nowMs,
                hijriMonthYear = Bn.HIJRI_MONTHS[hj.month] + " " + Bn.digits(hj.year),
                gregDay = Bn.digits(ld.dayOfMonth),
                gregMonth = Bn.GREG_MONTHS[ld.monthValue - 1],
                gregYear = Bn.digits(ld.year),
                banglaDay = Bn.digits(bn.day),
                banglaMonth = Bn.BANGLA_MONTHS[bn.month],
                banglaYear = Bn.digits(bn.year),
                hijriDay = Bn.digits(hj.day),
                hijriMonth = Bn.HIJRI_MONTHS[hj.month],
                hijriYear = Bn.digits(hj.year),
                prayerTimes = arrayOf(
                    clock12(t0.fajr, true), clock12(t0.dhuhr, true), clock12(t0.asr, true),
                    clock12(t0.maghrib, true), clock12(t0.isha, true)
                ),
                sunrise = clock12(t0.sunrise, false),
                sehri = clock12(t0.fajr, false),
                iftar = clock12(t0.maghrib, false),
                current = cur, currentName = name, running = running,
                periodStartMs = start, periodEndMs = end,
                isPm = isPm,
                nextChangeMs = next + 1000L
            )
        }
    }
}
