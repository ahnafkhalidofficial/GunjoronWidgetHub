package com.gunjoron.pathey.data.remote

import android.content.Context
import com.gunjoron.pathey.data.Prefs
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/**
 * ফায়ারবেজ রিয়েলটাইম ডেটাবেজের prayer_config থেকে হিজরি তারিখের কনফিগ আনে:
 *   hijri_adjustment (দিন, যেমন -1) · hijri_override (true হলে bn/en-এর দিন-মাস সরাসরি) · bn{day,month} · en{day,month}
 * সর্বশেষ মান Prefs-এ থাকে (অফলাইনেও কাজ করে)।
 */
object RemoteConfig {
    private const val URL_CONFIG = "https://hijri-tarikh-default-rtdb.firebaseio.com/prayer_config.json"
    private const val STALE_MS = 15 * 60_000L

    /** নতুন ডেটা এলে true — ব্যাকগ্রাউন্ড থ্রেডে ডাকতে হবে। force=false হলে ১৫ মিনিটের মধ্যে আবার আনে না। */
    fun fetch(ctx: Context, force: Boolean = false): Boolean {
        val prefs = Prefs.get(ctx)
        val now = System.currentTimeMillis()
        if (!force && now - prefs.configFetchedMs < STALE_MS) return false
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(URL_CONFIG).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 8000; requestMethod = "GET"
            }
            if (conn.responseCode != 200) return false
            val js = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val bn = js.optJSONObject("bn"); val en = js.optJSONObject("en")
            val before = listOf(prefs.hijriAdjust, prefs.hijriOverride, prefs.hijriOvDay, prefs.hijriOvMonthBn, prefs.hijriOvDayEn, prefs.hijriOvMonthEn)
            prefs.hijriAdjust = js.optInt("hijri_adjustment", prefs.hijriAdjust)
            prefs.hijriOverride = js.optBoolean("hijri_override", false)
            if (bn != null) { prefs.hijriOvDay = bn.optInt("day", prefs.hijriOvDay); prefs.hijriOvMonthBn = bn.optString("month", prefs.hijriOvMonthBn) }
            if (en != null) { prefs.hijriOvDayEn = en.optInt("day", prefs.hijriOvDayEn); prefs.hijriOvMonthEn = en.optString("month", prefs.hijriOvMonthEn) }
            prefs.configFetchedMs = now
            before != listOf(prefs.hijriAdjust, prefs.hijriOverride, prefs.hijriOvDay, prefs.hijriOvMonthBn, prefs.hijriOvDayEn, prefs.hijriOvMonthEn)
        } catch (_: Throwable) { false } finally { try { conn?.disconnect() } catch (_: Throwable) {} }
    }
}
