package com.gunjoron.pathey.data.prayer

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.*

/**
 * অফলাইন নামাজের সময় হিসাব (PrayTimes.org অ্যালগরিদম)।
 * ডিফল্ট: University of Islamic Sciences, Karachi (ফজর ১৮°, ইশা ১৮°) + হানাফী আসর — বাংলাদেশে প্রচলিত।
 * ইন্টারনেট/API লাগে না, তাই উইজেট সবসময় তাৎক্ষণিক ও নির্ভরযোগ্য।
 */
object PrayerCalc {
    /** সব মান স্থানীয় সময়ে, মধ্যরাত থেকে মিলিসেকেন্ডে (দিনের শুরু থেকে)। */
    class Day(
        val date: LocalDate,
        val dayStartMs: Long,
        val fajr: Long, val sunrise: Long, val dhuhr: Long,
        val asr: Long, val maghrib: Long, val isha: Long
    )

    private const val FAJR_ANGLE = 18.0
    private const val ISHA_ANGLE = 18.0
    private const val ASR_FACTOR = 2.0 // হানাফী

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double): Double { val r = a - 360.0 * floor(a / 360.0); return r }
    private fun fixHour(a: Double): Double { return a - 24.0 * floor(a / 24.0) }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private class Sun(val decl: Double, val eqt: Double)

    private fun sunPos(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return Sun(decl, eqt)
    }

    fun compute(date: LocalDate, lat: Double, lng: Double, zone: ZoneId = ZoneId.systemDefault()): Day {
        val dayStart = date.atStartOfDay(zone)
        val dayStartMs = dayStart.toInstant().toEpochMilli()
        val tzHours = zone.rules.getOffset(dayStart.toInstant().plusSeconds(12 * 3600L)).totalSeconds / 3600.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)

        fun midDay(t: Double) = fixHour(12 - sunPos(jd + t).eqt)
        fun sunAngleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPos(jd + t).decl
            val noon = midDay(t)
            val x = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) / (cos(rad(decl)) * cos(rad(lat)))
            val h = 1.0 / 15.0 * deg(acos(x.coerceIn(-1.0, 1.0)))
            return noon + (if (ccw) -h else h)
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPos(jd + t).decl
            val angle = -deg(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
            return sunAngleTime(angle, t, false)
        }

        var tf = 5.0 / 24; var tsr = 6.0 / 24; var td = 12.0 / 24; var ta = 13.0 / 24; var tss = 18.0 / 24; var ti = 18.0 / 24
        // PrayTimes একবারের পুনরাবৃত্তি যথেষ্ট; আমরা দুইবার করি — আরও নির্ভুল।
        var fajr = 0.0; var sunrise = 0.0; var dhuhr = 0.0; var asr = 0.0; var sunset = 0.0; var isha = 0.0
        repeat(2) {
            fajr = sunAngleTime(FAJR_ANGLE, tf, true)
            sunrise = sunAngleTime(0.833, tsr, true)
            dhuhr = midDay(td)
            asr = asrTime(ASR_FACTOR, ta)
            sunset = sunAngleTime(0.833, tss, false)
            isha = sunAngleTime(ISHA_ANGLE, ti, false)
            tf = fajr / 24; tsr = sunrise / 24; td = dhuhr / 24; ta = asr / 24; tss = sunset / 24; ti = isha / 24
        }
        val shift = tzHours - lng / 15.0
        fun ms(h: Double) = dayStartMs + ((h + shift) * 3600_000.0).toLong()
        return Day(date, dayStartMs, ms(fajr), ms(sunrise), ms(dhuhr), ms(asr), ms(sunset), ms(isha))
    }
}
