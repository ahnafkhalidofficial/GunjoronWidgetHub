package com.gunjoron.pathey.widget.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.data.calendar.Bn
import com.gunjoron.pathey.widget.assets.Art
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.theme.PaletteMin
import java.util.Calendar

/**
 * ডিজাইনগুলোর শেয়ার করা ছোট আঁকার সরঞ্জাম: লেখা, মাপ, প্রগ্রেস বার, টাইল, আইকন, লোগো ইত্যাদি।
 * (সব ডিজাইনই এখান থেকে ব্যবহার করে — একই কাজ বারবার লেখা হয়নি।)
 */

internal fun formatHms(totalMs: Long): String {
    val t = (if (totalMs < 0) 0 else totalMs) / 1000
    val h = t / 3600; val m = (t / 60) % 60; val s = t % 60
    return Bn.pad2(h.toInt()) + ":" + Bn.pad2(m.toInt()) + ":" + Bn.pad2(s.toInt())
}

/** কার্ড/প্যানেলের রঙের অস্বচ্ছতা সামান্য কমানো — যাতে পেছনের ওয়ালপেপার হালকা ঝাপসা দেখা যায়। */
private const val GLASS_ALPHA = 0.85f

internal fun soften(color: Int): Int {
    val a = ((color ushr 24) * GLASS_ALPHA).toInt().coerceIn(0, 255)
    return (a shl 24) or (color and 0xFFFFFF)
}

/** কোনো গ্রেডিয়েন্ট নয় — শুধু খুব হালকা ফ্রস্ট-দানা, যাতে ঝাপসা কাচের অনুভূতি আসে। */
private val grain: Bitmap by lazy {
    val n = 96
    val px = IntArray(n * n)
    val r = java.util.Random(7)
    for (i in px.indices) {
        val a = r.nextInt(15)                       // ০–১৪ / ২৫৫ — হালকা
        px[i] = (a shl 24) or (if (r.nextBoolean()) 0xFFFFFF else 0x000000)
    }
    Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
}

internal fun glass(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float) {
    p.style = Paint.Style.FILL
    p.shader = BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    c.drawRoundRect(l, t, r, b, rx, rx, p)
    p.shader = null
}

internal fun measure(p: Paint, s: String, tf: Typeface, size: Float): Float {
    p.typeface = tf; p.textSize = size
    return p.measureText(s)
}

internal fun text(c: Canvas, p: Paint, s: String, x: Float, y: Float, size: Float, color: Int,
                 tf: Typeface, align: Paint.Align = Paint.Align.LEFT) {
    p.style = Paint.Style.FILL
    p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
    c.drawText(s, x, y, p)
    p.textAlign = Paint.Align.LEFT
}

internal fun pad2a(n: Int) = if (n < 10) "0$n" else n.toString()

// ------------------------------------------------------------------------------------------
// ডিজাইন ৪ (মিনিমাল) ও ৫ (স্ট্রিপ) — কোনো আর্ট/লাইভ ওভারলে নেই; সবকিছু বিটম্যাপে, প্রতি মিনিটে নতুন।
// ------------------------------------------------------------------------------------------
/**
 * "০১:২৩:৫৬ বাকি" — অঙ্কগুলো লাইভ কাউন্টডাউন (প্রিভিউতে আঁকা, হোমস্ক্রিনে Chronometer), "বাকি" বিটম্যাপে।
 * dr = অঙ্ক-বক্সের ডান কিনারা (স্থির; genlayout.py-র REM বক্সের সাথে মেলাতে হবে), লেবেল তার ১০ ইউনিট ডানে।
 */
internal fun remLine(c: Canvas, p: Paint, ov: Overlay, live: Boolean, snap: Snapshot, nowMs: Long,
                    dr: Float, base: Float, dsz: Float, lsz: Float, dcol: Int, lcol: Int,
                    endMs: Long = snap.periodEndMs) {
    if (live) text(c, p, formatHms(endMs - nowMs), dr, base, dsz, dcol, Fonts.bebas, Paint.Align.RIGHT)
    else ov.chrono = TextSpec(0f, 0f, 0f, dcol)
    text(c, p, "বাকি", dr + 10f, base, lsz, lcol, Fonts.regular)
}

private val WEEKDAYS = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

internal fun weekday(nowMs: Long): String {
    val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
    return WEEKDAYS[cal.get(Calendar.DAY_OF_WEEK) - 1]
}

/** পাতলা ঘড়ি: ঘণ্টা | কোলন (অঙ্কের মাঝ বরাবর) | মিনিট। ফেরত: মোট প্রস্থ। */
internal fun slimClock(c: Canvas, p: Paint, hm: String, x: Float, base: Float, size: Float, color: Int): Float {
    p.typeface = Fonts.outfit; p.textSize = size
    val r0 = Rect(); p.getTextBounds("0", 0, 1, r0)
    val r1 = Rect(); p.getTextBounds(":", 0, 1, r1)
    val dy = (r0.top + r0.bottom) / 2f - (r1.top + r1.bottom) / 2f
    val a = hm.substring(0, 2); val b = hm.substring(3)
    val aw = measure(p, a, Fonts.outfit, size); val cw = measure(p, ":", Fonts.outfit, size)
    val bw = measure(p, b, Fonts.outfit, size)
    text(c, p, a, x, base, size, color, Fonts.outfit)
    text(c, p, ":", x + aw, base + dy, size, color, Fonts.outfit)
    text(c, p, b, x + aw + cw, base, size, color, Fonts.outfit)
    return aw + cw + bw
}

internal fun bar(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
    p.style = Paint.Style.FILL; p.color = track
    c.drawRoundRect(x0, y, x1, y + h, h / 2f, h / 2f, p)
    val fx = x0 + (x1 - x0) * frac.coerceIn(0f, 1f)
    if (fx - x0 > h) { p.color = fill; c.drawRoundRect(x0, y, fx, y + h, h / 2f, h / 2f, p) }
}

internal fun fit(p: Paint, s: String, tf: Typeface, size: Float, maxW: Float): Float {
    val w = measure(p, s, tf, size)
    return if (w > maxW) size * maxW / w else size
}

// ------------------------------------------------------------------------------------------
// ডিজাইন ৬ (সান-আর্ক): সূর্যোদয় থেকে সূর্যাস্তের আর্ক, তাতে সূর্যের বর্তমান অবস্থান; ভেতরে ঘড়ি;
// দুই প্রান্তে সূর্যোদয়/সূর্যাস্ত, মাঝে চলমান ওয়াক্ত; নিচে পাঁচ ওয়াক্তের স্ট্রিপ।
// ------------------------------------------------------------------------------------------
internal fun onColor(bg: Int): Int {
    val r = (bg shr 16) and 255; val g = (bg shr 8) and 255; val b = bg and 255
    return if (0.299f * r + 0.587f * g + 0.114f * b > 150f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
}

/** ৪-কোনা ছোট তারা (ভেক্টর-আইকনের মতো) */
internal fun sparkle(c: Canvas, p: Paint, x: Float, y: Float, r: Float, color: Int) {
    val k = r * 0.3f
    val path = Path()
    path.moveTo(x, y - r); path.lineTo(x + k, y - k); path.lineTo(x + r, y); path.lineTo(x + k, y + k)
    path.lineTo(x, y + r); path.lineTo(x - k, y + k); path.lineTo(x - r, y); path.lineTo(x - k, y - k)
    path.close()
    p.style = Paint.Style.FILL; p.color = color
    c.drawPath(path, p)
}

/** সূর্য: গোল চাকতি + ৮টা গোল-মাথা রশ্মি (ফ্ল্যাট ভেক্টর আইকন) */
internal fun sun(c: Canvas, p: Paint, cx: Float, cy: Float, color: Int, halo: Boolean) {
    p.style = Paint.Style.FILL
    if (halo) {   // লাইট থিমে আভা/ছায়া নেই
        p.color = (color and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, 44f, p)
        p.color = (color and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, 33f, p)
    }
    p.color = color; c.drawCircle(cx, cy, 14f, p)
    p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.5f; p.color = color
    for (i in 0 until 8) {
        val t = Math.PI / 4.0 * i
        val ca = Math.cos(t).toFloat(); val sa = Math.sin(t).toFloat()
        c.drawLine(cx + ca * 21f, cy + sa * 21f, cx + ca * 28.5f, cy + sa * 28.5f, p)
    }
    p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
}

/**
 * চাঁদ: মসৃণ অর্ধচন্দ্র (বড় বৃত্ত − ছোট বৃত্ত) + দুটো ছোট তারা (ফ্ল্যাট ভেক্টর আইকন)।
 * rotDeg: চাঁদের "কামড়" যেদিকে মুখ করে (চলার দিক); পেছনের মোটা গোল কিনারা আর্কের দাগের সাথে মেলে।
 */
internal fun moon(c: Canvas, p: Paint, cx: Float, cy: Float, rad: Float, glow: Int, body: Int, halo: Boolean, rotDeg: Float) {
    p.style = Paint.Style.FILL
    if (halo) {   // লাইট থিমে আভা/ছায়া নেই
        p.color = (glow and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, rad + 22f, p)
        p.color = (glow and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, rad + 11f, p)
    }
    c.save()
    c.translate(cx, cy); c.rotate(rotDeg)
    val d = rad * 0.40f; val r2 = rad * 0.86f
    val x = (d * d + rad * rad - r2 * r2) / (2f * d)
    val y = Math.sqrt((rad * rad - x * x).toDouble()).toFloat()
    val aR = Math.atan2(y.toDouble(), x.toDouble())
    val bR = Math.atan2(y.toDouble(), (x - d).toDouble())
    val a = Math.toDegrees(aR).toFloat(); val b2 = Math.toDegrees(bR).toFloat()
    val path = Path()
    path.moveTo(rad * Math.cos(-aR).toFloat(), rad * Math.sin(-aR).toFloat())
    path.arcTo(RectF(-rad, -rad, rad, rad), -a, -(360f - 2f * a))
    path.arcTo(RectF(d - r2, -r2, d + r2, r2), b2, 360f - 2f * b2)
    path.close()
    p.color = body
    c.drawPath(path, p)
    c.restore()
}

internal fun lum(col: Int): Float =
    0.299f * ((col shr 16) and 255) + 0.587f * ((col shr 8) and 255) + 0.114f * (col and 255)

/** ডিজাইন ৬/৭/৮-এর এক লোগো: গোল বৃত্ত + ভেতরে লোগোর পাথ (লাইট/ডার্ক অনুযায়ী রঙ) */
internal fun logoRing(ctx: Context, c: Canvas, p: Paint, m: PaletteMin, cx: Float, cy: Float, lr: Float) {
    p.style = Paint.Style.FILL; p.shader = null; p.color = (m.primary and 0xFFFFFF) or 0x14000000
    c.drawCircle(cx, cy, lr, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = lr * 0.111f; p.color = m.primary
    c.drawCircle(cx, cy, lr, p)
    p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
    val lg = Art.logoPath(ctx, lum(m.primary) > 150f)
    val lh = lr * 1.333f; val lw = lh * lg.width / lg.height
    c.drawBitmap(lg, null, RectF(cx - lw / 2f, cy - lh / 2f, cx + lw / 2f, cy + lh / 2f), p)
}

// ------------------------------------------------------------------------------------------
// ডিজাইন ৭ ও ৮ — ডিজাইন ১-এর আইকন-মেডালিয়ন (সূর্যোদয়, সেহরি, ইফতার) ও লোগো, ডিজাইন ১-এর আর্ট থেকে নেওয়া।
// ------------------------------------------------------------------------------------------
private val MEDAL_SRC = arrayOf(
    Rect(832, 52, 925, 145),     // সূর্যোদয়
    Rect(533, 239, 627, 333),    // সেহরি
    Rect(819, 239, 913, 333)     // ইফতার
)

private val LOGO_SRC = Rect(56, 42, 197, 185)

internal fun medal(c: Canvas, p: Paint, art: Bitmap, i: Int, cx: Float, cy: Float, dia: Float) {
    val r = dia / 2f
    c.save()
    val path = Path(); path.addCircle(cx, cy, r * 0.985f, Path.Direction.CW)
    c.clipPath(path)
    p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
    c.drawBitmap(art, MEDAL_SRC[i], RectF(cx - r, cy - r, cx + r, cy + r), p)
    c.restore()
}

internal fun hmOf(nowMs: Long): String {
    val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
    var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
    return (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
}

internal fun tile(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float, color: Int, edge: Int = 0) {
    p.style = Paint.Style.FILL; p.color = color
    c.drawRoundRect(l, t, r, b, rx, rx, p)
    if (edge != 0) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = edge
        c.drawRoundRect(l + 0.75f, t + 0.75f, r - 0.75f, b - 0.75f, rx, rx, p)
        p.style = Paint.Style.FILL
    }
}

/** প্রগ্রেস বার + শেষ প্রান্তে গোল নব */
internal fun barK(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
    bar(c, p, x0, x1, y, h, frac, track, fill)
    val kx = (x0 + (x1 - x0) * frac.coerceIn(0f, 1f)).coerceIn(x0 + h, x1 - h)
    p.style = Paint.Style.FILL
    p.color = (fill and 0xFFFFFF) or 0x44000000; c.drawCircle(kx, y + h / 2f, h * 2.1f, p)
    p.color = fill; c.drawCircle(kx, y + h / 2f, h * 1.15f, p)
}
