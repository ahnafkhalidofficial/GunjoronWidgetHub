package com.gunjoron.pathey.hub.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** কালার হুইল (হিউ = কোণ, স্যাচুরেশন = ব্যাসার্ধ)। শেডার দিয়ে আঁকা — বিটম্যাপ জেনারেট করতে হয় না, তাই তাৎক্ষণিক। */
class ColorWheelView(ctx: Context) : View(ctx) {
    var hue = 217f
    var sat = 0.5f
    var knobColor = 0xFF1E293B.toInt()
    var ringColor = 0xFF15275A.toInt()
    var onPick: ((Float, Float) -> Unit)? = null

    private val wheel = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sweepColors = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val knobFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val knobShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x8C000000.toInt() }
    private var sweep: Shader? = null
    private var radial: Shader? = null
    private val radialPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f; val r = min(w, h) / 2f - 3f * resources.displayMetrics.density
        sweep = SweepGradient(cx, cy, sweepColors, floatArrayOf(0f, 1f / 6, 2f / 6, 3f / 6, 4f / 6, 5f / 6, 1f))
        radial = RadialGradient(cx, cy, r, 0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
        wheel.shader = sweep; radialPaint.shader = radial
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f; val r = min(width, height) / 2f - 3f * d
        c.drawCircle(cx, cy, r, wheel)
        c.drawCircle(cx, cy, r, radialPaint)
        ring.strokeWidth = 2f * d; ring.color = ringColor
        c.drawCircle(cx, cy, r + d, ring)
        val a = Math.toRadians(hue.toDouble())
        val kx = (cx + cos(a) * sat * r).toFloat(); val ky = (cy + sin(a) * sat * r).toFloat()
        knobFill.color = knobColor
        c.drawCircle(kx, ky, 11f * d, knobFill)
        knobShadow.strokeWidth = 1.5f * d; c.drawCircle(kx, ky, 12f * d, knobShadow)
        knobBorder.strokeWidth = 3f * d; c.drawCircle(kx, ky, 10f * d, knobBorder)
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w)
        setMeasuredDimension(s, s)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val d = resources.displayMetrics.density
                val cx = width / 2f; val cy = height / 2f; val r = min(width, height) / 2f - 3f * d
                val dx = e.x - cx; val dy = e.y - cy
                var h = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat(); if (h < 0) h += 360f
                val s = min(sqrt(dx * dx + dy * dy) / r, 1f)
                hue = h; sat = s
                onPick?.invoke(h, s)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); return true }
        }
        return super.onTouchEvent(e)
    }
}
