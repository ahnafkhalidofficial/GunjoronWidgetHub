package com.gunjoron.pathey.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** হাবের সব সেটিং (থিম, ডিজাইন, কাস্টম রঙ ইত্যাদি) — SharedPreferences-এ সেভ। */
class Prefs private constructor(private val sp: SharedPreferences) {

    var theme: String                       // glass | nobg | light | custom
        get() = sp.getString("theme", "glass") ?: "glass"
        set(v) = sp.edit().putString("theme", v).apply()

    var nobgMode: String                    // dark | light
        get() = sp.getString("nobgMode", "dark") ?: "dark"
        set(v) = sp.edit().putString("nobgMode", v).apply()

    var design: Int
        get() = sp.getInt("design", 1).coerceIn(1, 8)
        set(v) = sp.edit().putInt("design", v).apply()

    var customBg: Int                       // 0xRRGGBB
        get() = sp.getInt("customBg", 0x1E293B)
        set(v) = sp.edit().putInt("customBg", v and 0xFFFFFF).apply()

    var customOpacity: Int                  // ১০–১০০
        get() = sp.getInt("customOpacity", 90).coerceIn(10, 100)
        set(v) = sp.edit().putInt("customOpacity", v.coerceIn(10, 100)).apply()

    var customTone: String                  // auto | dark | light
        get() = sp.getString("customTone", "auto") ?: "auto"
        set(v) = sp.edit().putString("customTone", v).apply()

    var cityIndex: Int
        get() = sp.getInt("city", 0).coerceIn(0, Cities.LIST.size - 1)
        set(v) = sp.edit().putInt("city", v).apply()

    var hijriAdjust: Int
        get() = sp.getInt("hijriAdj", -1).coerceIn(-2, 2)
        set(v) = sp.edit().putInt("hijriAdj", v).apply()

    /** ডিজাইন ৬: ফোন আনলকের সময় সূর্য/চাঁদ শুরু থেকে এখনকার জায়গা পর্যন্ত চলে */
    var anim: Boolean
        get() = sp.getBoolean("anim", true)
        set(v) = sp.edit().putBoolean("anim", v).apply()

    var appDark: Boolean
        get() = sp.getBoolean("appDark", true)
        set(v) = sp.edit().putBoolean("appDark", v).apply()

    /** কাস্টম থিমে লেখা/আইকন হালকা (= গাঢ় লেখা) হবে কি না — হাবের wcIsLightTone()-এর হুবহু সূত্র। */
    fun customIsLightTone(): Boolean = when (customTone) {
        "light" -> true
        "dark" -> false
        else -> {
            val c = customBg
            (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.6
        }
    }

    companion object {
        @Volatile private var inst: Prefs? = null
        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(ctx.applicationContext.getSharedPreferences("hub", Context.MODE_PRIVATE)).also { inst = it }
        }
    }
}
