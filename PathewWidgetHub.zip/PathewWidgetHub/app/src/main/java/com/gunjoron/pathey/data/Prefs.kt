package com.gunjoron.pathey.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** হাবের সব সেটিং (থিম, ডিজাইন, কাস্টম রঙ ইত্যাদি) — SharedPreferences-এ সেভ। */
class Prefs private constructor(private val sp: SharedPreferences) {

    var theme: String                       // glass | nobg | light | custom
        get() = sp.getString("theme", "glass") ?: "glass"
        set(v) = sp.edit().putString("theme", v).apply()

    var nobgMode: String                    // dark | light
        get() = sp.getString("nobgMode", "dark") ?: "dark"
        set(v) = sp.edit().putString("nobgMode", v).apply()

    var design: Int
        get() = sp.getInt("design", 1).coerceIn(1, 9)
        set(v) = sp.edit().putInt("design", v).apply()

    /** হোম স্ক্রিনে যে ডিজাইনের উইজেট সেট করা (সবুজ টিক); আলাদা না থাকলে বাছাই করা ডিজাইনই */
    var widgetDesign: Int
        get() = sp.getInt("wdesign", -1).let { if (it in 1..9) it else design }
        set(v) = sp.edit().putInt("wdesign", v.coerceIn(1, 9)).apply()

    var customBg: Int                       // 0xRRGGBB
        get() = sp.getInt("customBg", 0x1E293B)
        set(v) = sp.edit().putInt("customBg", v and 0xFFFFFF).apply()

    var customOpacity: Int                  // ১০–১০০
        get() = sp.getInt("customOpacity", 90).coerceIn(10, 100)
        set(v) = sp.edit().putInt("customOpacity", v.coerceIn(10, 100)).apply()

    var customTone: String                  // auto | dark | light
        get() = sp.getString("customTone", "auto") ?: "auto"
        set(v) = sp.edit().putString("customTone", v).apply()

    /** অটো লোকেশন (ডিভাইস থেকে); পাওয়া না গেলে ঢাকা */
    var lat: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("lat", java.lang.Double.doubleToLongBits(23.8103)))
        set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToLongBits(v)).apply()
    var lng: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("lng", java.lang.Double.doubleToLongBits(90.4125)))
        set(v) = sp.edit().putLong("lng", java.lang.Double.doubleToLongBits(v)).apply()

    // ফায়ারবেজ রিয়েলটাইম ডেটাবেজ (prayer_config) থেকে আনা সর্বশেষ হিজরি কনফিগ
    var hijriAdjust: Int
        get() = sp.getInt("hijriAdj", -1).coerceIn(-5, 5)
        set(v) = sp.edit().putInt("hijriAdj", v).apply()
    var hijriOverride: Boolean
        get() = sp.getBoolean("hijriOv", false)
        set(v) = sp.edit().putBoolean("hijriOv", v).apply()
    var hijriOvDay: Int
        get() = sp.getInt("hijriOvDay", 1)
        set(v) = sp.edit().putInt("hijriOvDay", v).apply()
    var hijriOvMonthBn: String
        get() = sp.getString("hijriOvMonthBn", "") ?: ""
        set(v) = sp.edit().putString("hijriOvMonthBn", v).apply()
    var hijriOvDayEn: Int
        get() = sp.getInt("hijriOvDayEn", 1)
        set(v) = sp.edit().putInt("hijriOvDayEn", v).apply()
    var hijriOvMonthEn: String
        get() = sp.getString("hijriOvMonthEn", "") ?: ""
        set(v) = sp.edit().putString("hijriOvMonthEn", v).apply()
    var configFetchedMs: Long
        get() = sp.getLong("cfgAt", 0L)
        set(v) = sp.edit().putLong("cfgAt", v).apply()

    /** ইংরেজি তারিখ আগে: যে ডিজাইনে হিজরি তারিখ প্রথমে (বড়/বোল্ড), সেখানে ইংরেজি ও হিজরির জায়গা বদল। ডিফল্ট বন্ধ। */
    var gregFirst: Boolean
        get() = sp.getBoolean("gregFirst", false)
        set(v) = sp.edit().putBoolean("gregFirst", v).apply()

    var appDark: Boolean
        get() = sp.getBoolean("appDark", true)
        set(v) = sp.edit().putBoolean("appDark", v).apply()

    /** কাস্টম থিমে লেখা/আইকন হালকা (= গাঢ় লেখা) হবে কি না — হাবের wcIsLightTone()-এর হুবহু সূত্র। */
    fun customIsLightTone(): Boolean = when (customTone) {
        "light" -> true
        "dark" -> false
        else -> {
            val c = customBg
            (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.6
        }
    }

    companion object {
        @Volatile private var inst: Prefs? = null
        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(ctx.applicationContext.getSharedPreferences("hub", Context.MODE_PRIVATE)).also { inst = it }
        }
    }
}
