package com.gunjoron.pathey.hub

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.Html
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.gunjoron.pathey.R
import com.gunjoron.pathey.data.Bn
import com.gunjoron.pathey.data.Cities
import com.gunjoron.pathey.data.Prefs
import com.gunjoron.pathey.widget.Fonts
import com.gunjoron.pathey.widget.Look
import com.gunjoron.pathey.widget.PrayerWidgetProvider
import com.gunjoron.pathey.widget.WidgetUpdater
import com.gunjoron.pathey.widget.Variant

/**
 * উইজেট হাবের নেটিভ স্ক্রিন — HTML হাবের (Widget_Hub_v2.html) সব সেকশন একই ক্রমে ও একই রঙে।
 * WebView নেই, AndroidX নেই: শুধু প্লেইন Views — কোল্ড-স্টার্টে ১০০ মিলিসেকেন্ডের আশপাশে ওঠে।
 */
class HubScreen(private val act: Activity) {
    private val prefs = Prefs.get(act)
    private val t = Tok(prefs.appDark)
    private val handler = Handler(Looper.getMainLooper())
    private val pushWidget = Runnable { WidgetUpdater.updateAll(act) }

    private class Seg(val root: LinearLayout, val icon: ImageView, val label: TextView)

    private lateinit var preview: PreviewView
    private lateinit var chipTheme: TextView
    private lateinit var chipDesign: TextView
    private val themeBtns = LinkedHashMap<String, Seg>()
    private val modeBtns = LinkedHashMap<String, Seg>()
    private val toneBtns = LinkedHashMap<String, Seg>()
    private lateinit var nobgBox: View
    private lateinit var customBox: View
    private val dsgRows = HashMap<Int, LinearLayout>()
    private val dsgThumbs = HashMap<Int, PreviewView>()
    private val dsgChecks = HashMap<Int, FrameLayout>()
    private val dsgCheckIcons = HashMap<Int, ImageView>()

    // কাস্টম থিমের HSV অবস্থা (হাবের WC.h/s/v)
    private var ch = 217f
    private var cs = 0.5f
    private var cv = 0.23f
    private lateinit var wheel: ColorWheelView
    private lateinit var valSlider: GradientSlider
    private lateinit var opSlider: GradientSlider
    private lateinit var valTxt: TextView
    private lateinit var opTxt: TextView
    private lateinit var hexEdit: EditText
    private lateinit var hexChip: View
    private var settingHex = false

    private lateinit var cityRowSub: TextView
    private lateinit var hijriRowSub: TextView
    private lateinit var animRowSub: TextView

    private fun dp(v: Float) = Ui.dp(act, v)

    // ==========================================================================================
    fun build(): View {
        Fonts.init(act)
        loadHsv()
        styleSystemBars()

        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(t.bg)
        root.addView(buildHeader())

        val scroll = ScrollView(act)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.isFillViewport = true
        val col = Ui.vStack(act)
        col.setPadding(dp(14f), dp(4f), dp(14f), dp(28f))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(buildPreviewSection())
        col.addView(buildThemeSection())
        col.addView(buildDesignSection())
        col.addView(buildSettingsSection())
        col.addView(buildActions())

        refreshUi(pushToWidget = false)
        return root
    }

    private fun styleSystemBars() {
        act.window.setBackgroundDrawable(ColorDrawable(t.bg))
        act.window.statusBarColor = t.bg
        act.window.navigationBarColor = t.bg
        @Suppress("DEPRECATION")
        act.window.decorView.systemUiVisibility = if (t.dark) 0 else
            (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
    }

    // ------------------------------------------------------------------------------------------
    private fun buildHeader(): View {
        val wrap = Ui.hStack(act)
        wrap.setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        wrap.setBackgroundColor(t.bg)

        val markColors = if (t.dark) intArrayOf(0xFFF4F8FF.toInt(), 0xFFC9DBF5.toInt()) else intArrayOf(0xFFFFFFFF.toInt(), 0xFFE3EDFA.toInt())
        val mark = FrameLayout(act)
        mark.background = Ui.gradient(act, markColors, 16f, if (t.dark) 0x80A0C8FF.toInt() else 0xE6FFFFFF.toInt(), 1f)
        val logo = ImageView(act)
        logo.setImageResource(R.drawable.hub_mark)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        mark.addView(logo, FrameLayout.LayoutParams(dp(30f), dp(40f), Gravity.CENTER))
        wrap.addView(mark, Ui.lpw(act, 54f, 54f))

        val titles = Ui.vStack(act)
        titles.addView(Ui.text(act, "উইজেট হাব", 22f, t.ink, true))
        val sub = Ui.text(act, "হোম স্ক্রিনে নামাজের সময়সূচি উইজেট যুক্ত করুন এবং নিজের মতো করে সাজান", 14f, t.mut)
        sub.setLineSpacing(0f, 1.15f)
        titles.addView(sub)
        Ui.margin(sub, 0, dp(3f), 0, 0)
        val tl = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tl.leftMargin = dp(12f)
        wrap.addView(titles, tl)

        val tb = FrameLayout(act)
        tb.background = Ui.gradient(act, intArrayOf(t.card, t.seg), 14f, t.line, 1f)
        val ic = ImageView(act)
        ic.setImageResource(if (t.dark) R.drawable.ic_sun else R.drawable.ic_moon)
        ic.setColorFilter(if (t.dark) 0xFFFFD76A.toInt() else t.navy)
        tb.addView(ic, FrameLayout.LayoutParams(dp(23f), dp(23f), Gravity.CENTER))
        tb.contentDescription = "লাইট/ডার্ক মোড"
        tb.setOnClickListener {
            prefs.appDark = !prefs.appDark
            act.setContentView(HubScreen(act).build())
        }
        val tlp = LinearLayout.LayoutParams(dp(44f), dp(44f))
        tlp.leftMargin = dp(10f)
        wrap.addView(tb, tlp)
        return wrap
    }

    // ------------------------------------------------------------------------------------------
    private fun sectionLabel(iconRes: Int, title: String, live: Boolean = false): View {
        val row = Ui.hStack(act)
        row.addView(Ui.icon(act, iconRes, t.acc, 20f))
        val tv = Ui.text(act, title, 18f, t.mut, true)
        tv.letterSpacing = 0.02f
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(10f)
        row.addView(tv, lp)
        if (live) {
            val spacer = View(act)
            row.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
            val pill = Ui.text(act, "LIVE", 12f, t.live, true)
            pill.letterSpacing = 0.08f
            pill.setPadding(dp(9f), dp(3f), dp(9f), dp(3f))
            pill.background = Ui.shape(act, t.liveBg, 99f, t.liveBd, 1f)
            row.addView(pill)
        }
        row.setPadding(dp(2f), 0, dp(2f), dp(9f))
        return row
    }

    private fun section(): LinearLayout {
        val v = Ui.vStack(act)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(18f)
        v.layoutParams = lp
        return v
    }

    private fun hint(html: String): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        val ic = Ui.icon(act, R.drawable.ic_info, t.acc, 16f)
        val lp = LinearLayout.LayoutParams(dp(16f), dp(16f)); lp.topMargin = dp(2f); lp.rightMargin = dp(8f)
        row.addView(ic, lp)
        val tv = Ui.text(act, "", 14f, t.mut)
        tv.text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        tv.setLineSpacing(0f, 1.2f)
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setPadding(dp(3f), dp(9f), dp(3f), 0)
        return row
    }

    // ------------------------------------------------------------------------------------------
    private fun buildPreviewSection(): View {
        val s = section()
        (s.layoutParams as LinearLayout.LayoutParams).topMargin = dp(2f)
        s.addView(sectionLabel(R.drawable.ic_eye, "লাইভ প্রিভিউ", live = true))
        preview = PreviewView(act, true)
        val holder = FrameLayout(act)
        holder.setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        holder.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        s.addView(holder)

        val chips = Ui.hStack(act)
        chips.gravity = Gravity.CENTER
        chipTheme = chip(); chipDesign = chip()
        chips.addView(chipTheme)
        val l2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l2.leftMargin = dp(6f)
        chips.addView(chipDesign, l2)
        chips.setPadding(0, dp(8f), 0, 0)
        s.addView(chips)
        return s
    }

    private fun chip(): TextView {
        val c = Ui.text(act, "", 13.5f, 0xFF1E3A5F.toInt(), true)
        c.setPadding(dp(11f), dp(4f), dp(11f), dp(4f))
        c.background = Ui.shape(act, 0xFFFFFFFF.toInt(), 99f, if (t.dark) 0xFFB9C9E2.toInt() else 0xFF9FB4D6.toInt(), 1f)
        return c
    }

    // ------------------------------------------------------------------------------------------
    private fun segButton(iconRes: Int, label: String, labelSp: Float, vertical: Boolean, click: () -> Unit): Seg {
        val root = LinearLayout(act)
        root.orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER
        val ic = ImageView(act)
        ic.setImageResource(iconRes)
        val tv = Ui.text(act, label, labelSp, t.segC, true)
        tv.gravity = Gravity.CENTER
        tv.setLineSpacing(0f, 1.05f)
        root.addView(ic, LinearLayout.LayoutParams(dp(16f), dp(16f)))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (vertical) lp.topMargin = dp(4f) else lp.leftMargin = dp(7f)
        root.addView(tv, lp)
        root.setOnClickListener { click() }
        return Seg(root, ic, tv)
    }

    private fun styleSeg(s: Seg, active: Boolean) {
        if (active) {
            s.root.background = Ui.gradient(act, intArrayOf(0xFF134074.toInt(), 0xFF1D4ED8.toInt()), 12f, 0x5993C5FD, 1f)
            s.label.setTextColor(Color.WHITE); s.icon.setColorFilter(Color.WHITE)
        } else {
            s.root.background = null
            s.label.setTextColor(t.segC); s.icon.setColorFilter(t.segC)
        }
    }

    private fun styleSub(s: Seg, active: Boolean) {
        if (active) {
            s.root.background = Ui.shape(act, t.subActBg, 12f, t.subActBd, 1f)
            s.label.setTextColor(t.subActC); s.icon.setColorFilter(t.subActC)
        } else {
            s.root.background = Ui.shape(act, t.inBg, 12f, t.inBd, 1f)
            s.label.setTextColor(t.segC); s.icon.setColorFilter(t.segC)
        }
    }

    private fun buildThemeSection(): View {
        val s = section()
        s.addView(sectionLabel(R.drawable.ic_palette, "উইজেট থিম"))

        val seg = LinearLayout(act)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        seg.background = Ui.shape(act, t.segBg, 16f, t.segBd, 1f)
        fun addTheme(key: String, icon: Int, label: String) {
            val b = segButton(icon, label, 13.5f, true) { prefs.theme = key; refreshUi() }
            b.root.setPadding(dp(2f), dp(9f), dp(2f), dp(9f))
            themeBtns[key] = b
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (seg.childCount > 0) lp.leftMargin = dp(4f)
            seg.addView(b.root, lp)
        }
        addTheme("glass", R.drawable.ic_moon, "গ্লাস (ডার্ক)")
        addTheme("nobg", R.drawable.ic_crop, "ট্রান্সপারেন্ট")
        addTheme("light", R.drawable.ic_sun, "লাইট")
        addTheme("custom", R.drawable.ic_palette, "কাস্টম")
        s.addView(seg)

        // ট্রান্সপারেন্ট: ডার্ক/লাইট মোড
        val nb = Ui.vStack(act)
        val sub = Ui.hStack(act)
        fun addMode(key: String, icon: Int, label: String) {
            val b = segButton(icon, label, 15f, false) { prefs.nobgMode = key; refreshUi() }
            b.root.setPadding(dp(6f), dp(9f), dp(6f), dp(9f))
            modeBtns[key] = b
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (sub.childCount > 0) lp.leftMargin = dp(6f)
            sub.addView(b.root, lp)
        }
        addMode("dark", R.drawable.ic_contrast, "ডার্ক মোড")
        addMode("light", R.drawable.ic_sun, "লাইট মোড")
        nb.addView(sub)
        Ui.margin(sub, 0, dp(10f), 0, 0)
        nb.addView(hint("ওয়ালপেপার গাঢ় হলে <b>ডার্ক</b> (সাদা লেখা-আইকন), হালকা হলে <b>লাইট</b> (গাঢ় লেখা-আইকন) বেছে নিন।"))
        nobgBox = nb
        s.addView(nb)

        customBox = buildCustomPanel()
        s.addView(customBox)
        return s
    }

    // ------------------------------------------------------------------------------------------
    private fun subTitle(iconRes: Int, title: String, first: Boolean = false): View {
        val row = Ui.hStack(act)
        row.addView(Ui.icon(act, iconRes, t.acc, 16f))
        val tv = Ui.text(act, title, 15f, t.mut, true)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(6f)
        row.addView(tv, lp)
        row.setPadding(dp(2f), dp(if (first) 0f else 14f), 0, 0)
        return row
    }

    private fun sliderRow(label: String, slider: GradientSlider, valueView: TextView): View {
        val row = Ui.hStack(act)
        val l = Ui.text(act, label, 15f, t.mut, true)
        row.addView(l, LinearLayout.LayoutParams(dp(66f), ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(slider, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        valueView.gravity = Gravity.END
        row.addView(valueView, LinearLayout.LayoutParams(dp(42f), ViewGroup.LayoutParams.WRAP_CONTENT))
        row.setPadding(0, dp(12f), 0, 0)
        return row
    }

    private fun buildCustomPanel(): View {
        val p = Ui.vStack(act)
        p.setPadding(0, dp(12f), 0, 0)
        p.addView(subTitle(R.drawable.ic_fill, "ব্যাকগ্রাউন্ডের রঙ", true))

        wheel = ColorWheelView(act)
        wheel.ringColor = t.ring
        wheel.onPick = { h, s ->
            ch = h; cs = s
            if (cv < 0.05f) cv = 0.05f
            onColorEdited(true)
        }
        val wlp = LinearLayout.LayoutParams(dp(220f), dp(220f)); wlp.gravity = Gravity.CENTER_HORIZONTAL; wlp.topMargin = dp(8f)
        p.addView(wheel, wlp)

        valSlider = GradientSlider(act, 0, 100)
        valSlider.borderColor = t.inBd
        valSlider.onChange = { v -> cv = v / 100f; onColorEdited(true) }
        valTxt = Ui.text(act, "", 15f, t.ink, true)
        p.addView(sliderRow("উজ্জ্বলতা", valSlider, valTxt))

        opSlider = GradientSlider(act, 10, 100)
        opSlider.borderColor = t.inBd
        opSlider.colorStart = 0x1F94A3B8
        opSlider.colorEnd = 0xFF94A3B8.toInt()
        opSlider.onChange = { v -> prefs.customOpacity = v; refreshUi() }
        opTxt = Ui.text(act, "", 15f, t.ink, true)
        p.addView(sliderRow("স্বচ্ছতা", opSlider, opTxt))

        // হেক্স ইনপুট
        val hexRow = Ui.hStack(act)
        hexChip = View(act)
        hexRow.addView(hexChip, Ui.lpw(act, 38f, 38f))
        hexEdit = EditText(act)
        hexEdit.typeface = Typeface.MONOSPACE
        hexEdit.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
        hexEdit.setTextColor(t.ink)
        hexEdit.setHintTextColor(t.mut)
        hexEdit.hint = "#RRGGBB"
        hexEdit.setSingleLine(true)
        hexEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        hexEdit.filters = arrayOf(InputFilter.LengthFilter(7), InputFilter.AllCaps())
        hexEdit.setPadding(dp(12f), dp(9f), dp(12f), dp(9f))
        hexEdit.background = Ui.shape(act, t.hexBg, 12f, t.ghostBd, 1f)
        hexEdit.letterSpacing = 0.06f
        hexEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (settingHex) return
                val txt = e?.toString()?.trim().orEmpty()
                val ok = Regex("^#?([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$").matches(txt)
                hexEdit.background = Ui.shape(act, t.hexBg, 12f, if (!ok && txt.isNotEmpty()) 0xFFE11D48.toInt() else t.ghostBd, 1f)
                if (ok) {
                    var h = txt.removePrefix("#")
                    if (h.length == 3) h = h.map { "$it$it" }.joinToString("")
                    val rgb = h.toInt(16)
                    setHsvFromRgb(rgb)
                    onColorEdited(false)
                }
            }
        })
        val hlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); hlp.leftMargin = dp(10f)
        hexRow.addView(hexEdit, hlp)
        hexRow.setPadding(0, dp(12f), 0, 0)
        p.addView(hexRow)

        // প্রিসেট সোয়াচ
        val sw = Ui.hStack(act)
        sw.setPadding(0, dp(12f), 0, 0)
        for (hx in PRESETS) {
            val cell = FrameLayout(act)
            val dot = View(act)
            dot.background = Ui.shape(act, Color.parseColor(hx), 99f, t.chipRing, 2f)
            dot.contentDescription = hx
            dot.setOnClickListener { setHsvFromRgb(Color.parseColor(hx) and 0xFFFFFF); onColorEdited(true) }
            cell.addView(dot, FrameLayout.LayoutParams(dp(26f), dp(26f), Gravity.CENTER))
            sw.addView(cell, LinearLayout.LayoutParams(0, dp(30f), 1f))
        }
        p.addView(sw)

        // টোন
        p.addView(subTitle(R.drawable.ic_text, "লেখা ও আইকনের রঙ"))
        val tone = Ui.hStack(act)
        fun addTone(key: String, icon: Int, label: String) {
            val b = segButton(icon, label, 15f, false) { prefs.customTone = key; refreshUi() }
            b.root.setPadding(dp(4f), dp(9f), dp(4f), dp(9f))
            toneBtns[key] = b
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (tone.childCount > 0) lp.leftMargin = dp(6f)
            tone.addView(b.root, lp)
        }
        addTone("auto", R.drawable.ic_sparkle, "অটো")
        addTone("dark", R.drawable.ic_contrast, "ডার্ক")
        addTone("light", R.drawable.ic_sun, "লাইট")
        p.addView(tone)
        Ui.margin(tone, 0, dp(8f), 0, 0)
        p.addView(hint("<b>অটো</b> রঙ দেখে নিজেই সাদা/গাঢ় বেছে নেয়। <b>ডার্ক</b> = সাদা লেখা-আইকন (গাঢ় ব্যাকগ্রাউন্ডে), <b>লাইট</b> = গাঢ় লেখা-আইকন (হালকা ব্যাকগ্রাউন্ডে)।"))

        val reset = ghostButton(R.drawable.ic_refresh, "রঙ রিসেট করুন") {
            setHsvFromRgb(0x1E293B); prefs.customOpacity = 90; prefs.customTone = "auto"
            onColorEdited(true)
        }
        p.addView(reset)
        Ui.margin(reset, 0, dp(10f), 0, 0)
        p.setPadding(0, dp(12f), 0, 0)
        return p
    }

    // ------------------------------------------------------------------------------------------
    private fun buildDesignSection(): View {
        val s = section()
        s.addView(sectionLabel(R.drawable.ic_add_box, "উইজেট ডিজাইন নির্বাচন"))
        val titles = arrayOf("ডিজাইন ১", "ডিজাইন ২", "ডিজাইন ৩", "ডিজাইন ৪ · মিনিমাল", "ডিজাইন ৫ · ড্যাশবোর্ড", "ডিজাইন ৬ · সান-আর্ক", "ডিজাইন ৭ · বেন্টো", "ডিজাইন ৮ · স্ট্যাক")
        val subs = arrayOf(
            "তারিখ, টাইমার, সাহরী-ইফতার ও পাঁচ ওয়াক্তের নামাজের সময়",
            "তারিখ ও পাঁচ ওয়াক্তের নামাজের সময়",
            "টাইমার, তারিখ ও বর্তমান ওয়াক্তের নামাজ",
            "বড় পাতলা ঘড়ি, চলমান ওয়াক্ত ও বাকি সময়, প্রগ্রেস বার — প্রিমিয়াম মিনিমাল লুক",
            "সেকেন্ডসহ ঘড়ি, ইংরেজি-হিজরি-বাংলা তিন তারিখ, সাহরি-ইফতার, চলমান ওয়াক্ত ও পাঁচ ওয়াক্ত — সব তথ্য এক নজরে",
            "সূর্যোদয় থেকে সূর্যাস্তের আর্কে সূর্যের অবস্থান, ঘড়ি, চলমান ওয়াক্ত ও পাঁচ ওয়াক্তের স্ট্রিপ",
            "লোগো ও আইকনসহ বেন্টো টাইল: বড় ঘড়ি, সূর্যোদয়-সেহরি-ইফতার আইকন, চলমান ওয়াক্ত ও পাঁচ ওয়াক্ত",
            "ওপর-নিচ সাজানো ঘড়ি, তিন তারিখ, তিন আইকন, চলমান ওয়াক্তের প্রগ্রেস ও পাঁচ ওয়াক্ত"
        )
        for (n in 1..8) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(10f), dp(10f), dp(14f), dp(10f))
            val th = PreviewView(act, false)
            dsgThumbs[n] = th
            val thHolder = FrameLayout(act)
            thHolder.addView(th, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(thHolder, LinearLayout.LayoutParams(dp(118f), ViewGroup.LayoutParams.WRAP_CONTENT))

            val txt = Ui.vStack(act)
            txt.addView(Ui.text(act, titles[n - 1], 16f, t.ink, true))
            val st = Ui.text(act, subs[n - 1], 13f, t.mut)
            st.setLineSpacing(0f, 1.2f)
            txt.addView(st)
            Ui.margin(st, 0, dp(3f), 0, 0)
            val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            tlp.leftMargin = dp(14f); tlp.rightMargin = dp(10f)
            row.addView(txt, tlp)

            val check = FrameLayout(act)
            val ci = ImageView(act); ci.setImageResource(R.drawable.ic_check)
            check.addView(ci, FrameLayout.LayoutParams(dp(14f), dp(14f), Gravity.CENTER))
            dsgChecks[n] = check; dsgCheckIcons[n] = ci
            row.addView(check, Ui.lpw(act, 26f, 26f))

            row.setOnClickListener { prefs.design = n; refreshUi() }
            dsgRows[n] = row
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (n > 1) lp.topMargin = dp(10f)
            s.addView(row, lp)
        }
        s.addView(hint("ডিজাইন নির্বাচনের পর উপরের থিম থেকে ভেরিয়েন্ট (গ্লাস, লাইট, ট্রান্সপারেন্ট বা কাস্টম) বেছে নিন।"))
        return s
    }

    // ------------------------------------------------------------------------------------------
    private fun settingRow(iconRes: Int, title: String, onClick: () -> Unit): Pair<View, TextView> {
        val row = Ui.hStack(act)
        row.setPadding(dp(12f), dp(11f), dp(12f), dp(11f))
        row.background = Ui.shape(act, t.inBg, 16f, t.inBd, 1f)
        val ico = FrameLayout(act)
        ico.background = Ui.shape(act, t.subActBg, 12f)
        val iv = ImageView(act); iv.setImageResource(iconRes); iv.setColorFilter(t.acc)
        ico.addView(iv, FrameLayout.LayoutParams(dp(18f), dp(18f), Gravity.CENTER))
        row.addView(ico, Ui.lpw(act, 38f, 38f))
        val col = Ui.vStack(act)
        col.addView(Ui.text(act, title, 17f, t.ink, true))
        val sub = Ui.text(act, "", 15f, t.mut)
        col.addView(sub)
        Ui.margin(sub, 0, dp(1f), 0, 0)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.leftMargin = dp(12f)
        row.addView(col, lp)
        row.setOnClickListener { onClick() }
        return Pair(row, sub)
    }

    private fun buildSettingsSection(): View {
        val s = section()
        s.addView(sectionLabel(R.drawable.ic_location, "সময় ও তারিখ সেটিং"))

        val (cityRow, citySub) = settingRow(R.drawable.ic_location, "লোকেশন (নামাজের সময়ের জন্য)") { showCityDialog() }
        cityRowSub = citySub
        s.addView(cityRow)

        val (hijriRow, hijriSub) = settingRow(R.drawable.ic_calendar, "হিজরি তারিখ সমন্বয়") { showHijriDialog() }
        hijriRowSub = hijriSub
        s.addView(hijriRow)
        Ui.margin(hijriRow, 0, dp(8f), 0, 0)

        val (animRow, animSub) = settingRow(R.drawable.ic_sun, "আনলকে সূর্য/চাঁদের অ্যানিমেশন (ডিজাইন ৬)") {
            prefs.anim = !prefs.anim
            updateSettingSubs()
        }
        animRowSub = animSub
        s.addView(animRow)
        Ui.margin(animRow, 0, dp(8f), 0, 0)
        s.addView(hint("ফোন আনলক করলে সূর্য/চাঁদ আর্কের শুরু থেকে এখনকার জায়গা পর্যন্ত ১ সেকেন্ডের মতো চলে। ব্যাটারি খরচ নগণ্য; চাইলে বন্ধ করা যায়।"))
        updateSettingSubs()
        return s
    }

    private fun updateSettingSubs() {
        cityRowSub.text = Cities.LIST[prefs.cityIndex].name
        animRowSub.text = if (prefs.anim) "চালু" else "বন্ধ"
        val a = prefs.hijriAdjust
        hijriRowSub.text = when (a) { 0 -> "০ দিন (সৌদি/উম্মুল কুরা)"; else -> (if (a > 0) "+" else "−") + Bn.digits(kotlin.math.abs(a)) + " দিন" }
    }

    private fun dialog(): AlertDialog.Builder = AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun showCityDialog() {
        val names = Cities.LIST.map { it.name }.toTypedArray()
        dialog().setTitle("লোকেশন বেছে নিন")
            .setSingleChoiceItems(names, prefs.cityIndex) { d, which ->
                prefs.cityIndex = which
                d.dismiss()
                updateSettingSubs()
                afterDataSettingChanged()
            }.setNegativeButton("বাতিল", null).show()
    }

    private fun showHijriDialog() {
        val items = arrayOf("−২ দিন", "−১ দিন (বাংলাদেশে সাধারণত)", "০ দিন (সৌদি/উম্মুল কুরা)", "+১ দিন", "+২ দিন")
        dialog().setTitle("হিজরি তারিখ সমন্বয়")
            .setSingleChoiceItems(items, prefs.hijriAdjust + 2) { d, which ->
                prefs.hijriAdjust = which - 2
                d.dismiss()
                updateSettingSubs()
                afterDataSettingChanged()
            }.setNegativeButton("বাতিল", null).show()
    }

    private fun afterDataSettingChanged() {
        preview.invalidateSnapshot()
        dsgThumbs.values.forEach { it.invalidateSnapshot() }
        handler.removeCallbacks(pushWidget); handler.postDelayed(pushWidget, 100)
    }

    // ------------------------------------------------------------------------------------------
    private fun ghostButton(iconRes: Int, label: String, click: () -> Unit): View {
        val b = Ui.hStack(act)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
        b.background = Ui.shape(act, t.inBg, 16f, t.ghostBd, 1f)
        b.addView(Ui.icon(act, iconRes, t.ghostC, 18f))
        val tv = Ui.text(act, label, 16f, t.ghostC, true)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(8f)
        b.addView(tv, lp)
        b.setOnClickListener { click() }
        b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return b
    }

    private fun buildActions(): View {
        val s = section()
        s.setPadding(0, dp(4f), 0, 0)
        val cta = Ui.hStack(act)
        cta.gravity = Gravity.CENTER
        cta.setPadding(dp(14f), dp(15f), dp(14f), dp(15f))
        cta.background = Ui.gradient(act, intArrayOf(0xFF134074.toInt(), 0xFF1D4ED8.toInt(), 0xFF3B82F6.toInt()), 18f, 0x6693C5FD, 1f)
        cta.addView(Ui.icon(act, R.drawable.ic_add_box, Color.WHITE, 20f))
        val tv = Ui.text(act, "হোম স্ক্রিনে উইজেট যুক্ত করুন", 17f, Color.WHITE, true)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = dp(9f)
        cta.addView(tv, lp)
        cta.setOnClickListener { pinWidget() }
        s.addView(cta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val ghost = ghostButton(R.drawable.ic_refresh, "উইজেট রিফ্রেশ করুন") {
            WidgetUpdater.updateAll(act)
            Toast.makeText(act, "উইজেট রিফ্রেশ করা হয়েছে", Toast.LENGTH_SHORT).show()
        }
        s.addView(ghost)
        Ui.margin(ghost, 0, dp(10f), 0, 0)
        return s
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(act)
        val provider = ComponentName(act, PrayerWidgetProvider::class.java)
        if (mgr.isRequestPinAppWidgetSupported) {
            val cb = PendingIntent.getBroadcast(
                act, 2,
                Intent(act, PrayerWidgetProvider::class.java).setAction(WidgetUpdater.ACTION_REFRESH),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            mgr.requestPinAppWidget(provider, null, cb)
        } else {
            Toast.makeText(
                act, "আপনার লঞ্চার সরাসরি যুক্ত করা সাপোর্ট করে না — হোম স্ক্রিনে ফাঁকা জায়গায় ধরে রেখে \"উইজেট\" → \"পাথেয়\" বেছে নিন।",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ==========================================================================================
    //  কাস্টম রঙের অবস্থা
    // ==========================================================================================
    private fun loadHsv() {
        val a = FloatArray(3)
        Color.colorToHSV(prefs.customBg or 0xFF000000.toInt(), a)
        ch = a[0]; cs = a[1]; cv = a[2]
    }

    private fun setHsvFromRgb(rgb: Int) {
        val a = FloatArray(3)
        Color.colorToHSV(rgb or 0xFF000000.toInt(), a)
        ch = a[0]; cs = a[1]; cv = a[2]
    }

    private fun currentRgb(): Int = Color.HSVToColor(floatArrayOf(ch, cs, cv)) and 0xFFFFFF

    private fun onColorEdited(updateHexText: Boolean) {
        prefs.customBg = currentRgb()
        refreshUi(updateHexText = updateHexText)
    }

    // ==========================================================================================
    //  সব UI-র অবস্থা এক জায়গা থেকে
    // ==========================================================================================
    private fun refreshUi(pushToWidget: Boolean = true, updateHexText: Boolean = true) {
        val look = Look.from(prefs)
        preview.look = look

        val names = mapOf(
            "glass" to "গ্লাস (ডার্ক)", "nobg" to (if (prefs.nobgMode == "light") "ট্রান্সপারেন্ট · লাইট" else "ট্রান্সপারেন্ট · ডার্ক"),
            "light" to "লাইট", "custom" to ("কাস্টম · " + String.format("#%06X", prefs.customBg))
        )
        chipTheme.text = names[prefs.theme] ?: ""
        chipDesign.text = "ডিজাইন " + Bn.digits(prefs.design)

        for ((k, b) in themeBtns) styleSeg(b, k == prefs.theme)
        nobgBox.visibility = if (prefs.theme == "nobg") View.VISIBLE else View.GONE
        for ((k, b) in modeBtns) styleSub(b, k == prefs.nobgMode)
        customBox.visibility = if (prefs.theme == "custom") View.VISIBLE else View.GONE
        if (prefs.theme == "custom") refreshCustom(updateHexText)

        for (n in 1..8) {
            dsgThumbs[n]?.look = Look.from(prefs, design = n)
            val on = n == prefs.design
            dsgRows[n]?.background = if (on)
                Ui.shape(act, t.subActBg, 18f, t.subActBd, 1.5f)
            else Ui.shape(act, t.inBg, 18f, t.inBd, 1f)
            dsgChecks[n]?.background = if (on) Ui.shape(act, 0xFF1D4ED8.toInt(), 99f, 0xFF3B82F6.toInt(), 1.5f)
                else Ui.shape(act, 0, 99f, t.inHv, 1.5f)
            dsgCheckIcons[n]?.setColorFilter(if (on) Color.WHITE else Color.TRANSPARENT)
        }

        if (pushToWidget) {
            handler.removeCallbacks(pushWidget)
            handler.postDelayed(pushWidget, 150)
        }
    }

    private fun refreshCustom(updateHexText: Boolean) {
        val rgb = currentRgb()
        val argb = rgb or 0xFF000000.toInt()
        wheel.hue = ch; wheel.sat = cs; wheel.knobColor = argb; wheel.invalidate()
        valSlider.value = Math.round(cv * 100)
        valSlider.colorStart = Color.BLACK
        valSlider.colorEnd = Color.HSVToColor(floatArrayOf(ch, cs, 1f))
        valTxt.text = Bn.digits(Math.round(cv * 100)) + "%"
        opSlider.value = prefs.customOpacity
        opTxt.text = Bn.digits(prefs.customOpacity) + "%"
        hexChip.background = Ui.shape(act, argb, 12f, t.chipRing, 2f)
        if (updateHexText) {
            settingHex = true
            hexEdit.setText(String.format("#%06X", rgb))
            hexEdit.setSelection(hexEdit.text.length)
            hexEdit.background = Ui.shape(act, t.hexBg, 12f, t.ghostBd, 1f)
            settingHex = false
        }
        for ((k, b) in toneBtns) styleSub(b, k == prefs.customTone)
    }

    companion object {
        private val PRESETS = arrayOf("#0F172A", "#111A2E", "#1E3A8A", "#0F766E", "#14532D", "#7F1D1D", "#581C87", "#F8FAFC", "#FEF3C7", "#DBEAFE")
    }
}
