package com.gunjoron.pathey.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.SystemClock
import android.widget.RemoteViews
import com.gunjoron.pathey.MainActivity
import com.gunjoron.pathey.R
import com.gunjoron.pathey.data.Prefs
import com.gunjoron.pathey.data.Snapshot
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * হোমস্ক্রিন উইজেট আপডেট।
 *
 * গতির কৌশল:
 *  • সব স্ট্যাটিক/ধীর-বদলানো অংশ একবারই একটা বিটম্যাপে আঁকা হয় (কয়েক মিলিসেকেন্ড)।
 *  • ঘড়ির সেকেন্ড/মিনিট ও কাউন্টডাউন লঞ্চারের নিজস্ব TextClock/Chronometer টিক করে — আমাদের প্রসেস
 *    প্রতি সেকেন্ডে জাগে না, ব্যাটারি প্রায় শূন্য খরচ।
 *  • শুধু ওয়াক্তের সীমানা, দুপুর ১২টা ও মধ্যরাতে একটাই অ্যালার্ম — তখন উইজেট আবার আঁকা হয়।
 */
object WidgetUpdater {
    const val ACTION_TICK = "com.gunjoron.pathey.widgethub.ACTION_TICK"
    const val ACTION_REFRESH = "com.gunjoron.pathey.widgethub.ACTION_REFRESH"
    private const val BITMAP_W = 1100f

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
        if (ids.isEmpty()) { cancel(ctx); return }
        update(ctx, mgr, ids)
    }

    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val app = ctx.applicationContext
        Fonts.init(app)
        val look = Look.from(Prefs.get(app))
        val snap = Snapshot.build(app)
        for (id in ids) {
            try {
                mgr.updateAppWidget(id, build(app, mgr, id, look, snap))
            } catch (t: Throwable) {
                // একটা উইজেটের সমস্যা বাকিগুলো আটকাবে না
            }
        }
        // ঘণ্টা:মিনিট বিটম্যাপে আঁকা, তাই প্রতি মিনিটের শুরুতে (অথবা ওয়াক্ত বদলের সময়, যেটা আগে) নতুন করে আঁকা
        val nextMinute = (snap.nowMs / 60000L + 1) * 60000L + 150L
        schedule(app, minOf(snap.nextChangeMs, nextMinute))
    }

    /** লঞ্চারের জানানো আনুমানিক মাপ (px)। শুধু "প্রস্থ-সীমিত না উচ্চতা-সীমিত" বাছতে লাগে — সঠিক হওয়া জরুরি নয়। */
    private fun sizePx(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Float, Float> {
        val o = mgr.getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        // কিছু হুয়াওয়ে/অনার লঞ্চার প্রস্থ ~১৪% বেশি জানায় (পরীক্ষায় দেখা গেছে)
        val m = Build.MANUFACTURER.lowercase()
        val fw = if (m.contains("huawei") || m.contains("honor")) 0.875f else 1f
        return Pair(wDp * fw, hDp.toFloat())
    }

    private val LAYOUT_W = intArrayOf(0, R.layout.widget_d1_w, R.layout.widget_d2_w, R.layout.widget_d3_w, R.layout.widget_d4_w, R.layout.widget_d5_w, R.layout.widget_d6_w)
    private val LAYOUT_H = intArrayOf(0, R.layout.widget_d1_h, R.layout.widget_d2_h, R.layout.widget_d3_h, R.layout.widget_d4_h, R.layout.widget_d5_h, R.layout.widget_d6_h)

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, look: Look, snap: Snapshot): RemoteViews {
        val d = look.design
        // বিটম্যাপ সবসময় ডিজাইনের নিজস্ব অনুপাতে (কার্ড + চারপাশে PAD) — তাই কখনো চ্যাপ্টা/টানা হয় না।
        val regionW = WidgetRenderer.cardW(d) + 2 * WidgetRenderer.PAD
        val regionH = WidgetRenderer.cardH(d) + 2 * WidgetRenderer.PAD
        val k = BITMAP_W / regionW
        val bw = (regionW * k).roundToInt(); val bh = (regionH * k).roundToInt()
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val ov = WidgetRenderer.draw(ctx, cv, bw.toFloat(), bh.toFloat(), look, snap, false, snap.nowMs)

        val (wv, hv) = sizePx(ctx, mgr, id)
        val heightLimited = wv / hv >= regionW / regionH
        val rv = RemoteViews(ctx.packageName, (if (heightLimited) LAYOUT_H else LAYOUT_W)[d])
        rv.setImageViewBitmap(R.id.bg, bmp)

        // সেকেন্ডের লাইভ ঘড়ি (ডিজাইন ১ ও ৫: "ss", ডিজাইন ৩: ":ss")
        val sec = if (d == 3) ov.s3 else ov.ss
        if (sec != null) rv.setTextColor(R.id.tc_ss, sec.color)

        if (ov.chrono != null) {
            rv.setTextColor(R.id.ch_main, ov.chrono!!.color)
            val elapsedNow = SystemClock.elapsedRealtime()
            val countDown = look.design == 3 || !snap.running
            val base: Long
            val secs: Long
            if (countDown) {
                val remain = snap.periodEndMs - snap.nowMs
                base = elapsedNow + remain
                secs = remain / 1000
            } else {
                val el = snap.nowMs - snap.periodStartMs
                base = elapsedNow - el
                secs = el / 1000
            }
            // হাবের প্রিভিউর মতো সবসময় "00:20:59" ফরম্যাট (Chronometer নিজে ঘণ্টা না থাকলে "20:59" দেখায়)
            val fmt = when {
                abs(secs) < 3600 -> "00:%s"
                abs(secs) < 36000 -> "0%s"
                else -> "%s"
            }
            rv.setChronometerCountDown(R.id.ch_main, countDown)
            rv.setChronometer(R.id.ch_main, base, fmt, true)
        }

        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, open)
        return rv
    }

    fun schedule(ctx: Context, atMs: Long) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = tickIntent(ctx)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        } catch (_: SecurityException) {
            // এক্সাক্ট-অ্যালার্ম অনুমতি বাতিল হলে: ইনএক্সাক্টে ফলব্যাক
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, tickIntent(ctx))
            } catch (_: Throwable) {}
        }
    }

    fun cancel(ctx: Context) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(ctx))
        } catch (_: Throwable) {}
    }

    private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, PrayerWidgetProvider::class.java).setAction(ACTION_TICK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
