package com.gunjoron.pathey.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.util.TypedValue
import android.widget.RemoteViews
import com.gunjoron.pathey.MainActivity
import com.gunjoron.pathey.R
import com.gunjoron.pathey.data.Prefs
import com.gunjoron.pathey.data.Snapshot
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * হোমস্ক্রিন উইজেট আপডেট।
 *
 * গতির কৌশল:
 *  • সব স্ট্যাটিক/ধীর-বদলানো অংশ একবারই একটা বিটম্যাপে আঁকা হয় (কয়েক মিলিসেকেন্ড)।
 *  • ঘড়ির সেকেন্ড/মিনিট ও কাউন্টডাউন লঞ্চারের নিজস্ব TextClock/Chronometer টিক করে — আমাদের প্রসেস
 *    প্রতি সেকেন্ডে জাগে না, ব্যাটারি প্রায় শূন্য খরচ।
 *  • শুধু ওয়াক্তের সীমানা, দুপুর ১২টা ও মধ্যরাতে একটাই অ্যালার্ম — তখন উইজেট আবার আঁকা হয়।
 */
object WidgetUpdater {
    const val ACTION_TICK = "com.gunjoron.pathey.widgethub.ACTION_TICK"
    const val ACTION_REFRESH = "com.gunjoron.pathey.widgethub.ACTION_REFRESH"
    private const val MAX_BITMAP_W = 1400f

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, PrayerWidgetProvider::class.java))
        if (ids.isEmpty()) { cancel(ctx); return }
        update(ctx, mgr, ids)
    }

    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val app = ctx.applicationContext
        Fonts.init(app)
        val look = Look.from(Prefs.get(app))
        val snap = Snapshot.build(app)
        for (id in ids) {
            try {
                mgr.updateAppWidget(id, build(app, mgr, id, look, snap))
            } catch (t: Throwable) {
                // একটা উইজেটের সমস্যা বাকিগুলো আটকাবে না
            }
        }
        schedule(app, snap.nextChangeMs)
    }

    private fun sizePx(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
        val o = mgr.getAppWidgetOptions(id)
        val density = ctx.resources.displayMetrics.density
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        return Pair((wDp * density).roundToInt(), (hDp * density).roundToInt())
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, look: Look, snap: Snapshot): RemoteViews {
        val (wv, hv) = sizePx(ctx, mgr, id)
        val k = if (wv > MAX_BITMAP_W) MAX_BITMAP_W / wv else 1f
        val bmp = Bitmap.createBitmap(maxOf(1, (wv * k).toInt()), maxOf(1, (hv * k).toInt()), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(k, k)
        val ov = WidgetRenderer.draw(ctx, cv, wv.toFloat(), hv.toFloat(), look, snap, false, snap.nowMs)

        val rv = RemoteViews(ctx.packageName, R.layout.widget_main)
        rv.setImageViewBitmap(R.id.bg, bmp)

        val lay = WidgetRenderer.layout(look.design, wv.toFloat(), hv.toFloat())
        place(rv, R.id.slot_hh, R.id.tc_hh, ov.hh, Fonts.bebas, lay)
        place(rv, R.id.slot_mm, R.id.tc_mm, ov.mm, Fonts.bebas, lay)
        place(rv, R.id.slot_ss, R.id.tc_ss, ov.ss, Fonts.bebas, lay)
        place(rv, R.id.slot_hm, R.id.tc_hm, ov.hm, Fonts.serif, lay)
        place(rv, R.id.slot_s3, R.id.tc_s3, ov.s3, Fonts.serif, lay)
        place(rv, R.id.slot_ch, R.id.ch_main, ov.chrono, Fonts.bebas, lay)

        if (ov.chrono != null) {
            val elapsedNow = SystemClock.elapsedRealtime()
            val countDown = look.design == 3 || !snap.running
            val base: Long
            val secs: Long
            if (countDown) {
                val remain = snap.periodEndMs - snap.nowMs
                base = elapsedNow + remain
                secs = remain / 1000
            } else {
                val el = snap.nowMs - snap.periodStartMs
                base = elapsedNow - el
                secs = el / 1000
            }
            // হাবের প্রিভিউর মতো সবসময় "00:20:59" ফরম্যাট (Chronometer নিজে ঘণ্টা না থাকলে "20:59" দেখায়)
            val fmt = when {
                abs(secs) < 3600 -> "00:%s"
                abs(secs) < 36000 -> "0%s"
                else -> "%s"
            }
            rv.setChronometerCountDown(R.id.ch_main, countDown)
            rv.setChronometer(R.id.ch_main, base, fmt, true)
        }

        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, open)
        return rv
    }

    /** ওভারলে ভিউ ডিজাইনের হুবহু জায়গায় বসানো: বেসলাইন = y, বাম = x। */
    private fun place(rv: RemoteViews, slotId: Int, viewId: Int, spec: TextSpec?, tf: Typeface, lay: WidgetRenderer.Layout) {
        if (spec == null) { rv.setViewVisibility(slotId, android.view.View.GONE); return }
        rv.setViewVisibility(slotId, android.view.View.VISIBLE)
        val px = spec.size * lay.s
        val fm = Paint().also { it.typeface = tf; it.textSize = px }.fontMetricsInt
        val left = (lay.ox + spec.x * lay.s).roundToInt()
        val top = (lay.oy + spec.y * lay.s + fm.ascent).roundToInt().coerceAtLeast(0)
        rv.setTextViewTextSize(viewId, TypedValue.COMPLEX_UNIT_PX, px)
        rv.setTextColor(viewId, spec.color)
        rv.setViewPadding(slotId, left, top, 0, 0)
    }

    fun schedule(ctx: Context, atMs: Long) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = tickIntent(ctx)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        } catch (_: SecurityException) {
            // এক্সাক্ট-অ্যালার্ম অনুমতি বাতিল হলে: ইনএক্সাক্টে ফলব্যাক
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, tickIntent(ctx))
            } catch (_: Throwable) {}
        }
    }

    fun cancel(ctx: Context) {
        try {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(ctx))
        } catch (_: Throwable) {}
    }

    private fun tickIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, PrayerWidgetProvider::class.java).setAction(ACTION_TICK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
