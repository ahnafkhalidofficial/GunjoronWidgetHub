package com.gunjoron.pathey.hub.ui

import android.content.Context
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.View
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.widget.WidgetRenderer
import com.gunjoron.pathey.widget.theme.Look
import com.gunjoron.pathey.widget.theme.Variant

/**
 * আসল উইজেটের রেন্ডারার দিয়েই আঁকা লাইভ প্রিভিউ/থাম্বনেইল — তাই হোমস্ক্রিনের উইজেটের সাথে হুবহু মেলে।
 * ticking = true হলে প্রতি সেকেন্ডে ঘড়ি ও কাউন্টার চলে (শুধু স্ক্রিনে দেখা গেলে)।
 */
class PreviewView(ctx: Context, private val ticking: Boolean) : View(ctx) {
    var look: Look = Look(1, Variant.GLASS, 0)
        set(v) { val relayout = field.design != v.design; field = v; if (relayout) requestLayout(); invalidate() }

    private var snap: Snapshot? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            val now = System.currentTimeMillis()
            handler.postDelayed(this, 1000L - (now % 1000L) + 5L)
        }
    }

    fun invalidateSnapshot() { snap = null; invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val d = look.design
        val cw = WidgetRenderer.cardW(d) + 2 * WidgetRenderer.PAD
        val cs = snap
        val ch = WidgetRenderer.cardH(d, cs != null && WidgetRenderer.isCompact(d, cs)) + 2 * WidgetRenderer.PAD
        setMeasuredDimension(w, (w * ch / cw).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.currentTimeMillis()
        var s = snap
        if (s == null || now >= s.nextChangeMs) {
            val was = s != null && WidgetRenderer.isCompact(look.design, s)
            s = Snapshot.build(context, now); snap = s
            if (was != WidgetRenderer.isCompact(look.design, s)) { requestLayout(); invalidate(); return }
        }
        WidgetRenderer.draw(context, canvas, width.toFloat(), height.toFloat(), look, s, true, now)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (ticking) { handler.removeCallbacks(tick); handler.post(tick) }
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (!ticking) return
        handler.removeCallbacks(tick)
        if (isVisible) handler.post(tick)
    }
}
