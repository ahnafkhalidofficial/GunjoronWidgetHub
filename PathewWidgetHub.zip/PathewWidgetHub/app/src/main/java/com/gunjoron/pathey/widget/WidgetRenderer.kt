package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.pathey.data.Bn
import com.gunjoron.pathey.data.Snapshot
import java.util.Calendar
import kotlin.math.min

/** ওভারলে (লাইভ) টেক্সটের জায়গা — ডিজাইন-ইউনিটে, কার্ডের বাম-উপরের কোণ থেকে; y = বেসলাইন। */
class TextSpec(val x: Float, val y: Float, val size: Float, val color: Int)

class Overlay {
    var ss: TextSpec? = null
    var s3: TextSpec? = null      // ডিজাইন ৩: ":ss"
    var chrono: TextSpec? = null  // কাউন্টডাউন / কাউন্ট-আপ
}

/**
 * পুরো উইজেট একটাই জায়গায় আঁকা হয় — হোমস্ক্রিন উইজেট (বিটম্যাপ) এবং হাবের লাইভ প্রিভিউ, দুটোতেই
 * একই কোড, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু একরকম।
 *
 * সব মাপ/অবস্থান আপনার ডিজাইন শিটের SVG ইউনিটে (যেমন ডিজাইন ১ কার্ড = ১১১৪.২৫ × ৬০৮.১৬)।
 * live = true  → ঘড়ি ও কাউন্টার সরাসরি আঁকা হয় (প্রিভিউ, প্রতি সেকেন্ডে রিড্র)।
 * live = false → ঘড়ি/কাউন্টারের জায়গায় ফাঁকা রেখে Overlay ফেরত দেয় (হোমস্ক্রিনে TextClock/Chronometer বসে)।
 */
object WidgetRenderer {
    const val PAD = 23f            // কাস্টম প্যানেল কার্ডের চেয়ে যতটা বড়
    private const val PANEL_R = 48f

    fun cardW(d: Int) = when (d) { 3 -> 981.41f; 4, 5, 6, 7, 8 -> 1000f; else -> 1114.25f }
    fun cardH(d: Int) = when (d) { 1 -> 608.16f; 2 -> 445.15f; 3 -> 465.35f; 4 -> 448f; 5 -> 560f; 6 -> 586f; 7 -> 570f; else -> 576f }
    private fun cardRx(d: Int) = when (d) { 1 -> 50.17f; 2 -> 42.93f; 3 -> 41.19f; 4, 5, 6, 7, 8 -> 56f; else -> 50f }

    class Layout(val s: Float, val ox: Float, val oy: Float)

    /** w×h এলাকায় কার্ড (প্যানেলসহ) মাঝখানে, অনুপাত ঠিক রেখে। */
    fun layout(d: Int, w: Float, h: Float): Layout {
        val cw = cardW(d) + 2 * PAD
        val ch = cardH(d) + 2 * PAD
        val s = min(w / cw, h / ch)
        return Layout(s, (w - cardW(d) * s) / 2f, (h - cardH(d) * s) / 2f)
    }

    // ডিজাইন ১/২: ৫ ওয়াক্তের কলামের কেন্দ্র (ফজর, যোহর, আসর, মাগরিব, ইশা)
    private val COL_CX = floatArrayOf(137.35f, 342.5f, 542.72f, 771.11f, 984.43f)
    private const val HL_W = 185.78f
    private const val HL_H = 145.83f
    private const val HL_RX = 21.19f
    private const val HL_NAME_DY = -5.82f
    private const val HL_TIME_DY = -6.21f

    private fun formatHms(totalMs: Long): String {
        val t = (if (totalMs < 0) 0 else totalMs) / 1000
        val h = t / 3600; val m = (t / 60) % 60; val s = t % 60
        return Bn.pad2(h.toInt()) + ":" + Bn.pad2(m.toInt()) + ":" + Bn.pad2(s.toInt())
    }

    fun draw(
        ctx: Context, c: Canvas, w: Float, h: Float,
        look: Look, snap: Snapshot, live: Boolean, nowMs: Long
    ): Overlay {
        Fonts.init(ctx)
        val d = look.design
        val cw = cardW(d); val chh = cardH(d)
        val lay = layout(d, w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.isLinearText = true
        p.isFilterBitmap = true

        c.save()
        c.translate(lay.ox, lay.oy)
        c.scale(lay.s, lay.s)

        // ১) কাস্টম থিমের পেছনের রঙিন প্যানেল
        if (look.panelColor != 0) {
            p.style = Paint.Style.FILL; p.color = soften(look.panelColor)
            c.drawRoundRect(-PAD, -PAD, cw + PAD, chh + PAD, PANEL_R, PANEL_R, p)
            glass(c, p, -PAD, -PAD, cw + PAD, chh + PAD, PANEL_R)
        }

        // ২) কার্ড (গ্লাস/লাইট) — ট্রান্সপারেন্টে নেই
        val cardFill: Int; val cardStroke: Int
        if (d >= 4) { val pl = Palettes.ofMin(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else if (d == 3) { val pl = Palettes.of3(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else { val pl = Palettes.of12(d, look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        if (cardFill != 0) {
            val rx = cardRx(d)
            p.style = Paint.Style.FILL; p.color = soften(cardFill)
            c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
            if (cardStroke != 0) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = cardStroke
                c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
                p.style = Paint.Style.FILL
            }
            if (look.panelColor == 0) glass(c, p, 0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx)
        }

        // ৩) স্ট্যাটিক আর্ট (লোগো, আইকন-পিল, ঘড়ির টাইল, ডিভাইডার…)
        // (আগের রঙ/স্বচ্ছতা পেইন্টে থেকে গেলে আইকন-লোগোও ফিকে হয়ে যেত — তাই রিসেট)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        if (d <= 2) drawArt(c, p, Art.get(ctx, d, look.variant), d, cw, chh)

        // ৪) ডায়নামিক টেক্সট
        val ov = Overlay()
        if (d == 8) drawD8(c, p, look, snap, live, nowMs, ov, Art.get(ctx, 1, look.variant)) else if (d == 7) drawD7(c, p, look, snap, live, nowMs, ov, Art.get(ctx, 1, look.variant)) else if (d == 6) drawD6(ctx, c, p, look, snap, live, nowMs, ov) else if (d == 5) drawD5(c, p, look, snap, live, nowMs, ov) else if (d == 4) drawMin(c, p, look, snap, live, nowMs, ov) else if (d == 3) drawD3(c, p, look, snap, live, nowMs, ov) else drawD12(c, p, d, look, snap, live, nowMs, ov)

        c.restore()
        return ov
    }

    // ------------------------------------------------------------------------------------------
    /** সূর্যোদয় ও ইফতার (সূর্যাস্ত) পিল সামান্য ডানে — আর্টের ওই দুই টুকরো আলাদা সরিয়ে আঁকা। */
    private const val PILL_SHIFT = 14f
    private val SUNRISE_R = Rect(820, 25, 1072, 175)
    private val IFTAR_R = Rect(806, 222, 1060, 358)

    private fun drawArt(c: Canvas, p: Paint, art: Bitmap, d: Int, cw: Float, chh: Float) {
        c.save()
        c.clipOutRect(SUNRISE_R.left.toFloat(), SUNRISE_R.top.toFloat(), SUNRISE_R.right.toFloat(), SUNRISE_R.bottom.toFloat())
        if (d == 1) c.clipOutRect(IFTAR_R.left.toFloat(), IFTAR_R.top.toFloat(), IFTAR_R.right.toFloat(), IFTAR_R.bottom.toFloat())
        c.drawBitmap(art, null, RectF(0f, 0f, cw, chh), p)
        c.restore()
        fun piece(r: Rect) = c.drawBitmap(art, r, RectF(r.left + PILL_SHIFT, r.top.toFloat(), r.right + PILL_SHIFT, r.bottom.toFloat()), p)
        piece(SUNRISE_R)
        if (d == 1) piece(IFTAR_R)
    }

    /** কার্ড/প্যানেলের রঙের অস্বচ্ছতা সামান্য কমানো — যাতে পেছনের ওয়ালপেপার হালকা ঝাপসা দেখা যায়। */
    private const val GLASS_ALPHA = 0.85f
    private fun soften(color: Int): Int {
        val a = ((color ushr 24) * GLASS_ALPHA).toInt().coerceIn(0, 255)
        return (a shl 24) or (color and 0xFFFFFF)
    }

    /** কোনো গ্রেডিয়েন্ট নয় — শুধু খুব হালকা ফ্রস্ট-দানা, যাতে ঝাপসা কাচের অনুভূতি আসে। */
    private val grain: Bitmap by lazy {
        val n = 96
        val px = IntArray(n * n)
        val r = java.util.Random(7)
        for (i in px.indices) {
            val a = r.nextInt(15)                       // ০–১৪ / ২৫৫ — হালকা
            px[i] = (a shl 24) or (if (r.nextBoolean()) 0xFFFFFF else 0x000000)
        }
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun glass(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float) {
        p.style = Paint.Style.FILL
        p.shader = BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        p.shader = null
    }

    private fun measure(p: Paint, s: String, tf: Typeface, size: Float): Float {
        p.typeface = tf; p.textSize = size
        return p.measureText(s)
    }

    private fun text(c: Canvas, p: Paint, s: String, x: Float, y: Float, size: Float, color: Int,
                     tf: Typeface, align: Paint.Align = Paint.Align.LEFT) {
        p.style = Paint.Style.FILL
        p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
        c.drawText(s, x, y, p)
        p.textAlign = Paint.Align.LEFT
    }

    // ------------------------------------------------------------------------------------------
    private fun drawD12(c: Canvas, p: Paint, d: Int, look: Look, snap: Snapshot, live: Boolean,
                        nowMs: Long, ov: Overlay) {
        val pal = Palettes.of12(d, look.variant)
        val yOff = if (d == 1) 0f else -160f   // নিচের অংশ ডিজাইন ২-এ ১৬০ ইউনিট উপরে

        // ---- হিজরি দিন (বড়) + হিজরি মাস-সাল
        val dayX = 216.32f
        text(c, p, snap.hijriDay, dayX, 103.57f, 110f, pal.day, Fonts.bold)
        val dayAdv = measure(p, snap.hijriDay, Fonts.bold, 110f)
        val hx = dayX + dayAdv + 10.53f
        var hs = 55f
        val hw = measure(p, snap.hijriMonthYear, Fonts.bold, hs)
        val hAvail = 825f - hx
        if (hw > hAvail) hs = 55f * hAvail / hw
        text(c, p, snap.hijriMonthYear, hx, 102.29f, hs, pal.hijri, Fonts.bold)

        // ---- ইংরেজি তারিখ | বাংলা তারিখ (মাঝে ডিভাইডার)
        var ds = 52f
        val g1 = snap.gregorianLine; val g2 = snap.banglaLine
        var w1 = measure(p, g1, Fonts.bold, ds); var w2 = measure(p, g2, Fonts.bold, ds)
        val total = w1 + DATE_SEP + w2
        val maxW = 612f
        val f = if (total > maxW) maxW / total else 1f
        if (f < 1f) { ds *= f; w1 *= f; w2 *= f }
        text(c, p, g1, dayX, 162.99f, ds, pal.date, Fonts.bold)
        // দাগ = লেখার রঙ, একটু ফিকে; দুই পাশে ফাঁক যাতে আলাদা বোঝা যায়
        p.style = Paint.Style.FILL; p.color = (pal.date and 0xFFFFFF) or 0xBF000000.toInt()
        val dvx = dayX + w1 + (DATE_SEP - 2.2f) / 2f * f
        c.drawRect(dvx, 123.4f, dvx + 2.2f * f, 123.4f + 45.19f, p)
        text(c, p, g2, dayX + w1 + DATE_SEP * f, 162.99f, ds, pal.date, Fonts.bold)

        // ---- সূর্যোদয় পিল
        text(c, p, "সূর্যোদয়", 1006.18f + PILL_SHIFT, 89.51f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.sunrise, 1005.07f + PILL_SHIFT, 146.66f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

        // ---- ডিজাইন ১: ঘড়ি ও সাহরী/ইফতার
        if (d == 1) {
            text(c, p, "সেহরি", 698.77f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.sehri, 703.71f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)
            text(c, p, "ইফতার", 995.9f + PILL_SHIFT, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.iftar, 992.11f + PILL_SHIFT, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

            val ampm = if (snap.isPm) "PM" else "AM"
            text(c, p, ampm, 424.41f, 299.25f, 40f, pal.pm, Fonts.bebas)
            // ঘণ্টা ও মিনিট বিটম্যাপেই (ডিজাইনের ফন্টে) আঁকা — প্রতি মিনিটের শুরুতে উইজেট নতুন করে আঁকা হয়।
            // শুধু সেকেন্ড লাইভ (TextClock), কারণ প্রতি সেকেন্ডে অ্যাপ জাগানো যাবে না।
            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
            text(c, p, if (hh < 10) "0$hh" else "$hh", 65.32f, 332.48f, 136.17f, pal.clock, Fonts.bebas)
            text(c, p, pad2a(cal.get(Calendar.MINUTE)), 218.54f, 334.48f, 125f, pal.clock, Fonts.bebas)
            if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), 353.03f, 340.13f, 65f, pal.clock, Fonts.bebas)
            else ov.ss = TextSpec(0f, 0f, 0f, pal.clock)
        }

        // ---- পাঁচ ওয়াক্ত
        val nameY = 448.74f + yOff
        val timeY = 502.65f + yOff
        val hlY = 381.16f + yOff
        for (i in 0 until 5) {
            val cx = COL_CX[i]
            val hl = (snap.current == i)
            if (hl) {
                p.style = Paint.Style.FILL; p.color = pal.hlFill
                c.drawRoundRect(cx - HL_W / 2f, hlY, cx + HL_W / 2f, hlY + HL_H, HL_RX, HL_RX, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, nameY + (if (hl) HL_NAME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.name, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, timeY + (if (hl) HL_TIME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.time, Fonts.bold, Paint.Align.CENTER)
        }

        // ---- নিচের লাইন: "<ওয়াক্ত> -এর সময় অতিবাহিত: 00:20:59"
        val nowY = 577.67f + yOff
        val prefix = if (snap.running) snap.currentName + " -এর সময় অতিবাহিত:"
                     else snap.currentName + " -এর সময় শুরু হতে বাকি:"
        var ps = 50f; val ds2 = 40f
        val digitsText = if (live) formatHms(
            if (snap.running) nowMs - snap.periodStartMs else snap.periodEndMs - nowMs) else ""
        // অঙ্ক সবসময় একই জায়গায় (লাইভ Chronometer-এর বক্স স্থির), লেবেল তার বাঁ-পাশে ডান-সারিবদ্ধ
        val labelEnd = CH12_X - CH12_GAP
        var pw = measure(p, prefix, Fonts.regular, ps)
        val maxLabel = labelEnd - 40f
        if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel }
        text(c, p, prefix, labelEnd - pw, nowY, ps, pal.now, Fonts.regular)
        if (live) text(c, p, digitsText, CH12_X, nowY, ds2, pal.nowTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.nowTime)
    }

    // লাইভ কাউন্টারের স্থির বাম-কিনারা (ডিজাইন-ইউনিট) ও লেবেলের ফাঁক
    const val CH12_X = 710f; const val CH12_GAP = 10f
    const val CH3_X = 548f
    private const val DATE_SEP = 30f      // ইংরেজি ও বাংলা তারিখের মাঝে মোট ফাঁক (দাগসহ)
    private const val CLOCK_X = 85f; private const val CLOCK_W = 621f; private const val CLOCK_BASE = 200f
    private const val SIDE_CX = 838f; private const val AMPM_BASE = 80f; private const val SEC_BASE = 197f

    private fun cwOf(d: Int) = cardW(d)
    private fun pad2a(n: Int) = if (n < 10) "0$n" else n.toString()

    // ------------------------------------------------------------------------------------------
    private fun drawD3(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean,
                       nowMs: Long, ov: Overlay) {
        val pal = Palettes.of3(look.variant)
        val cw = cardW(3)
        val rule = (pal.month and 0xFFFFFF) or 0xBF000000.toInt()   // লেখার রঙ, সামান্য ফিকে
        val ruleW = 1.8f

        // ১) বড় ঘড়ি (বাঁয়ে), AM/PM + সেকেন্ড (ডানে, একটার ওপর আরেকটা)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val clockSize = CLOCK_W / measure(p, "00:00", Fonts.clockBold, 100f) * 100f   // সবচেয়ে চওড়া "00:00" ধরে মাপ
        // ঘণ্টা | কোলন | মিনিট আলাদা আঁকা — কোলন ঠিক অঙ্কের উচ্চতার মাঝখানে (ফন্টে সেটা নিচু বসে)
        p.typeface = Fonts.clockBold; p.textSize = clockSize
        val rb = Rect(); p.getTextBounds("0", 0, 1, rb)
        val digitMid = (rb.top + rb.bottom) / 2f
        val cb = Rect(); p.getTextBounds(":", 0, 1, cb)
        val colonMid = (cb.top + cb.bottom) / 2f
        val colonDy = digitMid - colonMid
        val hhS = hm.substring(0, 2); val mmS = hm.substring(3)
        val hhW = measure(p, hhS, Fonts.clockBold, clockSize)
        val colonW = measure(p, ":", Fonts.clockBold, clockSize)
        text(c, p, hhS, CLOCK_X, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, ":", CLOCK_X + hhW, CLOCK_BASE + colonDy, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, mmS, CLOCK_X + hhW + colonW, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, if (snap.isPm) "PM" else "AM", SIDE_CX, AMPM_BASE, 80f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), SIDE_CX, SEC_BASE, 130f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        else ov.s3 = TextSpec(0f, 0f, 0f, pal.clock)

        // ২) তিন কলামের তারিখ: ইংরেজি | হিজরি | বাংলা — সমান তিন ভাগ
        class Col(val day: String, val month: String, val year: String)
        val cols = arrayOf(
            Col(snap.gregDay, snap.gregMonth, snap.gregYear),
            Col(snap.hijriDay, snap.hijriMonth, snap.hijriYear),
            Col(snap.banglaDay, snap.banglaMonth, snap.banglaYear)
        )
        val colW = cw / 3f
        p.style = Paint.Style.FILL; p.color = rule
        for (i in 1..2) c.drawRect(colW * i - ruleW / 2f, 248f, colW * i + ruleW / 2f, 399f, p)
        for ((i, col) in cols.withIndex()) {
            val cx = colW * (i + 0.5f)
            text(c, p, col.day, cx, 312f, 100f, pal.day, Fonts.bold, Paint.Align.CENTER)
            val maxW = colW - 36f
            var ms = 52f
            val mw = measure(p, col.month, Fonts.regular, ms)
            if (mw > maxW) ms *= maxW / mw
            text(c, p, col.month, cx, 360f, ms, pal.month, Fonts.regular, Paint.Align.CENTER)
            text(c, p, col.year, cx, 392f, 44f, pal.month, Fonts.regular, Paint.Align.CENTER)
        }

        // ৩) নিচের লাইন: ── ইশা [চলছে] সময় বাকি: 01:54:56 ──
        //    অঙ্ক স্থির জায়গায় (লাইভ Chronometer), বাকি সব তার বাঁয়ে ডান-সারিবদ্ধ; দুই পাশে রেখা।
        val label = if (snap.running) "সময় বাকি:" else "শুরু হতে বাকি:"
        val lw = measure(p, label, Fonts.regular, 27f)
        val nameW = measure(p, snap.currentName, Fonts.regular, 36f)
        val badgeW = 70.25f
        var x = CH3_X - 8f - lw
        text(c, p, label, x, 436f, 27f, pal.subLabel, Fonts.regular)
        if (snap.running) {
            x -= 8f + badgeW
            p.style = Paint.Style.FILL; p.color = 0xFFFCB010.toInt()
            c.drawRoundRect(x, 412f, x + badgeW, 440.05f, 14.02f, 14.02f, p)
            text(c, p, "চলছে", x + 10.34f, 435f, 26.95f, pal.badgeText, Fonts.regular)
            p.style = Paint.Style.FILL; p.color = 0xFFFF0000.toInt()
            c.drawCircle(x + 60.98f, 426.4f, 3.15f, p)
        }
        x -= 6f + nameW
        text(c, p, snap.currentName, x, 437f, 36f, pal.prayer, Fonts.regular)
        val digitsText = if (live) formatHms(snap.periodEndMs - nowMs) else ""
        if (live) text(c, p, digitsText, CH3_X, 436f, 34f, pal.subTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.subTime)
        // রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(24f, 426f - ruleW / 2f, x - 10f, 426f + ruleW / 2f, p)
        c.drawRect(CH3_X + 108f + 10f, 426f - ruleW / 2f, cw - 24f, 426f + ruleW / 2f, p)
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৪ (মিনিমাল) ও ৫ (স্ট্রিপ) — কোনো আর্ট/লাইভ ওভারলে নেই; সবকিছু বিটম্যাপে, প্রতি মিনিটে নতুন।
    // ------------------------------------------------------------------------------------------
    /**
     * "০১:২৩:৫৬ বাকি" — অঙ্কগুলো লাইভ কাউন্টডাউন (প্রিভিউতে আঁকা, হোমস্ক্রিনে Chronometer), "বাকি" বিটম্যাপে।
     * dr = অঙ্ক-বক্সের ডান কিনারা (স্থির; genlayout.py-র REM বক্সের সাথে মেলাতে হবে), লেবেল তার ১০ ইউনিট ডানে।
     */
    private fun remLine(c: Canvas, p: Paint, ov: Overlay, live: Boolean, snap: Snapshot, nowMs: Long,
                        dr: Float, base: Float, dsz: Float, lsz: Float, dcol: Int, lcol: Int) {
        if (live) text(c, p, formatHms(snap.periodEndMs - nowMs), dr, base, dsz, dcol, Fonts.bebas, Paint.Align.RIGHT)
        else ov.chrono = TextSpec(0f, 0f, 0f, dcol)
        text(c, p, "বাকি", dr + 10f, base, lsz, lcol, Fonts.regular)
    }

    private val WEEKDAYS = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")
    private fun weekday(nowMs: Long): String {
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        return WEEKDAYS[cal.get(Calendar.DAY_OF_WEEK) - 1]
    }

    /** পাতলা ঘড়ি: ঘণ্টা | কোলন (অঙ্কের মাঝ বরাবর) | মিনিট। ফেরত: মোট প্রস্থ। */
    private fun slimClock(c: Canvas, p: Paint, hm: String, x: Float, base: Float, size: Float, color: Int): Float {
        p.typeface = Fonts.outfit; p.textSize = size
        val r0 = Rect(); p.getTextBounds("0", 0, 1, r0)
        val r1 = Rect(); p.getTextBounds(":", 0, 1, r1)
        val dy = (r0.top + r0.bottom) / 2f - (r1.top + r1.bottom) / 2f
        val a = hm.substring(0, 2); val b = hm.substring(3)
        val aw = measure(p, a, Fonts.outfit, size); val cw = measure(p, ":", Fonts.outfit, size)
        val bw = measure(p, b, Fonts.outfit, size)
        text(c, p, a, x, base, size, color, Fonts.outfit)
        text(c, p, ":", x + aw, base + dy, size, color, Fonts.outfit)
        text(c, p, b, x + aw + cw, base, size, color, Fonts.outfit)
        return aw + cw + bw
    }

    private fun bar(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
        p.style = Paint.Style.FILL; p.color = track
        c.drawRoundRect(x0, y, x1, y + h, h / 2f, h / 2f, p)
        val fx = x0 + (x1 - x0) * frac.coerceIn(0f, 1f)
        if (fx - x0 > h) { p.color = fill; c.drawRoundRect(x0, y, fx, y + h, h / 2f, h / 2f, p) }
    }

    private fun drawMin(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(4)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val ampm = if (snap.isPm) "PM" else "AM"
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val L = 40f; val R = cw - 40f
        val colW = (R - L) / 5f

        // ওপরের সারি: ইংরেজি তারিখ (বাঁয়ে) | হিজরি তারিখ (ডানে)
        text(c, p, snap.gregorianLine, L, 80f, 37f, m.secondary, Fonts.regular)
        text(c, p, snap.hijriDay + " " + snap.hijriMonthYear, R, 80f, 37f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        // বড় পাতলা ঘড়ি + AM/PM
        val w = slimClock(c, p, hm, L - 6f, 250f, 188f, m.primary)
        text(c, p, ampm, L - 6f + w + 18f, 250f, 44f, m.accent, Fonts.outfit)
        // ডানে চলমান ওয়াক্ত
        text(c, p, if (snap.running) "চলমান ওয়াক্ত" else "পরবর্তী ওয়াক্ত", R, 130f, 33f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        text(c, p, snap.currentName, R, 200f, 84f, m.accent, Fonts.bold, Paint.Align.RIGHT)
        remLine(c, p, ov, live, snap, nowMs, 898f, 254f, 44f, 36f, m.primary, m.primary)
        // প্রগ্রেস বার
        bar(c, p, L, R, 296f, 8f, frac, m.track, m.accent)
        // পাঁচ ওয়াক্ত
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = snap.current == i
            text(c, p, Bn.PRAYER_NAMES[i], cx, 360f, 36f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 414f, 46f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৫ (ড্যাশবোর্ড): সেকেন্ডসহ ঘড়ি · তিন তারিখ (ইংরেজি/হিজরি/বাংলা) · সাহরি-ইফতার · চলমান ওয়াক্ত · পাঁচ ওয়াক্ত
    // শুধু সেকেন্ডটা লাইভ (TextClock "ss"); বাকি সব বিটম্যাপে।
    // ------------------------------------------------------------------------------------------
    private const val D5_CLOCK_W = 380f; private const val D5_BASE = 198f
    const val D5_SIDE_CX = 480f
    private const val D5_DIV = 548f; private const val D5_RX = 572f

    private fun fit(p: Paint, s: String, tf: Typeface, size: Float, maxW: Float): Float {
        val w = measure(p, s, tf, size)
        return if (w > maxW) size * maxW / w else size
    }

    private fun drawD5(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(5)
        val L = 40f; val R = cw - 40f
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000

        // ১) ঘড়ি (বাঁয়ে) + AM/PM ও সেকেন্ড (একটার নিচে আরেকটা)
        val clockSize = D5_CLOCK_W / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hm, L - 4f, D5_BASE, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", D5_SIDE_CX, 122f, 38f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), D5_SIDE_CX, 196f, 66f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ২) ডানে তিন তারিখ — লেবেল + তারিখ
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, 44f, D5_DIV + 1f, 258f, p)
        val dates = arrayOf(
            "ইংরেজি" to snap.gregorianLine,
            "হিজরি" to (snap.hijriDay + " " + snap.hijriMonthYear),
            "বাংলা" to snap.banglaLine
        )
        for ((i, dv) in dates.withIndex()) {
            val y0 = 66f + 72f * i
            text(c, p, dv.first, D5_RX, y0, 28f, m.accent, Fonts.regular)
            val sz = fit(p, dv.second, Fonts.bold, 39f, R - D5_RX)
            text(c, p, dv.second, D5_RX, y0 + 38f, sz, m.primary, Fonts.bold)
        }

        // ৩) সেহরি / ইফতার টাইল + চলমান ওয়াক্ত
        val tw = 238f; val ty = 282f; val th = 104f
        val tiles = arrayOf("সেহরি" to snap.sehri, "ইফতার" to snap.iftar)
        for ((i, t) in tiles.withIndex()) {
            val x0 = L + (tw + 14f) * i
            p.style = Paint.Style.FILL; p.color = m.track
            c.drawRoundRect(x0, ty, x0 + tw, ty + th, 28f, 28f, p)
            text(c, p, t.first, x0 + 26f, ty + 38f, 31f, m.secondary, Fonts.regular)
            text(c, p, t.second, x0 + 26f, ty + 88f, 48f, m.primary, Fonts.bold)
        }
        text(c, p, if (snap.running) "চলমান ওয়াক্ত" else "পরবর্তী ওয়াক্ত", D5_RX, ty + 32f, 29f, m.secondary, Fonts.regular)
        text(c, p, snap.currentName, D5_RX, ty + 76f, 52f, m.accent, Fonts.bold)
        remLine(c, p, ov, live, snap, nowMs, 912f, ty + 76f, 32f, 30f, m.primary, m.primary)
        bar(c, p, D5_RX, R, ty + 92f, 8f, frac, m.track, m.accent)

        // ৪) পাঁচ ওয়াক্ত; চলমানটা হাইলাইটে
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) {
                p.style = Paint.Style.FILL; p.color = (m.accent and 0xFFFFFF) or 0x33000000
                c.drawRoundRect(cx - colW / 2f + 5f, 410f, cx + colW / 2f - 5f, 542f, 28f, 28f, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, 460f, 35f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 513f, 46f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৬ (সান-আর্ক): সূর্যোদয় থেকে সূর্যাস্তের আর্ক, তাতে সূর্যের বর্তমান অবস্থান; ভেতরে ঘড়ি;
    // দুই প্রান্তে সূর্যোদয়/সূর্যাস্ত, মাঝে চলমান ওয়াক্ত; নিচে পাঁচ ওয়াক্তের স্ট্রিপ।
    // ------------------------------------------------------------------------------------------
    private fun onColor(bg: Int): Int {
        val r = (bg shr 16) and 255; val g = (bg shr 8) and 255; val b = bg and 255
        return if (0.299f * r + 0.587f * g + 0.114f * b > 150f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
    }

    /** ৪-কোনা ছোট তারা (ভেক্টর-আইকনের মতো) */
    private fun sparkle(c: Canvas, p: Paint, x: Float, y: Float, r: Float, color: Int) {
        val k = r * 0.3f
        val path = Path()
        path.moveTo(x, y - r); path.lineTo(x + k, y - k); path.lineTo(x + r, y); path.lineTo(x + k, y + k)
        path.lineTo(x, y + r); path.lineTo(x - k, y + k); path.lineTo(x - r, y); path.lineTo(x - k, y - k)
        path.close()
        p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    /** সূর্য: গোল চাকতি + ৮টা গোল-মাথা রশ্মি (ফ্ল্যাট ভেক্টর আইকন) */
    private fun sun(c: Canvas, p: Paint, cx: Float, cy: Float, color: Int, halo: Boolean) {
        p.style = Paint.Style.FILL
        if (halo) {   // লাইট থিমে আভা/ছায়া নেই
            p.color = (color and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, 44f, p)
            p.color = (color and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, 33f, p)
        }
        p.color = color; c.drawCircle(cx, cy, 14f, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.5f; p.color = color
        for (i in 0 until 8) {
            val t = Math.PI / 4.0 * i
            val ca = Math.cos(t).toFloat(); val sa = Math.sin(t).toFloat()
            c.drawLine(cx + ca * 21f, cy + sa * 21f, cx + ca * 28.5f, cy + sa * 28.5f, p)
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
    }

    /** চাঁদ: মসৃণ অর্ধচন্দ্র (বড় বৃত্ত − সামান্য হেলানো ছোট বৃত্ত) + দুটো ছোট তারা (ফ্ল্যাট ভেক্টর আইকন) */
    private fun moon(c: Canvas, p: Paint, cx: Float, cy: Float, rad: Float, glow: Int, body: Int, halo: Boolean) {
        p.style = Paint.Style.FILL
        if (halo) {   // লাইট থিমে আভা/ছায়া নেই
            p.color = (glow and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, rad + 22f, p)
            p.color = (glow and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, rad + 11f, p)
        }
        val d = rad * 0.40f; val r2 = rad * 0.86f
        val phi = Math.toRadians(-38.0)
        val x = (d * d + rad * rad - r2 * r2) / (2f * d)
        val y = Math.sqrt((rad * rad - x * x).toDouble()).toFloat()
        val aR = Math.atan2(y.toDouble(), x.toDouble())
        val bR = Math.atan2(y.toDouble(), (x - d).toDouble())
        val a = Math.toDegrees(aR).toFloat(); val b2 = Math.toDegrees(bR).toFloat(); val ph = Math.toDegrees(phi).toFloat()
        val ox = d * Math.cos(phi).toFloat(); val oy = d * Math.sin(phi).toFloat()
        val path = Path()
        path.moveTo(cx + rad * Math.cos(phi - aR).toFloat(), cy + rad * Math.sin(phi - aR).toFloat())
        path.arcTo(RectF(cx - rad, cy - rad, cx + rad, cy + rad), ph - a, -(360f - 2f * a))
        path.arcTo(RectF(cx + ox - r2, cy + oy - r2, cx + ox + r2, cy + oy + r2), ph + b2, 360f - 2f * b2)
        path.close()
        p.color = body
        c.drawPath(path, p)
        sparkle(c, p, cx + rad * 0.78f, cy - rad * 0.60f, rad * 0.26f, body)
        sparkle(c, p, cx + rad * 1.02f, cy + rad * 0.10f, rad * 0.16f, body)
    }

    private fun lum(col: Int): Float =
        0.299f * ((col shr 16) and 255) + 0.587f * ((col shr 8) and 255) + 0.114f * (col and 255)

    private fun drawD6(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(6)
        val L = 40f; val R = cw - 40f
        val cx = cw / 2f; val cy = 334f; val rad = 215f
        val rule = (m.primary and 0xFFFFFF) or 0x40000000
        val lightText = lum(m.primary) > 150f

        // ওপরের মাঝখানে লোগো: গোল বৃত্তের ভেতরে লোগোর সাদা পাথ
        val lr = 36f; val ly = 52f
        p.style = Paint.Style.FILL; p.color = (m.primary and 0xFFFFFF) or 0x14000000
        c.drawCircle(cx, ly, lr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = m.primary
        c.drawCircle(cx, ly, lr, p)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        val lg = Art.logoPath(ctx, lightText)
        val lh = 48f; val lw = lh * lg.width / lg.height
        c.drawBitmap(lg, null, RectF(cx - lw / 2f, ly - lh / 2f, cx + lw / 2f, ly + lh / 2f), p)

        // ওপরের কোণে তিন তারিখ: বাঁয়ে ইংরেজি + বাংলা, ডানে হিজরি (দুই লাইনে)
        text(c, p, snap.gregorianLine, L, 62f, 35f, m.secondary, Fonts.regular)
        text(c, p, snap.banglaLine, L, 106f, 35f, m.secondary, Fonts.regular)
        text(c, p, snap.hijriDay + " " + snap.hijriMonth, R, 62f, 35f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        text(c, p, snap.hijriYear + " হিজরি", R, 106f, 35f, m.secondary, Fonts.regular, Paint.Align.RIGHT)

        // আর্ক: দিনে সূর্যোদয় → সূর্যাস্ত (সূর্য, বাঁ থেকে ডানে); রাতে সূর্যাস্ত → পরদিন সূর্যোদয় (চাঁদ, ডান থেকে বাঁয়ে)
        val isDay = snap.sunsetMs > snap.sunriseMs && nowMs >= snap.sunriseMs && nowMs < snap.sunsetMs
        val a0 = if (isDay) snap.sunriseMs else snap.nightStartMs
        val a1 = if (isDay) snap.sunsetMs else snap.nightEndMs
        val f = if (a1 > a0) ((nowMs - a0).toFloat() / (a1 - a0)).coerceIn(0f, 1f) else 0f
        val nightCol = if (lightText) 0xFFC9D6FF.toInt() else 0xFF3B4F8A.toInt()
        val bodyCol = if (isDay) m.accent else nightCol   // আর্কের উজ্জ্বল অংশের রঙ
        val oval = RectF(cx - rad, cy - rad, cx + rad, cy + rad)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 5f; p.color = m.track
        c.drawArc(oval, 180f, 180f, false, p)
        // উজ্জ্বল অংশ আইকনের কিনারায় থামে (আইকনের ভেতর দিয়ে দাগ যাবে না)
        val gap = Math.toDegrees(32.0 / rad).toFloat()
        val sweep = 180f * f - gap
        if (sweep > 1f) {
            p.strokeWidth = 8f; p.color = bodyCol
            // দিনে বাঁ থেকে ডানে; রাতে ডান (সূর্যাস্ত) থেকে বাঁয়ে (সূর্যোদয়ের দিকে)
            if (isDay) c.drawArc(oval, 180f, sweep, false, p)
            else c.drawArc(oval, 360f - 180f * f + gap, sweep, false, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(L, cy - 1f, R, cy + 1f, p)
        // সূর্য / চাঁদ
        val ang = if (isDay) Math.PI * (1.0 + f) else Math.PI * (2.0 - f)
        val sx = cx + rad * Math.cos(ang).toFloat(); val sy = cy + rad * Math.sin(ang).toFloat()
        if (isDay) sun(c, p, sx, sy, m.accent, lightText)
        else moon(c, p, sx, sy, 24f, nightCol, if (lightText) 0xFFF4EEDC.toInt() else 0xFF2F4378.toInt(), lightText)

        // আর্কের ভেতরে ঘড়ি + AM/PM
        val clockSize = 122f
        val cwid = measure(p, hmOf(nowMs).substring(0, 2), Fonts.outfit, clockSize) * 2f + measure(p, ":", Fonts.outfit, clockSize)
        slimClock(c, p, hmOf(nowMs), cx - cwid / 2f, 282f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", cx, 320f, 32f, m.accent, Fonts.outfit, Paint.Align.CENTER)

        // ভূমি-রেখার নিচে: সূর্যোদয় | চলমান ওয়াক্ত + বাকি সময় (লাইভ) | সূর্যাস্ত
        text(c, p, "সূর্যোদয়", cx - rad, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.CENTER)
        text(c, p, snap.sunrise, cx - rad, 432f, 50f, m.primary, Fonts.bold, Paint.Align.CENTER)
        text(c, p, "সূর্যাস্ত", cx + rad, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.CENTER)
        text(c, p, snap.iftar, cx + rad, 432f, 50f, m.primary, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.currentName, cx, 394f, 56f, m.accent, Fonts.bold, Paint.Align.CENTER)
        remLine(c, p, ov, live, snap, nowMs, 520f, 434f, 34f, 32f, m.primary, m.primary)

        // নিচে পাঁচ ওয়াক্তের স্ট্রিপ (নাম ওপরে, সময় নিচে)
        p.style = Paint.Style.FILL; p.color = m.track
        c.drawRoundRect(L, 460f, R, 568f, 34f, 34f, p)
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cc = L + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) {
                p.style = Paint.Style.FILL; p.color = m.accent
                c.drawRoundRect(cc - colW / 2f + 4f, 466f, cc + colW / 2f - 4f, 562f, 30f, 30f, p)
            }
            val fg1 = if (on) onColor(m.accent) else m.secondary
            val fg2 = if (on) onColor(m.accent) else m.primary
            text(c, p, Bn.PRAYER_NAMES[i], cc, 504f, 31f, fg1, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cc, 548f, 40f, fg2, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৭ ও ৮ — ডিজাইন ১-এর আইকন-মেডালিয়ন (সূর্যোদয়, সেহরি, ইফতার) ও লোগো, ডিজাইন ১-এর আর্ট থেকে নেওয়া।
    // ------------------------------------------------------------------------------------------
    private val MEDAL_SRC = arrayOf(
        Rect(832, 52, 925, 145),     // সূর্যোদয়
        Rect(533, 239, 627, 333),    // সেহরি
        Rect(819, 239, 913, 333)     // ইফতার
    )
    private val LOGO_SRC = Rect(56, 42, 197, 185)

    private fun medal(c: Canvas, p: Paint, art: Bitmap, i: Int, cx: Float, cy: Float, dia: Float) {
        val r = dia / 2f
        c.save()
        val path = Path(); path.addCircle(cx, cy, r * 0.985f, Path.Direction.CW)
        c.clipPath(path)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        c.drawBitmap(art, MEDAL_SRC[i], RectF(cx - r, cy - r, cx + r, cy + r), p)
        c.restore()
    }

    private fun hmOf(nowMs: Long): String {
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        return (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
    }

    private fun tile(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float, color: Int, edge: Int = 0) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        if (edge != 0) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = edge
            c.drawRoundRect(l + 0.75f, t + 0.75f, r - 0.75f, b - 0.75f, rx, rx, p)
            p.style = Paint.Style.FILL
        }
    }

    /** প্রগ্রেস বার + শেষ প্রান্তে গোল নব */
    private fun barK(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
        bar(c, p, x0, x1, y, h, frac, track, fill)
        val kx = (x0 + (x1 - x0) * frac.coerceIn(0f, 1f)).coerceIn(x0 + h, x1 - h)
        p.style = Paint.Style.FILL
        p.color = (fill and 0xFFFFFF) or 0x44000000; c.drawCircle(kx, y + h / 2f, h * 2.1f, p)
        p.color = fill; c.drawCircle(kx, y + h / 2f, h * 1.15f, p)
    }

    /** ডিজাইন ৭ (বেন্টো): হেডার (লোগো, হিজরি, ইংরেজি | বাংলা, চলমান ওয়াক্ত) · বড় ঘড়ি-টাইল · তিন আইকন-টাইল · পাঁচ ওয়াক্ত */
    private fun drawD7(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(7)
        val L = 36f; val R = cw - 36f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x80000000.toInt()
        val edge = (m.primary and 0xFFFFFF) or 0x1F000000

        // হেডার: লোগো · হিজরি · ইংরেজি | বাংলা · ডানে চলমান-ওয়াক্তের ক্যাপসুল
        c.drawBitmap(art, LOGO_SRC, RectF(L, 24f, L + 70f, 24f + 71f), p)
        val hx = L + 70f + 20f
        val hijri = snap.hijriDay + " " + snap.hijriMonthYear
        val capLabel = if (snap.running) "চলমান" else "পরবর্তী"
        val capLW = measure(p, capLabel, Fonts.regular, 30f)
        val capNW = measure(p, snap.currentName, Fonts.bold, 40f)
        val capW = 26f + capLW + 12f + capNW + 26f
        val cx0 = R - capW
        tile(c, p, cx0, 36f, R, 92f, 28f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
        text(c, p, capLabel, cx0 + 26f, 75f, 30f, m.secondary, Fonts.regular)
        text(c, p, snap.currentName, cx0 + 26f + capLW + 12f, 77f, 40f, m.accent, Fonts.bold)
        val hSz = fit(p, hijri, Fonts.bold, 44f, cx0 - 16f - hx)
        text(c, p, hijri, hx, 60f, hSz, m.primary, Fonts.bold)
        val g1 = snap.gregorianLine; val g2 = snap.banglaLine
        var ds = 33f
        val tw = measure(p, g1, Fonts.regular, ds) + 34f + measure(p, g2, Fonts.regular, ds)
        val maxW = cx0 - 16f - hx
        if (tw > maxW) ds *= maxW / tw
        val w1 = measure(p, g1, Fonts.regular, ds)
        text(c, p, g1, hx, 98f, ds, m.secondary, Fonts.regular)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(hx + w1 + 16f, 72f, hx + w1 + 18f, 104f, p)
        text(c, p, g2, hx + w1 + 34f, 98f, ds, m.secondary, Fonts.regular)

        // বড় ঘড়ি-টাইল: বার · AM/PM · ঘড়ি · প্রগ্রেস · ওয়াক্ত + বাকি সময় (লাইভ)
        val ty0 = 126f; val ty1 = 404f; val tr = 522f
        tile(c, p, L, ty0, tr, ty1, 34f, m.track, edge)
        text(c, p, weekday(nowMs), L + 28f, 170f, 31f, m.secondary, Fonts.regular)
        text(c, p, if (snap.isPm) "PM" else "AM", tr - 28f, 170f, 36f, m.accent, Fonts.outfit, Paint.Align.RIGHT)
        val clockSize = 372f / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hmOf(nowMs), L + 24f, 282f, clockSize, m.primary)
        barK(c, p, L + 30f, tr - 30f, 314f, 8f, frac, m.track, m.accent)
        text(c, p, snap.currentName, L + 28f, 372f, 42f, m.accent, Fonts.bold)
        remLine(c, p, ov, live, snap, nowMs, 435f, 372f, 38f, 35f, m.primary, m.primary)

        // তিন আইকন-টাইল
        val labels = arrayOf("সূর্যোদয়", "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunrise, snap.sehri, snap.iftar)
        val tx0 = 536f; val th = 84f
        for (i in 0 until 3) {
            val y0 = ty0 + (th + 12f) * i
            tile(c, p, tx0, y0, R, y0 + th, 30f, m.track, edge)
            medal(c, p, art, i, tx0 + 20f + 33f, y0 + th / 2f, 66f)
            text(c, p, labels[i], tx0 + 100f, y0 + th / 2f + 12f, 33f, m.secondary, Fonts.regular)
            text(c, p, times[i], R - 24f, y0 + th / 2f + 16f, 46f, m.primary, Fonts.bold, Paint.Align.RIGHT)
        }

        // পাঁচ ওয়াক্ত
        val sy0 = 418f; val sy1 = 534f
        tile(c, p, L, sy0, R, sy1, 34f, m.track, edge)
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cc = L + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 5f, sy0 + 5f, cc + colW / 2f - 5f, sy1 - 5f, 29f, m.accent)
            val fg1 = if (on) onColor(m.accent) else m.secondary
            val fg2 = if (on) onColor(m.accent) else m.primary
            text(c, p, Bn.PRAYER_NAMES[i], cc, 464f, 32f, fg1, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cc, 512f, 42f, fg2, Fonts.bold, Paint.Align.CENTER)
        }
    }

    /** ডিজাইন ৮ (স্ট্যাক): বাঁয়ে লম্বা টাইলে ওপর-নিচ সাজানো ঘড়ি · ডানে লোগো + তিন তারিখ, তিন আইকন, চলমান ওয়াক্ত, পাঁচ ওয়াক্ত */
    private fun drawD8(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(8)
        val R = cw - 36f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000
        val edge = (m.primary and 0xFFFFFF) or 0x1F000000

        // বাঁয়ে স্ট্যাক ঘড়ি
        tile(c, p, 36f, 36f, 356f, 540f, 40f, m.track, edge)
        val hm = hmOf(nowMs)
        val lcx = 196f
        val cs = 190f
        text(c, p, hm.substring(0, 2), lcx, 216f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        p.style = Paint.Style.FILL; p.color = m.accent
        c.drawRoundRect(lcx - 44f, 252f, lcx + 44f, 258f, 3f, 3f, p)
        text(c, p, hm.substring(3), lcx, 450f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        tile(c, p, lcx - 64f, 470f, lcx + 64f, 522f, 26f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
        text(c, p, if (snap.isPm) "PM" else "AM", lcx, 508f, 40f, m.accent, Fonts.outfit, Paint.Align.CENTER)

        // ডানে: লোগো + তিন তারিখ
        val X0 = 392f
        c.drawBitmap(art, LOGO_SRC, RectF(X0, 44f, X0 + 78f, 44f + 79f), p)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(X0 + 94f, 52f, X0 + 96f, 122f, p)
        val dx = X0 + 114f
        val dates = arrayOf(snap.hijriDay + " " + snap.hijriMonthYear, snap.gregorianLine, snap.banglaLine)
        val dys = floatArrayOf(72f, 108f, 144f)
        for ((i, dtx) in dates.withIndex()) {
            val tf = if (i == 0) Fonts.bold else Fonts.regular
            val sz = fit(p, dtx, tf, if (i == 0) 38f else 33f, R - dx)
            text(c, p, dtx, dx, dys[i], sz, if (i == 0) m.primary else m.secondary, tf)
        }

        // তিন আইকন (সূর্যোদয় | সেহরি | ইফতার)
        val labels = arrayOf("সূর্যোদয়", "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunrise, snap.sehri, snap.iftar)
        val colW3 = (R - X0) / 3f
        for (i in 0 until 3) {
            val cx = X0 + colW3 * (i + 0.5f)
            medal(c, p, art, i, cx, 232f, 80f)
            text(c, p, labels[i], cx, 312f, 31f, m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, times[i], cx, 358f, 44f, m.primary, Fonts.bold, Paint.Align.CENTER)
            if (i > 0) { p.style = Paint.Style.FILL; p.color = rule; c.drawRect(X0 + colW3 * i - 1f, 196f, X0 + colW3 * i + 1f, 362f, p) }
        }

        // চলমান ওয়াক্ত + বাকি সময় (লাইভ) + প্রগ্রেস
        text(c, p, snap.currentName, X0, 420f, 46f, m.accent, Fonts.bold)
        remLine(c, p, ov, live, snap, nowMs, 906f, 420f, 36f, 34f, m.primary, m.primary)
        barK(c, p, X0 + 6f, R - 6f, 436f, 8f, frac, m.track, m.accent)

        // পাঁচ ওয়াক্ত
        val colW = (R - X0) / 5f
        for (i in 0 until 5) {
            val cc = X0 + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 2f, 456f, cc + colW / 2f - 2f, 540f, 24f, (m.accent and 0xFFFFFF) or 0x33000000, (m.accent and 0xFFFFFF) or 0x66000000)
            text(c, p, Bn.PRAYER_NAMES[i], cc, 494f, 30f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cc, 530f, 34f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }
}
