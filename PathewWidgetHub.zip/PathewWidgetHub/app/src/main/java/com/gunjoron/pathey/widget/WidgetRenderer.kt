package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.pathey.data.Bn
import com.gunjoron.pathey.data.Snapshot
import java.util.Calendar
import kotlin.math.min

/** ওভারলে (লাইভ) টেক্সটের জায়গা — ডিজাইন-ইউনিটে, কার্ডের বাম-উপরের কোণ থেকে; y = বেসলাইন। */
class TextSpec(val x: Float, val y: Float, val size: Float, val color: Int)

class Overlay {
    var ss: TextSpec? = null
    var s3: TextSpec? = null      // ডিজাইন ৩: ":ss"
    var chrono: TextSpec? = null  // কাউন্টডাউন / কাউন্ট-আপ
}

/**
 * পুরো উইজেট একটাই জায়গায় আঁকা হয় — হোমস্ক্রিন উইজেট (বিটম্যাপ) এবং হাবের লাইভ প্রিভিউ, দুটোতেই
 * একই কোড, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু একরকম।
 *
 * সব মাপ/অবস্থান আপনার ডিজাইন শিটের SVG ইউনিটে (যেমন ডিজাইন ১ কার্ড = ১১১৪.২৫ × ৬০৮.১৬)।
 * live = true  → ঘড়ি ও কাউন্টার সরাসরি আঁকা হয় (প্রিভিউ, প্রতি সেকেন্ডে রিড্র)।
 * live = false → ঘড়ি/কাউন্টারের জায়গায় ফাঁকা রেখে Overlay ফেরত দেয় (হোমস্ক্রিনে TextClock/Chronometer বসে)।
 */
object WidgetRenderer {
    const val PAD = 23f            // কাস্টম প্যানেল কার্ডের চেয়ে যতটা বড়
    private const val PANEL_R = 48f

    fun cardW(d: Int) = when (d) { 3 -> 981.41f; 4, 5, 6 -> 1000f; else -> 1114.25f }
    fun cardH(d: Int) = when (d) { 1 -> 608.16f; 2 -> 445.15f; 3 -> 465.35f; 4 -> 440f; 5 -> 520f; else -> 500f }
    private fun cardRx(d: Int) = when (d) { 1 -> 50.17f; 2 -> 42.93f; 3 -> 41.19f; 4, 5, 6 -> 56f; else -> 50f }

    class Layout(val s: Float, val ox: Float, val oy: Float)

    /** w×h এলাকায় কার্ড (প্যানেলসহ) মাঝখানে, অনুপাত ঠিক রেখে। */
    fun layout(d: Int, w: Float, h: Float): Layout {
        val cw = cardW(d) + 2 * PAD
        val ch = cardH(d) + 2 * PAD
        val s = min(w / cw, h / ch)
        return Layout(s, (w - cardW(d) * s) / 2f, (h - cardH(d) * s) / 2f)
    }

    // ডিজাইন ১/২: ৫ ওয়াক্তের কলামের কেন্দ্র (ফজর, যোহর, আসর, মাগরিব, ইশা)
    private val COL_CX = floatArrayOf(137.35f, 342.5f, 542.72f, 771.11f, 984.43f)
    private const val HL_W = 185.78f
    private const val HL_H = 145.83f
    private const val HL_RX = 21.19f
    private const val HL_NAME_DY = -5.82f
    private const val HL_TIME_DY = -6.21f

    private fun formatHms(totalMs: Long): String {
        val t = (if (totalMs < 0) 0 else totalMs) / 1000
        val h = t / 3600; val m = (t / 60) % 60; val s = t % 60
        return Bn.pad2(h.toInt()) + ":" + Bn.pad2(m.toInt()) + ":" + Bn.pad2(s.toInt())
    }

    fun draw(
        ctx: Context, c: Canvas, w: Float, h: Float,
        look: Look, snap: Snapshot, live: Boolean, nowMs: Long
    ): Overlay {
        Fonts.init(ctx)
        val d = look.design
        val cw = cardW(d); val chh = cardH(d)
        val lay = layout(d, w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.isLinearText = true
        p.isFilterBitmap = true

        c.save()
        c.translate(lay.ox, lay.oy)
        c.scale(lay.s, lay.s)

        // ১) কাস্টম থিমের পেছনের রঙিন প্যানেল
        if (look.panelColor != 0) {
            p.style = Paint.Style.FILL; p.color = soften(look.panelColor)
            c.drawRoundRect(-PAD, -PAD, cw + PAD, chh + PAD, PANEL_R, PANEL_R, p)
            glass(c, p, -PAD, -PAD, cw + PAD, chh + PAD, PANEL_R)
        }

        // ২) কার্ড (গ্লাস/লাইট) — ট্রান্সপারেন্টে নেই
        val cardFill: Int; val cardStroke: Int
        if (d >= 4) { val pl = Palettes.ofMin(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else if (d == 3) { val pl = Palettes.of3(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else { val pl = Palettes.of12(d, look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        if (cardFill != 0) {
            val rx = cardRx(d)
            p.style = Paint.Style.FILL; p.color = soften(cardFill)
            c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
            if (cardStroke != 0) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = cardStroke
                c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
                p.style = Paint.Style.FILL
            }
            if (look.panelColor == 0) glass(c, p, 0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx)
        }

        // ৩) স্ট্যাটিক আর্ট (লোগো, আইকন-পিল, ঘড়ির টাইল, ডিভাইডার…)
        // (আগের রঙ/স্বচ্ছতা পেইন্টে থেকে গেলে আইকন-লোগোও ফিকে হয়ে যেত — তাই রিসেট)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        if (d <= 2) drawArt(c, p, Art.get(ctx, d, look.variant), d, cw, chh)

        // ৪) ডায়নামিক টেক্সট
        val ov = Overlay()
        if (d == 6) drawD6(c, p, look, snap, nowMs) else if (d == 5) drawD5(c, p, look, snap, live, nowMs, ov) else if (d == 4) drawMin(c, p, look, snap, nowMs) else if (d == 3) drawD3(c, p, look, snap, live, nowMs, ov) else drawD12(c, p, d, look, snap, live, nowMs, ov)

        c.restore()
        return ov
    }

    // ------------------------------------------------------------------------------------------
    /** সূর্যোদয় ও ইফতার (সূর্যাস্ত) পিল সামান্য ডানে — আর্টের ওই দুই টুকরো আলাদা সরিয়ে আঁকা। */
    private const val PILL_SHIFT = 14f
    private val SUNRISE_R = Rect(820, 25, 1072, 175)
    private val IFTAR_R = Rect(806, 222, 1060, 358)

    private fun drawArt(c: Canvas, p: Paint, art: Bitmap, d: Int, cw: Float, chh: Float) {
        c.save()
        c.clipOutRect(SUNRISE_R.left.toFloat(), SUNRISE_R.top.toFloat(), SUNRISE_R.right.toFloat(), SUNRISE_R.bottom.toFloat())
        if (d == 1) c.clipOutRect(IFTAR_R.left.toFloat(), IFTAR_R.top.toFloat(), IFTAR_R.right.toFloat(), IFTAR_R.bottom.toFloat())
        c.drawBitmap(art, null, RectF(0f, 0f, cw, chh), p)
        c.restore()
        fun piece(r: Rect) = c.drawBitmap(art, r, RectF(r.left + PILL_SHIFT, r.top.toFloat(), r.right + PILL_SHIFT, r.bottom.toFloat()), p)
        piece(SUNRISE_R)
        if (d == 1) piece(IFTAR_R)
    }

    /** কার্ড/প্যানেলের রঙের অস্বচ্ছতা সামান্য কমানো — যাতে পেছনের ওয়ালপেপার হালকা ঝাপসা দেখা যায়। */
    private const val GLASS_ALPHA = 0.85f
    private fun soften(color: Int): Int {
        val a = ((color ushr 24) * GLASS_ALPHA).toInt().coerceIn(0, 255)
        return (a shl 24) or (color and 0xFFFFFF)
    }

    /** কোনো গ্রেডিয়েন্ট নয় — শুধু খুব হালকা ফ্রস্ট-দানা, যাতে ঝাপসা কাচের অনুভূতি আসে। */
    private val grain: Bitmap by lazy {
        val n = 96
        val px = IntArray(n * n)
        val r = java.util.Random(7)
        for (i in px.indices) {
            val a = r.nextInt(15)                       // ০–১৪ / ২৫৫ — হালকা
            px[i] = (a shl 24) or (if (r.nextBoolean()) 0xFFFFFF else 0x000000)
        }
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun glass(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float) {
        p.style = Paint.Style.FILL
        p.shader = BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        p.shader = null
    }

    private fun measure(p: Paint, s: String, tf: Typeface, size: Float): Float {
        p.typeface = tf; p.textSize = size
        return p.measureText(s)
    }

    private fun text(c: Canvas, p: Paint, s: String, x: Float, y: Float, size: Float, color: Int,
                     tf: Typeface, align: Paint.Align = Paint.Align.LEFT) {
        p.style = Paint.Style.FILL
        p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
        c.drawText(s, x, y, p)
        p.textAlign = Paint.Align.LEFT
    }

    // ------------------------------------------------------------------------------------------
    private fun drawD12(c: Canvas, p: Paint, d: Int, look: Look, snap: Snapshot, live: Boolean,
                        nowMs: Long, ov: Overlay) {
        val pal = Palettes.of12(d, look.variant)
        val yOff = if (d == 1) 0f else -160f   // নিচের অংশ ডিজাইন ২-এ ১৬০ ইউনিট উপরে

        // ---- হিজরি দিন (বড়) + হিজরি মাস-সাল
        val dayX = 216.32f
        text(c, p, snap.hijriDay, dayX, 103.57f, 110f, pal.day, Fonts.bold)
        val dayAdv = measure(p, snap.hijriDay, Fonts.bold, 110f)
        val hx = dayX + dayAdv + 10.53f
        var hs = 55f
        val hw = measure(p, snap.hijriMonthYear, Fonts.bold, hs)
        val hAvail = 825f - hx
        if (hw > hAvail) hs = 55f * hAvail / hw
        text(c, p, snap.hijriMonthYear, hx, 102.29f, hs, pal.hijri, Fonts.bold)

        // ---- ইংরেজি তারিখ | বাংলা তারিখ (মাঝে ডিভাইডার)
        var ds = 52f
        val g1 = snap.gregorianLine; val g2 = snap.banglaLine
        var w1 = measure(p, g1, Fonts.bold, ds); var w2 = measure(p, g2, Fonts.bold, ds)
        val total = w1 + DATE_SEP + w2
        val maxW = 612f
        val f = if (total > maxW) maxW / total else 1f
        if (f < 1f) { ds *= f; w1 *= f; w2 *= f }
        text(c, p, g1, dayX, 162.99f, ds, pal.date, Fonts.bold)
        // দাগ = লেখার রঙ, একটু ফিকে; দুই পাশে ফাঁক যাতে আলাদা বোঝা যায়
        p.style = Paint.Style.FILL; p.color = (pal.date and 0xFFFFFF) or 0xBF000000.toInt()
        val dvx = dayX + w1 + (DATE_SEP - 2.2f) / 2f * f
        c.drawRect(dvx, 123.4f, dvx + 2.2f * f, 123.4f + 45.19f, p)
        text(c, p, g2, dayX + w1 + DATE_SEP * f, 162.99f, ds, pal.date, Fonts.bold)

        // ---- সূর্যোদয় পিল
        text(c, p, "সূর্যোদয়", 1006.18f + PILL_SHIFT, 89.51f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.sunrise, 1005.07f + PILL_SHIFT, 146.66f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

        // ---- ডিজাইন ১: ঘড়ি ও সাহরী/ইফতার
        if (d == 1) {
            text(c, p, "সেহরি", 698.77f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.sehri, 703.71f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)
            text(c, p, "ইফতার", 995.9f + PILL_SHIFT, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.iftar, 992.11f + PILL_SHIFT, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

            val ampm = if (snap.isPm) "PM" else "AM"
            text(c, p, ampm, 424.41f, 299.25f, 40f, pal.pm, Fonts.bebas)
            // ঘণ্টা ও মিনিট বিটম্যাপেই (ডিজাইনের ফন্টে) আঁকা — প্রতি মিনিটের শুরুতে উইজেট নতুন করে আঁকা হয়।
            // শুধু সেকেন্ড লাইভ (TextClock), কারণ প্রতি সেকেন্ডে অ্যাপ জাগানো যাবে না।
            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
            text(c, p, if (hh < 10) "0$hh" else "$hh", 65.32f, 332.48f, 136.17f, pal.clock, Fonts.bebas)
            text(c, p, pad2a(cal.get(Calendar.MINUTE)), 218.54f, 334.48f, 125f, pal.clock, Fonts.bebas)
            if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), 353.03f, 340.13f, 65f, pal.clock, Fonts.bebas)
            else ov.ss = TextSpec(0f, 0f, 0f, pal.clock)
        }

        // ---- পাঁচ ওয়াক্ত
        val nameY = 448.74f + yOff
        val timeY = 502.65f + yOff
        val hlY = 381.16f + yOff
        for (i in 0 until 5) {
            val cx = COL_CX[i]
            val hl = (snap.current == i)
            if (hl) {
                p.style = Paint.Style.FILL; p.color = pal.hlFill
                c.drawRoundRect(cx - HL_W / 2f, hlY, cx + HL_W / 2f, hlY + HL_H, HL_RX, HL_RX, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, nameY + (if (hl) HL_NAME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.name, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, timeY + (if (hl) HL_TIME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.time, Fonts.bold, Paint.Align.CENTER)
        }

        // ---- নিচের লাইন: "<ওয়াক্ত> -এর সময় অতিবাহিত: 00:20:59"
        val nowY = 577.67f + yOff
        val prefix = if (snap.running) snap.currentName + " -এর সময় অতিবাহিত:"
                     else snap.currentName + " -এর সময় শুরু হতে বাকি:"
        var ps = 50f; val ds2 = 40f
        val digitsText = if (live) formatHms(
            if (snap.running) nowMs - snap.periodStartMs else snap.periodEndMs - nowMs) else ""
        // অঙ্ক সবসময় একই জায়গায় (লাইভ Chronometer-এর বক্স স্থির), লেবেল তার বাঁ-পাশে ডান-সারিবদ্ধ
        val labelEnd = CH12_X - CH12_GAP
        var pw = measure(p, prefix, Fonts.regular, ps)
        val maxLabel = labelEnd - 40f
        if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel }
        text(c, p, prefix, labelEnd - pw, nowY, ps, pal.now, Fonts.regular)
        if (live) text(c, p, digitsText, CH12_X, nowY, ds2, pal.nowTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.nowTime)
    }

    // লাইভ কাউন্টারের স্থির বাম-কিনারা (ডিজাইন-ইউনিট) ও লেবেলের ফাঁক
    const val CH12_X = 710f; const val CH12_GAP = 10f
    const val CH3_X = 548f
    private const val DATE_SEP = 30f      // ইংরেজি ও বাংলা তারিখের মাঝে মোট ফাঁক (দাগসহ)
    private const val CLOCK_X = 85f; private const val CLOCK_W = 621f; private const val CLOCK_BASE = 200f
    private const val SIDE_CX = 838f; private const val AMPM_BASE = 80f; private const val SEC_BASE = 197f

    private fun cwOf(d: Int) = cardW(d)
    private fun pad2a(n: Int) = if (n < 10) "0$n" else n.toString()

    // ------------------------------------------------------------------------------------------
    private fun drawD3(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean,
                       nowMs: Long, ov: Overlay) {
        val pal = Palettes.of3(look.variant)
        val cw = cardW(3)
        val rule = (pal.month and 0xFFFFFF) or 0xBF000000.toInt()   // লেখার রঙ, সামান্য ফিকে
        val ruleW = 1.8f

        // ১) বড় ঘড়ি (বাঁয়ে), AM/PM + সেকেন্ড (ডানে, একটার ওপর আরেকটা)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val clockSize = CLOCK_W / measure(p, "00:00", Fonts.clockBold, 100f) * 100f   // সবচেয়ে চওড়া "00:00" ধরে মাপ
        // ঘণ্টা | কোলন | মিনিট আলাদা আঁকা — কোলন ঠিক অঙ্কের উচ্চতার মাঝখানে (ফন্টে সেটা নিচু বসে)
        p.typeface = Fonts.clockBold; p.textSize = clockSize
        val rb = Rect(); p.getTextBounds("0", 0, 1, rb)
        val digitMid = (rb.top + rb.bottom) / 2f
        val cb = Rect(); p.getTextBounds(":", 0, 1, cb)
        val colonMid = (cb.top + cb.bottom) / 2f
        val colonDy = digitMid - colonMid
        val hhS = hm.substring(0, 2); val mmS = hm.substring(3)
        val hhW = measure(p, hhS, Fonts.clockBold, clockSize)
        val colonW = measure(p, ":", Fonts.clockBold, clockSize)
        text(c, p, hhS, CLOCK_X, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, ":", CLOCK_X + hhW, CLOCK_BASE + colonDy, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, mmS, CLOCK_X + hhW + colonW, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, if (snap.isPm) "PM" else "AM", SIDE_CX, AMPM_BASE, 80f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), SIDE_CX, SEC_BASE, 130f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        else ov.s3 = TextSpec(0f, 0f, 0f, pal.clock)

        // ২) তিন কলামের তারিখ: ইংরেজি | হিজরি | বাংলা — সমান তিন ভাগ
        class Col(val day: String, val month: String, val year: String)
        val cols = arrayOf(
            Col(snap.gregDay, snap.gregMonth, snap.gregYear),
            Col(snap.hijriDay, snap.hijriMonth, snap.hijriYear),
            Col(snap.banglaDay, snap.banglaMonth, snap.banglaYear)
        )
        val colW = cw / 3f
        p.style = Paint.Style.FILL; p.color = rule
        for (i in 1..2) c.drawRect(colW * i - ruleW / 2f, 248f, colW * i + ruleW / 2f, 399f, p)
        for ((i, col) in cols.withIndex()) {
            val cx = colW * (i + 0.5f)
            text(c, p, col.day, cx, 312f, 100f, pal.day, Fonts.bold, Paint.Align.CENTER)
            val maxW = colW - 36f
            var ms = 52f
            val mw = measure(p, col.month, Fonts.regular, ms)
            if (mw > maxW) ms *= maxW / mw
            text(c, p, col.month, cx, 360f, ms, pal.month, Fonts.regular, Paint.Align.CENTER)
            text(c, p, col.year, cx, 392f, 44f, pal.month, Fonts.regular, Paint.Align.CENTER)
        }

        // ৩) নিচের লাইন: ── ইশা [চলছে] সময় বাকি: 01:54:56 ──
        //    অঙ্ক স্থির জায়গায় (লাইভ Chronometer), বাকি সব তার বাঁয়ে ডান-সারিবদ্ধ; দুই পাশে রেখা।
        val label = if (snap.running) "সময় বাকি:" else "শুরু হতে বাকি:"
        val lw = measure(p, label, Fonts.regular, 27f)
        val nameW = measure(p, snap.currentName, Fonts.regular, 36f)
        val badgeW = 70.25f
        var x = CH3_X - 8f - lw
        text(c, p, label, x, 436f, 27f, pal.subLabel, Fonts.regular)
        if (snap.running) {
            x -= 8f + badgeW
            p.style = Paint.Style.FILL; p.color = 0xFFFCB010.toInt()
            c.drawRoundRect(x, 412f, x + badgeW, 440.05f, 14.02f, 14.02f, p)
            text(c, p, "চলছে", x + 10.34f, 435f, 26.95f, pal.badgeText, Fonts.regular)
            p.style = Paint.Style.FILL; p.color = 0xFFFF0000.toInt()
            c.drawCircle(x + 60.98f, 426.4f, 3.15f, p)
        }
        x -= 6f + nameW
        text(c, p, snap.currentName, x, 437f, 36f, pal.prayer, Fonts.regular)
        val digitsText = if (live) formatHms(snap.periodEndMs - nowMs) else ""
        if (live) text(c, p, digitsText, CH3_X, 436f, 34f, pal.subTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.subTime)
        // রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(24f, 426f - ruleW / 2f, x - 10f, 426f + ruleW / 2f, p)
        c.drawRect(CH3_X + 108f + 10f, 426f - ruleW / 2f, cw - 24f, 426f + ruleW / 2f, p)
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৪ (মিনিমাল) ও ৫ (স্ট্রিপ) — কোনো আর্ট/লাইভ ওভারলে নেই; সবকিছু বিটম্যাপে, প্রতি মিনিটে নতুন।
    // ------------------------------------------------------------------------------------------
    private fun remText(ms: Long): String {
        val mins = maxOf(1L, (ms + 59_999L) / 60_000L)
        val h = mins / 60; val m = mins % 60
        return Bn.digits(if (h > 0) "$h ঘ $m মি" else "$m মি")
    }

    /** পাতলা ঘড়ি: ঘণ্টা | কোলন (অঙ্কের মাঝ বরাবর) | মিনিট। ফেরত: মোট প্রস্থ। */
    private fun slimClock(c: Canvas, p: Paint, hm: String, x: Float, base: Float, size: Float, color: Int): Float {
        p.typeface = Fonts.outfit; p.textSize = size
        val r0 = Rect(); p.getTextBounds("0", 0, 1, r0)
        val r1 = Rect(); p.getTextBounds(":", 0, 1, r1)
        val dy = (r0.top + r0.bottom) / 2f - (r1.top + r1.bottom) / 2f
        val a = hm.substring(0, 2); val b = hm.substring(3)
        val aw = measure(p, a, Fonts.outfit, size); val cw = measure(p, ":", Fonts.outfit, size)
        val bw = measure(p, b, Fonts.outfit, size)
        text(c, p, a, x, base, size, color, Fonts.outfit)
        text(c, p, ":", x + aw, base + dy, size, color, Fonts.outfit)
        text(c, p, b, x + aw + cw, base, size, color, Fonts.outfit)
        return aw + cw + bw
    }

    private fun bar(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
        p.style = Paint.Style.FILL; p.color = track
        c.drawRoundRect(x0, y, x1, y + h, h / 2f, h / 2f, p)
        val fx = x0 + (x1 - x0) * frac.coerceIn(0f, 1f)
        if (fx - x0 > h) { p.color = fill; c.drawRoundRect(x0, y, fx, y + h, h / 2f, h / 2f, p) }
    }

    private fun drawMin(c: Canvas, p: Paint, look: Look, snap: Snapshot, nowMs: Long) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(4)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val ampm = if (snap.isPm) "PM" else "AM"
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val remain = remText(snap.periodEndMs - nowMs)
        val L = 40f; val R = cw - 40f
        val colW = (R - L) / 5f

        // ওপরের সারি: ইংরেজি তারিখ (বাঁয়ে) | হিজরি তারিখ (ডানে)
        text(c, p, snap.gregorianLine, L, 78f, 33f, m.secondary, Fonts.regular)
        text(c, p, snap.hijriDay + " " + snap.hijriMonthYear, R, 78f, 33f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        // বড় পাতলা ঘড়ি + AM/PM
        val w = slimClock(c, p, hm, L - 6f, 250f, 188f, m.primary)
        text(c, p, ampm, L - 6f + w + 18f, 250f, 44f, m.accent, Fonts.outfit)
        // ডানে চলমান ওয়াক্ত
        text(c, p, if (snap.running) "চলমান ওয়াক্ত" else "পরবর্তী ওয়াক্ত", R, 128f, 28f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        text(c, p, snap.currentName, R, 198f, 84f, m.accent, Fonts.bold, Paint.Align.RIGHT)
        text(c, p, remain + " বাকি", R, 250f, 36f, m.primary, Fonts.regular, Paint.Align.RIGHT)
        // প্রগ্রেস বার
        bar(c, p, L, R, 292f, 8f, frac, m.track, m.accent)
        // পাঁচ ওয়াক্ত
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = snap.current == i
            text(c, p, Bn.PRAYER_NAMES[i], cx, 352f, 30f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 400f, 40f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৫ (ড্যাশবোর্ড): সেকেন্ডসহ ঘড়ি · তিন তারিখ (ইংরেজি/হিজরি/বাংলা) · সাহরি-ইফতার · চলমান ওয়াক্ত · পাঁচ ওয়াক্ত
    // শুধু সেকেন্ডটা লাইভ (TextClock "ss"); বাকি সব বিটম্যাপে।
    // ------------------------------------------------------------------------------------------
    private const val D5_CLOCK_W = 470f; private const val D5_BASE = 200f
    const val D5_SIDE_CX = 585f
    private const val D5_DIV = 662f; private const val D5_RX = 690f

    private fun fit(p: Paint, s: String, tf: Typeface, size: Float, maxW: Float): Float {
        val w = measure(p, s, tf, size)
        return if (w > maxW) size * maxW / w else size
    }

    private fun drawD5(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(5)
        val L = 40f; val R = cw - 40f
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000

        // ১) ঘড়ি (বাঁয়ে) + AM/PM ও সেকেন্ড (একটার নিচে আরেকটা)
        val clockSize = D5_CLOCK_W / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hm, L - 4f, D5_BASE, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", D5_SIDE_CX, 114f, 34f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), D5_SIDE_CX, 192f, 62f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ২) ডানে তিন তারিখ — ছোট লেবেল + তারিখ
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, 50f, D5_DIV + 1f, 226f, p)
        val dates = arrayOf(
            "ইংরেজি" to snap.gregorianLine,
            "হিজরি" to (snap.hijriDay + " " + snap.hijriMonthYear),
            "বাংলা" to snap.banglaLine
        )
        for ((i, dv) in dates.withIndex()) {
            val y0 = 70f + 60f * i
            text(c, p, dv.first, D5_RX, y0, 21f, m.accent, Fonts.regular)
            val sz = fit(p, dv.second, Fonts.bold, 31f, R - D5_RX)
            text(c, p, dv.second, D5_RX, y0 + 32f, sz, m.primary, Fonts.bold)
        }

        // ৩) সাহরি / ইফতার টাইল + চলমান ওয়াক্ত
        val tw = 250f; val ty = 256f; val th = 86f
        val tiles = arrayOf("সেহরি" to snap.sehri, "ইফতার" to snap.iftar)
        for ((i, t) in tiles.withIndex()) {
            val x0 = L + (tw + 12f) * i
            p.style = Paint.Style.FILL; p.color = m.track
            c.drawRoundRect(x0, ty, x0 + tw, ty + th, 26f, 26f, p)
            text(c, p, t.first, x0 + 26f, ty + 33f, 24f, m.secondary, Fonts.regular)
            text(c, p, t.second, x0 + 26f, ty + 73f, 40f, m.primary, Fonts.bold)
        }
        text(c, p, if (snap.running) "চলমান ওয়াক্ত" else "পরবর্তী ওয়াক্ত", D5_RX, ty + 24f, 21f, m.secondary, Fonts.regular)
        text(c, p, snap.currentName, D5_RX, ty + 66f, 44f, m.accent, Fonts.bold)
        text(c, p, remText(snap.periodEndMs - nowMs) + " বাকি", R, ty + 66f, 26f, m.primary, Fonts.regular, Paint.Align.RIGHT)
        bar(c, p, D5_RX, R, ty + 80f, 6f, frac, m.track, m.accent)

        // ৪) পাঁচ ওয়াক্ত; চলমানটা হাইলাইটে
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) {
                p.style = Paint.Style.FILL; p.color = (m.accent and 0xFFFFFF) or 0x33000000
                c.drawRoundRect(cx - colW / 2f + 5f, 370f, cx + colW / 2f - 5f, 490f, 28f, 28f, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, 420f, 28f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 466f, 40f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৬ (সান-আর্ক): সূর্যোদয় থেকে সূর্যাস্তের আর্ক, তাতে সূর্যের বর্তমান অবস্থান; ভেতরে ঘড়ি;
    // দুই প্রান্তে সূর্যোদয়/সূর্যাস্ত, মাঝে চলমান ওয়াক্ত; নিচে পাঁচ ওয়াক্তের স্ট্রিপ।
    // ------------------------------------------------------------------------------------------
    private fun onColor(bg: Int): Int {
        val r = (bg shr 16) and 255; val g = (bg shr 8) and 255; val b = bg and 255
        return if (0.299f * r + 0.587f * g + 0.114f * b > 150f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
    }

    private fun drawD6(c: Canvas, p: Paint, look: Look, snap: Snapshot, nowMs: Long) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(6)
        val L = 40f; val R = cw - 40f
        val cx = cw / 2f; val cy = 296f; val rad = 250f
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val rule = (m.primary and 0xFFFFFF) or 0x40000000

        // ওপরের কোণে দুই তারিখ
        text(c, p, snap.gregorianLine, L, 64f, 28f, m.secondary, Fonts.regular)
        text(c, p, snap.banglaLine, L, 100f, 28f, m.secondary, Fonts.regular)
        text(c, p, snap.hijriDay + " " + snap.hijriMonthYear, R, 64f, 28f, m.secondary, Fonts.regular, Paint.Align.RIGHT)

        // আর্ক: ফিকে ট্র্যাক + সূর্যোদয় থেকে এখন পর্যন্ত উজ্জ্বল অংশ
        val sr = snap.sunriseMs; val ss = snap.sunsetMs
        val day = ss > sr
        val f = if (!day) 0f else ((nowMs - sr).toFloat() / (ss - sr)).coerceIn(0f, 1f)
        val isDay = day && nowMs in sr..ss
        val oval = RectF(cx - rad, cy - rad, cx + rad, cy + rad)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 4f; p.color = m.track
        c.drawArc(oval, 180f, 180f, false, p)
        if (f > 0.004f) {
            p.strokeWidth = 7f; p.color = m.accent
            c.drawArc(oval, 180f, 180f * f, false, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        // ভূমি-রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(L, cy - 1f, R, cy + 1f, p)
        // সূর্য
        val ang = Math.PI * (1.0 + f)
        val sx = cx + rad * Math.cos(ang).toFloat(); val sy = cy + rad * Math.sin(ang).toFloat()
        if (isDay) {
            p.color = (m.accent and 0xFFFFFF) or 0x26000000; c.drawCircle(sx, sy, 34f, p)
            p.color = (m.accent and 0xFFFFFF) or 0x4D000000; c.drawCircle(sx, sy, 22f, p)
            p.color = m.accent; c.drawCircle(sx, sy, 12f, p)
        } else {
            p.color = m.secondary; c.drawCircle(sx, sy, 8f, p)
        }

        // আর্কের ভেতরে ঘড়ি + AM/PM
        val clockSize = 150f
        p.typeface = Fonts.outfit; p.textSize = clockSize
        val cwid = measure(p, hm.substring(0, 2), Fonts.outfit, clockSize) * 2f + measure(p, ":", Fonts.outfit, clockSize)
        slimClock(c, p, hm, cx - cwid / 2f, 246f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", cx, 282f, 28f, m.accent, Fonts.outfit, Paint.Align.CENTER)

        // ভূমি-রেখার নিচে: সূর্যোদয় | চলমান ওয়াক্ত | সূর্যাস্ত
        text(c, p, "সূর্যোদয়", cx - rad, 344f, 25f, m.secondary, Fonts.regular, Paint.Align.CENTER)
        text(c, p, snap.sunrise, cx - rad, 390f, 44f, m.primary, Fonts.bold, Paint.Align.CENTER)
        text(c, p, "সূর্যাস্ত", cx + rad, 344f, 25f, m.secondary, Fonts.regular, Paint.Align.CENTER)
        text(c, p, snap.iftar, cx + rad, 390f, 44f, m.primary, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.currentName, cx, 358f, 50f, m.accent, Fonts.bold, Paint.Align.CENTER)
        text(c, p, remText(snap.periodEndMs - nowMs) + " বাকি", cx, 392f, 26f, m.primary, Fonts.regular, Paint.Align.CENTER)

        // নিচে পাঁচ ওয়াক্তের স্ট্রিপ
        p.style = Paint.Style.FILL; p.color = m.track
        c.drawRoundRect(L, 420f, R, 480f, 30f, 30f, p)
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cc = L + colW * (i + 0.5f)
            val on = snap.current == i
            if (on) {
                p.style = Paint.Style.FILL; p.color = m.accent
                c.drawRoundRect(cc - colW / 2f + 4f, 424f, cc + colW / 2f - 4f, 476f, 26f, 26f, p)
            }
            val nm = Bn.PRAYER_NAMES[i]; val tm = snap.prayerTimes[i]
            val nw = measure(p, nm, Fonts.regular, 24f); val tw = measure(p, tm, Fonts.bold, 29f)
            val x0 = cc - (nw + 10f + tw) / 2f
            text(c, p, nm, x0, 459f, 24f, if (on) onColor(m.accent) else m.secondary, Fonts.regular)
            text(c, p, tm, x0 + nw + 10f, 460f, 29f, if (on) onColor(m.accent) else m.primary, Fonts.bold)
        }
    }
}
