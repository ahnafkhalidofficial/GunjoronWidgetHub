package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.pathey.data.Bn
import com.gunjoron.pathey.data.Snapshot
import java.util.Calendar
import kotlin.math.min

/** ওভারলে (লাইভ) টেক্সটের জায়গা — ডিজাইন-ইউনিটে, কার্ডের বাম-উপরের কোণ থেকে; y = বেসলাইন। */
class TextSpec(val x: Float, val y: Float, val size: Float, val color: Int)

class Overlay {
    var ss: TextSpec? = null
    var s3: TextSpec? = null      // ডিজাইন ৩: ":ss"
    var chrono: TextSpec? = null  // কাউন্টডাউন / কাউন্ট-আপ
}

/**
 * পুরো উইজেট একটাই জায়গায় আঁকা হয় — হোমস্ক্রিন উইজেট (বিটম্যাপ) এবং হাবের লাইভ প্রিভিউ, দুটোতেই
 * একই কোড, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু একরকম।
 *
 * সব মাপ/অবস্থান আপনার ডিজাইন শিটের SVG ইউনিটে (যেমন ডিজাইন ১ কার্ড = ১১১৪.২৫ × ৬০৮.১৬)।
 * live = true  → ঘড়ি ও কাউন্টার সরাসরি আঁকা হয় (প্রিভিউ, প্রতি সেকেন্ডে রিড্র)।
 * live = false → ঘড়ি/কাউন্টারের জায়গায় ফাঁকা রেখে Overlay ফেরত দেয় (হোমস্ক্রিনে TextClock/Chronometer বসে)।
 */
object WidgetRenderer {
    const val PAD = 23f            // কাস্টম প্যানেল কার্ডের চেয়ে যতটা বড়
    private const val PANEL_R = 48f

    fun cardW(d: Int) = if (d == 3) 981.41f else 1114.25f
    fun cardH(d: Int) = when (d) { 1 -> 608.16f; 2 -> 445.15f; else -> 465.35f }
    private fun cardRx(d: Int) = when (d) { 1 -> 50.17f; 2 -> 42.93f; else -> 41.19f }

    class Layout(val s: Float, val ox: Float, val oy: Float)

    /** w×h এলাকায় কার্ড (প্যানেলসহ) মাঝখানে, অনুপাত ঠিক রেখে। */
    fun layout(d: Int, w: Float, h: Float): Layout {
        val cw = cardW(d) + 2 * PAD
        val ch = cardH(d) + 2 * PAD
        val s = min(w / cw, h / ch)
        return Layout(s, (w - cardW(d) * s) / 2f, (h - cardH(d) * s) / 2f)
    }

    // ডিজাইন ১/২: ৫ ওয়াক্তের কলামের কেন্দ্র (ফজর, যোহর, আসর, মাগরিব, ইশা)
    private val COL_CX = floatArrayOf(137.35f, 342.5f, 542.72f, 771.11f, 984.43f)
    private const val HL_W = 185.78f
    private const val HL_H = 145.83f
    private const val HL_RX = 21.19f
    private const val HL_NAME_DY = -5.82f
    private const val HL_TIME_DY = -6.21f

    private fun formatHms(totalMs: Long): String {
        val t = (if (totalMs < 0) 0 else totalMs) / 1000
        val h = t / 3600; val m = (t / 60) % 60; val s = t % 60
        return Bn.pad2(h.toInt()) + ":" + Bn.pad2(m.toInt()) + ":" + Bn.pad2(s.toInt())
    }

    fun draw(
        ctx: Context, c: Canvas, w: Float, h: Float,
        look: Look, snap: Snapshot, live: Boolean, nowMs: Long
    ): Overlay {
        Fonts.init(ctx)
        val d = look.design
        val cw = cardW(d); val chh = cardH(d)
        val lay = layout(d, w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.isLinearText = true
        p.isFilterBitmap = true

        c.save()
        c.translate(lay.ox, lay.oy)
        c.scale(lay.s, lay.s)

        // ১) কাস্টম থিমের পেছনের রঙিন প্যানেল
        if (look.panelColor != 0) {
            p.style = Paint.Style.FILL; p.color = soften(look.panelColor)
            c.drawRoundRect(-PAD, -PAD, cw + PAD, chh + PAD, PANEL_R, PANEL_R, p)
            glass(c, p, -PAD, -PAD, cw + PAD, chh + PAD, PANEL_R)
        }

        // ২) কার্ড (গ্লাস/লাইট) — ট্রান্সপারেন্টে নেই
        val cardFill: Int; val cardStroke: Int
        if (d == 3) { val pl = Palettes.of3(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else { val pl = Palettes.of12(d, look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        if (cardFill != 0) {
            val rx = cardRx(d)
            p.style = Paint.Style.FILL; p.color = soften(cardFill)
            c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
            if (cardStroke != 0) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = cardStroke
                c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
                p.style = Paint.Style.FILL
            }
            if (look.panelColor == 0) glass(c, p, 0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx)
        }

        // ৩) স্ট্যাটিক আর্ট (লোগো, আইকন-পিল, ঘড়ির টাইল, ডিভাইডার…)
        // (আগের রঙ/স্বচ্ছতা পেইন্টে থেকে গেলে আইকন-লোগোও ফিকে হয়ে যেত — তাই রিসেট)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        if (d != 3) c.drawBitmap(Art.get(ctx, d, look.variant), null, RectF(0f, 0f, cw, chh), p)

        // ৪) ডায়নামিক টেক্সট
        val ov = Overlay()
        if (d == 3) drawD3(c, p, look, snap, live, nowMs, ov) else drawD12(c, p, d, look, snap, live, nowMs, ov)

        c.restore()
        return ov
    }

    // ------------------------------------------------------------------------------------------
    /** কার্ড/প্যানেলের রঙের অস্বচ্ছতা সামান্য কমানো — যাতে পেছনের ওয়ালপেপার হালকা ঝাপসা দেখা যায়। */
    private const val GLASS_ALPHA = 0.85f
    private fun soften(color: Int): Int {
        val a = ((color ushr 24) * GLASS_ALPHA).toInt().coerceIn(0, 255)
        return (a shl 24) or (color and 0xFFFFFF)
    }

    /** কোনো গ্রেডিয়েন্ট নয় — শুধু খুব হালকা ফ্রস্ট-দানা, যাতে ঝাপসা কাচের অনুভূতি আসে। */
    private val grain: Bitmap by lazy {
        val n = 96
        val px = IntArray(n * n)
        val r = java.util.Random(7)
        for (i in px.indices) {
            val a = r.nextInt(15)                       // ০–১৪ / ২৫৫ — হালকা
            px[i] = (a shl 24) or (if (r.nextBoolean()) 0xFFFFFF else 0x000000)
        }
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun glass(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float) {
        p.style = Paint.Style.FILL
        p.shader = BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        p.shader = null
    }

    private fun measure(p: Paint, s: String, tf: Typeface, size: Float): Float {
        p.typeface = tf; p.textSize = size
        return p.measureText(s)
    }

    private fun text(c: Canvas, p: Paint, s: String, x: Float, y: Float, size: Float, color: Int,
                     tf: Typeface, align: Paint.Align = Paint.Align.LEFT) {
        p.style = Paint.Style.FILL
        p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
        c.drawText(s, x, y, p)
        p.textAlign = Paint.Align.LEFT
    }

    // ------------------------------------------------------------------------------------------
    private fun drawD12(c: Canvas, p: Paint, d: Int, look: Look, snap: Snapshot, live: Boolean,
                        nowMs: Long, ov: Overlay) {
        val pal = Palettes.of12(d, look.variant)
        val yOff = if (d == 1) 0f else -160f   // নিচের অংশ ডিজাইন ২-এ ১৬০ ইউনিট উপরে

        // ---- হিজরি দিন (বড়) + হিজরি মাস-সাল
        val dayX = 216.32f
        text(c, p, snap.hijriDay, dayX, 103.57f, 110f, pal.day, Fonts.bold)
        val dayAdv = measure(p, snap.hijriDay, Fonts.bold, 110f)
        val hx = dayX + dayAdv + 10.53f
        var hs = 55f
        val hw = measure(p, snap.hijriMonthYear, Fonts.bold, hs)
        val hAvail = 825f - hx
        if (hw > hAvail) hs = 55f * hAvail / hw
        text(c, p, snap.hijriMonthYear, hx, 102.29f, hs, pal.hijri, Fonts.bold)

        // ---- ইংরেজি তারিখ | বাংলা তারিখ (মাঝে ডিভাইডার)
        var ds = 52f
        val g1 = snap.gregorianLine; val g2 = snap.banglaLine
        var w1 = measure(p, g1, Fonts.bold, ds); var w2 = measure(p, g2, Fonts.bold, ds)
        val total = w1 + 14.31f + w2
        val maxW = 612f
        val f = if (total > maxW) maxW / total else 1f
        if (f < 1f) { ds *= f; w1 *= f; w2 *= f }
        text(c, p, g1, dayX, 162.99f, ds, pal.date, Fonts.bold)
        p.style = Paint.Style.FILL; p.color = pal.divider
        val dvx = dayX + w1 + 6.31f * f
        c.drawRect(dvx, 123.4f, dvx + 1f, 123.4f + 45.19f, p)
        text(c, p, g2, dayX + w1 + 14.31f * f, 162.99f, ds, pal.date, Fonts.bold)

        // ---- সূর্যোদয় পিল
        text(c, p, "সূর্যোদয়", 1006.18f, 89.51f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.sunrise, 1005.07f, 146.66f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

        // ---- ডিজাইন ১: ঘড়ি ও সাহরী/ইফতার
        if (d == 1) {
            text(c, p, "সেহরি", 698.77f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.sehri, 703.71f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)
            text(c, p, "ইফতার", 995.9f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.iftar, 992.11f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

            val ampm = if (snap.isPm) "PM" else "AM"
            text(c, p, ampm, 424.41f, 299.25f, 40f, pal.pm, Fonts.bebas)
            // ঘণ্টা ও মিনিট বিটম্যাপেই (ডিজাইনের ফন্টে) আঁকা — প্রতি মিনিটের শুরুতে উইজেট নতুন করে আঁকা হয়।
            // শুধু সেকেন্ড লাইভ (TextClock), কারণ প্রতি সেকেন্ডে অ্যাপ জাগানো যাবে না।
            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
            text(c, p, if (hh < 10) "0$hh" else "$hh", 65.32f, 332.48f, 136.17f, pal.clock, Fonts.bebas)
            text(c, p, pad2a(cal.get(Calendar.MINUTE)), 218.54f, 334.48f, 125f, pal.clock, Fonts.bebas)
            if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), 353.03f, 340.13f, 65f, pal.clock, Fonts.bebas)
            else ov.ss = TextSpec(0f, 0f, 0f, pal.clock)
        }

        // ---- পাঁচ ওয়াক্ত
        val nameY = 448.74f + yOff
        val timeY = 502.65f + yOff
        val hlY = 381.16f + yOff
        for (i in 0 until 5) {
            val cx = COL_CX[i]
            val hl = (snap.current == i)
            if (hl) {
                p.style = Paint.Style.FILL; p.color = pal.hlFill
                c.drawRoundRect(cx - HL_W / 2f, hlY, cx + HL_W / 2f, hlY + HL_H, HL_RX, HL_RX, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, nameY + (if (hl) HL_NAME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.name, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, timeY + (if (hl) HL_TIME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.time, Fonts.bold, Paint.Align.CENTER)
        }

        // ---- নিচের লাইন: "<ওয়াক্ত> -এর সময় অতিবাহিত: 00:20:59"
        val nowY = 577.67f + yOff
        val prefix = if (snap.running) snap.currentName + " -এর সময় অতিবাহিত:"
                     else snap.currentName + " -এর সময় শুরু হতে বাকি:"
        var ps = 50f; val ds2 = 40f
        val digitsText = if (live) formatHms(
            if (snap.running) nowMs - snap.periodStartMs else snap.periodEndMs - nowMs) else ""
        // অঙ্ক সবসময় একই জায়গায় (লাইভ Chronometer-এর বক্স স্থির), লেবেল তার বাঁ-পাশে ডান-সারিবদ্ধ
        val labelEnd = CH12_X - CH12_GAP
        var pw = measure(p, prefix, Fonts.regular, ps)
        val maxLabel = labelEnd - 40f
        if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel }
        text(c, p, prefix, labelEnd - pw, nowY, ps, pal.now, Fonts.regular)
        if (live) text(c, p, digitsText, CH12_X, nowY, ds2, pal.nowTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.nowTime)
    }

    // লাইভ কাউন্টারের স্থির বাম-কিনারা (ডিজাইন-ইউনিট) ও লেবেলের ফাঁক
    const val CH12_X = 710f; const val CH12_GAP = 10f
    const val CH3_X = 548f
    private const val CLOCK_X = 85f; private const val CLOCK_W = 621f; private const val CLOCK_BASE = 200f
    private const val SIDE_CX = 838f; private const val AMPM_BASE = 80f; private const val SEC_BASE = 197f

    private fun cwOf(d: Int) = cardW(d)
    private fun pad2a(n: Int) = if (n < 10) "0$n" else n.toString()

    // ------------------------------------------------------------------------------------------
    private fun drawD3(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean,
                       nowMs: Long, ov: Overlay) {
        val pal = Palettes.of3(look.variant)
        val cw = cardW(3)
        val rule = (pal.month and 0xFFFFFF) or 0x66000000   // ডিভাইডারের হালকা রঙ

        // ১) বড় ঘড়ি (বাঁয়ে), AM/PM + সেকেন্ড (ডানে, একটার ওপর আরেকটা)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val clockSize = CLOCK_W / measure(p, "00:00", Fonts.clockBold, 100f) * 100f   // সবচেয়ে চওড়া "00:00" ধরে মাপ
        // ঘণ্টা | কোলন | মিনিট আলাদা আঁকা — কোলন ঠিক অঙ্কের উচ্চতার মাঝখানে (ফন্টে সেটা নিচু বসে)
        p.typeface = Fonts.clockBold; p.textSize = clockSize
        val rb = Rect(); p.getTextBounds("0", 0, 1, rb)
        val digitMid = (rb.top + rb.bottom) / 2f
        val cb = Rect(); p.getTextBounds(":", 0, 1, cb)
        val colonMid = (cb.top + cb.bottom) / 2f
        val colonDy = digitMid - colonMid
        val hhS = hm.substring(0, 2); val mmS = hm.substring(3)
        val hhW = measure(p, hhS, Fonts.clockBold, clockSize)
        val colonW = measure(p, ":", Fonts.clockBold, clockSize)
        text(c, p, hhS, CLOCK_X, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, ":", CLOCK_X + hhW, CLOCK_BASE + colonDy, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, mmS, CLOCK_X + hhW + colonW, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, if (snap.isPm) "PM" else "AM", SIDE_CX, AMPM_BASE, 80f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), SIDE_CX, SEC_BASE, 130f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        else ov.s3 = TextSpec(0f, 0f, 0f, pal.clock)

        // ২) তিন কলামের তারিখ: ইংরেজি | হিজরি | বাংলা — সমান তিন ভাগ
        class Col(val day: String, val month: String, val year: String)
        val cols = arrayOf(
            Col(snap.gregDay, snap.gregMonth, snap.gregYear),
            Col(snap.hijriDay, snap.hijriMonth, snap.hijriYear),
            Col(snap.banglaDay, snap.banglaMonth, snap.banglaYear)
        )
        val colW = cw / 3f
        p.style = Paint.Style.FILL; p.color = rule
        for (i in 1..2) c.drawRect(colW * i - 0.6f, 248f, colW * i + 0.6f, 399f, p)
        for ((i, col) in cols.withIndex()) {
            val cx = colW * (i + 0.5f)
            text(c, p, col.day, cx, 312f, 100f, pal.day, Fonts.bold, Paint.Align.CENTER)
            val maxW = colW - 36f
            var ms = 52f
            val mw = measure(p, col.month, Fonts.regular, ms)
            if (mw > maxW) ms *= maxW / mw
            text(c, p, col.month, cx, 360f, ms, pal.month, Fonts.regular, Paint.Align.CENTER)
            text(c, p, col.year, cx, 392f, 44f, pal.month, Fonts.regular, Paint.Align.CENTER)
        }

        // ৩) নিচের লাইন: ── ইশা [চলছে] সময় বাকি: 01:54:56 ──
        //    অঙ্ক স্থির জায়গায় (লাইভ Chronometer), বাকি সব তার বাঁয়ে ডান-সারিবদ্ধ; দুই পাশে রেখা।
        val label = if (snap.running) "সময় বাকি:" else "শুরু হতে বাকি:"
        val lw = measure(p, label, Fonts.regular, 27f)
        val nameW = measure(p, snap.currentName, Fonts.regular, 36f)
        val badgeW = 70.25f
        var x = CH3_X - 8f - lw
        text(c, p, label, x, 436f, 27f, pal.subLabel, Fonts.regular)
        if (snap.running) {
            x -= 8f + badgeW
            p.style = Paint.Style.FILL; p.color = 0xFFFCB010.toInt()
            c.drawRoundRect(x, 412f, x + badgeW, 440.05f, 14.02f, 14.02f, p)
            text(c, p, "চলছে", x + 10.34f, 435f, 26.95f, pal.badgeText, Fonts.regular)
            p.style = Paint.Style.FILL; p.color = 0xFFFF0000.toInt()
            c.drawCircle(x + 60.98f, 426.4f, 3.15f, p)
        }
        x -= 6f + nameW
        text(c, p, snap.currentName, x, 437f, 36f, pal.prayer, Fonts.regular)
        val digitsText = if (live) formatHms(snap.periodEndMs - nowMs) else ""
        if (live) text(c, p, digitsText, CH3_X, 436f, 34f, pal.subTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.subTime)
        // রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(24f, 425.4f, x - 10f, 426.6f, p)
        c.drawRect(CH3_X + 108f + 10f, 425.4f, cw - 24f, 426.6f, p)
    }
}
