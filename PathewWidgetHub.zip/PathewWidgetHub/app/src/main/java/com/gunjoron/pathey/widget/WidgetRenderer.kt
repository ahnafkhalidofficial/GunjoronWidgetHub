package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.widget.assets.Art
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.designs.ClassicDesign
import com.gunjoron.pathey.widget.designs.DashboardDesign
import com.gunjoron.pathey.widget.designs.DialDesign
import com.gunjoron.pathey.widget.designs.EditorialDesign
import com.gunjoron.pathey.widget.designs.MinimalDesign
import com.gunjoron.pathey.widget.designs.StackDesign
import com.gunjoron.pathey.widget.designs.SunArcDesign
import com.gunjoron.pathey.widget.designs.TripleCalendarDesign
import com.gunjoron.pathey.widget.render.*
import com.gunjoron.pathey.widget.theme.Look
import com.gunjoron.pathey.widget.theme.Palettes
import com.gunjoron.pathey.widget.theme.Variant
import kotlin.math.min

/**
 * পুরো উইজেট একটাই জায়গায় আঁকা হয় — হোমস্ক্রিন উইজেট (বিটম্যাপ) এবং হাবের লাইভ প্রিভিউ, দুটোতেই
 * একই কোড, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু একরকম।
 *
 * সব মাপ/অবস্থান আপনার ডিজাইন শিটের SVG ইউনিটে (যেমন ডিজাইন ১ কার্ড = ১১১৪.২৫ × ৬০৮.১৬)।
 * live = true  → ঘড়ি ও কাউন্টার সরাসরি আঁকা হয় (প্রিভিউ, প্রতি সেকেন্ডে রিড্র)।
 * live = false → ঘড়ি/কাউন্টারের জায়গায় ফাঁকা রেখে Overlay ফেরত দেয় (হোমস্ক্রিনে TextClock/Chronometer বসে)।
 */
object WidgetRenderer {
    const val PAD = 23f            // কাস্টম প্যানেল কার্ডের চেয়ে যতটা বড়

    private const val PANEL_R = 48f

    fun cardW(d: Int) = when (d) { 3 -> 981.41f; 4, 5, 6, 7, 8, 9 -> 1000f; else -> 1114.25f }

    /** ডিজাইন ২: নিষিদ্ধ-সময়ের "–" অবস্থায় নিচের ওয়াক্ত-সারি ও লাইন বাদ — কার্ড ছোট হয়ে যায়। */
    const val D2_COMPACT_H = 380f

    const val D1_COMPACT_H = 540f

    fun isCompact(d: Int, snap: Snapshot) = d <= 2 && snap.forbid == 2

    fun cardH(d: Int, compact: Boolean) = if (compact && d == 2) D2_COMPACT_H else if (compact && d == 1) D1_COMPACT_H else cardH(d)

    fun cardH(d: Int) = when (d) { 1 -> 608.16f; 2 -> 445.15f; 3 -> 465.35f; 4 -> 448f; 5 -> 428f; 6 -> 480f; 7 -> 570f; 9 -> 540f; else -> 500f }

    private fun cardRx(d: Int) = when (d) { 1 -> 50.17f; 2 -> 42.93f; 3 -> 41.19f; 4, 5, 6, 7, 8, 9 -> 56f; else -> 50f }

    class Layout(val s: Float, val ox: Float, val oy: Float)

    /** w×h এলাকায় কার্ড (প্যানেলসহ) মাঝখানে, অনুপাত ঠিক রেখে। */
    fun layout(d: Int, w: Float, h: Float, compact: Boolean = false): Layout {
        val cw = cardW(d) + 2 * PAD
        val ch = cardH(d, compact) + 2 * PAD
        val s = min(w / cw, h / ch)
        return Layout(s, (w - cardW(d) * s) / 2f, (h - cardH(d, compact) * s) / 2f)
    }

    fun draw(
        ctx: Context, c: Canvas, w: Float, h: Float,
        look: Look, snap: Snapshot, live: Boolean, nowMs: Long, hideSky: Boolean = false
    ): Overlay {
        Fonts.init(ctx)
        val d = look.design
        val compact = isCompact(d, snap)
        val cw = cardW(d); val chh = cardH(d, compact)
        val lay = layout(d, w, h, compact)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.isLinearText = true
        p.isFilterBitmap = true

        c.save()
        c.translate(lay.ox, lay.oy)
        c.scale(lay.s, lay.s)

        // ১) কাস্টম থিমের পেছনের রঙিন প্যানেল
        if (look.panelColor != 0) {
            p.style = Paint.Style.FILL; p.color = soften(look.panelColor)
            c.drawRoundRect(-PAD, -PAD, cw + PAD, chh + PAD, PANEL_R, PANEL_R, p)
            glass(c, p, -PAD, -PAD, cw + PAD, chh + PAD, PANEL_R)
        }

        // ২) কার্ড (গ্লাস/লাইট) — ট্রান্সপারেন্টে নেই
        val cardFill: Int; val cardStroke: Int
        if (d >= 4) { val pl = Palettes.ofMin(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else if (d == 3) { val pl = Palettes.of3(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else { val pl = Palettes.of12(d, look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        if (cardFill != 0) {
            val rx = cardRx(d)
            p.style = Paint.Style.FILL; p.color = soften(cardFill)
            c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
            if (cardStroke != 0) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = cardStroke
                c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
                p.style = Paint.Style.FILL
            }
            if (look.panelColor == 0) glass(c, p, 0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx)
        }

        // ৩) স্ট্যাটিক আর্ট (লোগো, আইকন-পিল, ঘড়ির টাইল, ডিভাইডার…)
        // (আগের রঙ/স্বচ্ছতা পেইন্টে থেকে গেলে আইকন-লোগোও ফিকে হয়ে যেত — তাই রিসেট)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        if (d <= 2) ClassicDesign.drawArt(c, p, if (snap.sunIsSet) Art.sunsetArt(ctx, d, look.variant) else Art.get(ctx, d, look.variant), d, cw, cardH(d), d == 1 && (look.variant == Variant.LIGHT || look.variant == Variant.NOBG_LIGHT))

        // ৪) ডায়নামিক টেক্সট
        val ov = Overlay()
        // আইকন-মেডালিয়ন (সূর্যোদয়/সেহরি/ইফতার): দিনে সূর্যাস্ত-আইকন (তীর নিচে), রাতে সূর্যোদয়-আইকন (তীর ওপরে)
        val medalArt = if (d in 7..9) (if (snap.sunIsSet) Art.sunsetArt(ctx, 1, look.variant) else Art.get(ctx, 1, look.variant)) else null
        when (d) {
            9 -> DialDesign.draw(ctx, c, p, look, snap, live, nowMs, ov, medalArt!!)
            8 -> StackDesign.draw(ctx, c, p, look, snap, live, nowMs, ov, medalArt!!)
            7 -> EditorialDesign.draw(ctx, c, p, look, snap, live, nowMs, ov, medalArt!!)
            6 -> SunArcDesign.draw(ctx, c, p, look, snap, live, nowMs, ov, hideSky)
            5 -> DashboardDesign.draw(ctx, c, p, look, snap, live, nowMs, ov)
            4 -> MinimalDesign.draw(ctx, c, p, look, snap, live, nowMs, ov)
            3 -> TripleCalendarDesign.draw(c, p, look, snap, live, nowMs, ov)
            else -> ClassicDesign.draw(ctx, c, p, d, look, snap, live, nowMs, ov)
        }

        c.restore()
        return ov
    }

    // ---- ডিজাইন ৬ (সান-আর্ক) আনলক-অ্যানিমেশনের জন্য বাইরে-থেকে-ডাকা সুবিধা ----
    const val SKY_W = SunArcDesign.SKY_W
    const val SKY_H = SunArcDesign.SKY_H
    fun drawSkyFrame(ctx: Context, c: Canvas, look: Look, snap: Snapshot, nowMs: Long, fAnim: Float, scale: Float) =
        SunArcDesign.drawSkyFrame(ctx, c, look, snap, nowMs, fAnim, scale)
    fun skyFraction(snap: Snapshot, nowMs: Long): Float = SunArcDesign.skyFraction(snap, nowMs)
}
