package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.gunjoron.pathey.data.Bn
import com.gunjoron.pathey.data.Snapshot
import java.util.Calendar
import kotlin.math.min

/** ওভারলে (লাইভ) টেক্সটের জায়গা — ডিজাইন-ইউনিটে, কার্ডের বাম-উপরের কোণ থেকে; y = বেসলাইন। */
class TextSpec(val x: Float, val y: Float, val size: Float, val color: Int)

class Overlay {
    var ss: TextSpec? = null
    var s3: TextSpec? = null      // ডিজাইন ৩: ":ss"
    var chrono: TextSpec? = null  // কাউন্টডাউন / কাউন্ট-আপ
}

/**
 * পুরো উইজেট একটাই জায়গায় আঁকা হয় — হোমস্ক্রিন উইজেট (বিটম্যাপ) এবং হাবের লাইভ প্রিভিউ, দুটোতেই
 * একই কোড, তাই প্রিভিউ আর আসল উইজেট সবসময় হুবহু একরকম।
 *
 * সব মাপ/অবস্থান আপনার ডিজাইন শিটের SVG ইউনিটে (যেমন ডিজাইন ১ কার্ড = ১১১৪.২৫ × ৬০৮.১৬)।
 * live = true  → ঘড়ি ও কাউন্টার সরাসরি আঁকা হয় (প্রিভিউ, প্রতি সেকেন্ডে রিড্র)।
 * live = false → ঘড়ি/কাউন্টারের জায়গায় ফাঁকা রেখে Overlay ফেরত দেয় (হোমস্ক্রিনে TextClock/Chronometer বসে)।
 */
object WidgetRenderer {
    const val PAD = 23f            // কাস্টম প্যানেল কার্ডের চেয়ে যতটা বড়
    private const val PANEL_R = 48f

    fun cardW(d: Int) = when (d) { 3 -> 981.41f; 4, 5, 6, 7, 8, 9 -> 1000f; else -> 1114.25f }
    /** ডিজাইন ২: নিষিদ্ধ-সময়ের "–" অবস্থায় নিচের ওয়াক্ত-সারি ও লাইন বাদ — কার্ড ছোট হয়ে যায়। */
    const val D2_COMPACT_H = 380f
    const val D1_COMPACT_H = 540f
    fun isCompact(d: Int, snap: Snapshot) = d <= 2 && snap.forbid == 2
    fun cardH(d: Int, compact: Boolean) = if (compact && d == 2) D2_COMPACT_H else if (compact && d == 1) D1_COMPACT_H else cardH(d)
    fun cardH(d: Int) = when (d) { 1 -> 608.16f; 2 -> 445.15f; 3 -> 465.35f; 4 -> 448f; 5 -> 428f; 6 -> 480f; 7 -> 570f; 9 -> 540f; else -> 500f }
    private fun cardRx(d: Int) = when (d) { 1 -> 50.17f; 2 -> 42.93f; 3 -> 41.19f; 4, 5, 6, 7, 8, 9 -> 56f; else -> 50f }

    class Layout(val s: Float, val ox: Float, val oy: Float)

    /** w×h এলাকায় কার্ড (প্যানেলসহ) মাঝখানে, অনুপাত ঠিক রেখে। */
    fun layout(d: Int, w: Float, h: Float, compact: Boolean = false): Layout {
        val cw = cardW(d) + 2 * PAD
        val ch = cardH(d, compact) + 2 * PAD
        val s = min(w / cw, h / ch)
        return Layout(s, (w - cardW(d) * s) / 2f, (h - cardH(d, compact) * s) / 2f)
    }

    // ডিজাইন ১/২: ৫ ওয়াক্তের কলামের কেন্দ্র (ফজর, যোহর, আসর, মাগরিব, ইশা)
    private val COL_CX = floatArrayOf(137.35f, 342.5f, 542.72f, 771.11f, 984.43f)
    private const val HL_W = 185.78f
    private const val HL_H = 145.83f
    private const val HL_RX = 21.19f
    private const val HL_NAME_DY = -5.82f
    private const val HL_TIME_DY = -6.21f

    private fun formatHms(totalMs: Long): String {
        val t = (if (totalMs < 0) 0 else totalMs) / 1000
        val h = t / 3600; val m = (t / 60) % 60; val s = t % 60
        return Bn.pad2(h.toInt()) + ":" + Bn.pad2(m.toInt()) + ":" + Bn.pad2(s.toInt())
    }

    fun draw(
        ctx: Context, c: Canvas, w: Float, h: Float,
        look: Look, snap: Snapshot, live: Boolean, nowMs: Long, hideSky: Boolean = false
    ): Overlay {
        Fonts.init(ctx)
        val d = look.design
        val compact = isCompact(d, snap)
        val cw = cardW(d); val chh = cardH(d, compact)
        val lay = layout(d, w, h, compact)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.isLinearText = true
        p.isFilterBitmap = true

        c.save()
        c.translate(lay.ox, lay.oy)
        c.scale(lay.s, lay.s)

        // ১) কাস্টম থিমের পেছনের রঙিন প্যানেল
        if (look.panelColor != 0) {
            p.style = Paint.Style.FILL; p.color = soften(look.panelColor)
            c.drawRoundRect(-PAD, -PAD, cw + PAD, chh + PAD, PANEL_R, PANEL_R, p)
            glass(c, p, -PAD, -PAD, cw + PAD, chh + PAD, PANEL_R)
        }

        // ২) কার্ড (গ্লাস/লাইট) — ট্রান্সপারেন্টে নেই
        val cardFill: Int; val cardStroke: Int
        if (d >= 4) { val pl = Palettes.ofMin(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else if (d == 3) { val pl = Palettes.of3(look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        else { val pl = Palettes.of12(d, look.variant); cardFill = pl.cardFill; cardStroke = pl.cardStroke }
        if (cardFill != 0) {
            val rx = cardRx(d)
            p.style = Paint.Style.FILL; p.color = soften(cardFill)
            c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
            if (cardStroke != 0) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = cardStroke
                c.drawRoundRect(0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx, rx, p)
                p.style = Paint.Style.FILL
            }
            if (look.panelColor == 0) glass(c, p, 0.5f, 0.5f, cw - 0.5f, chh - 0.5f, rx)
        }

        // ৩) স্ট্যাটিক আর্ট (লোগো, আইকন-পিল, ঘড়ির টাইল, ডিভাইডার…)
        // (আগের রঙ/স্বচ্ছতা পেইন্টে থেকে গেলে আইকন-লোগোও ফিকে হয়ে যেত — তাই রিসেট)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        if (d <= 2) drawArt(c, p, Art.get(ctx, d, look.variant), d, cw, cardH(d), d == 1 && (look.variant == Variant.LIGHT || look.variant == Variant.NOBG_LIGHT))

        // ৪) ডায়নামিক টেক্সট
        val ov = Overlay()
        if (d == 9) drawD9(ctx, c, p, look, snap, live, nowMs, ov, Art.get(ctx, 1, look.variant)) else if (d == 8) drawD8(ctx, c, p, look, snap, live, nowMs, ov, Art.get(ctx, 1, look.variant)) else if (d == 7) drawD7(ctx, c, p, look, snap, live, nowMs, ov, Art.get(ctx, 1, look.variant)) else if (d == 6) drawD6(ctx, c, p, look, snap, live, nowMs, ov, hideSky) else if (d == 5) drawD5(ctx, c, p, look, snap, live, nowMs, ov) else if (d == 4) drawMin(ctx, c, p, look, snap, live, nowMs, ov) else if (d == 3) drawD3(c, p, look, snap, live, nowMs, ov) else drawD12(ctx, c, p, d, look, snap, live, nowMs, ov)

        c.restore()
        return ov
    }

    // ------------------------------------------------------------------------------------------
    /** সূর্যোদয় ও ইফতার (সূর্যাস্ত) পিল সামান্য ডানে — আর্টের ওই দুই টুকরো আলাদা সরিয়ে আঁকা। */
    private const val PILL_SHIFT = 14f
    private val SUNRISE_R = Rect(820, 25, 1072, 175)
    private val IFTAR_R = Rect(806, 222, 1060, 358)
    private val LOGO2_R = Rect(26, 16, 208, 198)   // ডিজাইন ২-এর আর্টে বসানো নীল চৌকো লোগো (এটা বাদ দিয়ে নতুন লোগো আঁকা হয়)

    private val D1_TILES = arrayOf(floatArrayOf(63f, 222f, 191f, 350f), floatArrayOf(204f, 222f, 332f, 350f), floatArrayOf(344f, 281f, 412f, 349f))

    private fun drawArt(c: Canvas, p: Paint, art: Bitmap, d: Int, cw: Float, chh: Float, softTiles: Boolean = false) {
        c.save()
        c.clipOutRect(SUNRISE_R.left.toFloat(), SUNRISE_R.top.toFloat(), SUNRISE_R.right.toFloat(), SUNRISE_R.bottom.toFloat())
        c.clipOutRect(LOGO2_R.left.toFloat(), LOGO2_R.top.toFloat(), LOGO2_R.right.toFloat(), LOGO2_R.bottom.toFloat())
        if (d == 1) c.clipOutRect(IFTAR_R.left.toFloat(), IFTAR_R.top.toFloat(), IFTAR_R.right.toFloat(), IFTAR_R.bottom.toFloat())
        if (softTiles) for (t in D1_TILES) c.clipOutRect(t[0] - 2f, t[1] - 2f, t[2] + 2f, t[3] + 2f)
        c.drawBitmap(art, null, RectF(0f, 0f, cw, chh), p)
        c.restore()
        if (softTiles) {   // হালকা মোডে ঘড়ির টাইল গাঢ় নীলের বদলে নরম হালকা নীল — চোখে লাগে না
            p.style = Paint.Style.FILL; p.shader = null; p.color = 0x24244866   // কার্ডের রঙের ওপর খুব হালকা নীলচে ছায়া — শুধু বোঝা যায় শেপ আছে
            for (t in D1_TILES) c.drawRoundRect(t[0] - 0.5f, t[1] - 0.5f, t[2] + 0.5f, t[3] + 0.5f, 22f, 22f, p)
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
        }
        fun piece(r: Rect) = c.drawBitmap(art, r, RectF(r.left + PILL_SHIFT, r.top.toFloat(), r.right + PILL_SHIFT, r.bottom.toFloat()), p)
        piece(SUNRISE_R)
        if (d == 1) piece(IFTAR_R)
    }

    /** কার্ড/প্যানেলের রঙের অস্বচ্ছতা সামান্য কমানো — যাতে পেছনের ওয়ালপেপার হালকা ঝাপসা দেখা যায়। */
    private const val GLASS_ALPHA = 0.85f
    private fun soften(color: Int): Int {
        val a = ((color ushr 24) * GLASS_ALPHA).toInt().coerceIn(0, 255)
        return (a shl 24) or (color and 0xFFFFFF)
    }

    /** কোনো গ্রেডিয়েন্ট নয় — শুধু খুব হালকা ফ্রস্ট-দানা, যাতে ঝাপসা কাচের অনুভূতি আসে। */
    private val grain: Bitmap by lazy {
        val n = 96
        val px = IntArray(n * n)
        val r = java.util.Random(7)
        for (i in px.indices) {
            val a = r.nextInt(15)                       // ০–১৪ / ২৫৫ — হালকা
            px[i] = (a shl 24) or (if (r.nextBoolean()) 0xFFFFFF else 0x000000)
        }
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun glass(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float) {
        p.style = Paint.Style.FILL
        p.shader = BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        p.shader = null
    }

    private fun measure(p: Paint, s: String, tf: Typeface, size: Float): Float {
        p.typeface = tf; p.textSize = size
        return p.measureText(s)
    }

    private fun text(c: Canvas, p: Paint, s: String, x: Float, y: Float, size: Float, color: Int,
                     tf: Typeface, align: Paint.Align = Paint.Align.LEFT) {
        p.style = Paint.Style.FILL
        p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
        c.drawText(s, x, y, p)
        p.textAlign = Paint.Align.LEFT
    }

    // ------------------------------------------------------------------------------------------
    private fun drawD12(ctx: Context, c: Canvas, p: Paint, d: Int, look: Look, snap: Snapshot, live: Boolean,
                        nowMs: Long, ov: Overlay) {
        val pal = Palettes.of12(d, look.variant)
        val yOff = if (d == 1) 0f else -160f   // নিচের অংশ ডিজাইন ২-এ ১৬০ ইউনিট উপরে

        // ---- হিজরি দিন (বড়) + হিজরি মাস-সাল
        val dayX = 216.32f
        // ইংরেজি-আগে ট্রগল চালু থাকলে বড় অংশে ইংরেজি তারিখ, নিচের লাইনে হিজরি (আগের ইংরেজির জায়গায়)
        val bigDay = if (snap.gregFirst) snap.gregDay else snap.hijriDay
        val bigMonth = if (snap.gregFirst) snap.gregMonth + " " + snap.gregYear else snap.hijriMonthYear
        text(c, p, bigDay, dayX, 103.57f, 110f, pal.day, Fonts.bold)
        val dayAdv = measure(p, bigDay, Fonts.bold, 110f)
        val hx = dayX + dayAdv + 10.53f
        var hs = 55f
        val hw = measure(p, bigMonth, Fonts.bold, hs)
        val hAvail = 825f - hx
        if (hw > hAvail) hs = 55f * hAvail / hw
        text(c, p, bigMonth, hx, 102.29f, hs, pal.hijri, Fonts.bold)

        // ---- ইংরেজি তারিখ | বাংলা তারিখ (মাঝে ডিভাইডার)
        var ds = 52f
        val g1 = if (snap.gregFirst) snap.hijriLine else snap.gregorianLine; val g2 = snap.banglaLine
        var w1 = measure(p, g1, Fonts.bold, ds); var w2 = measure(p, g2, Fonts.bold, ds)
        val total = w1 + DATE_SEP + w2
        val maxW = 612f
        val f = if (total > maxW) maxW / total else 1f
        if (f < 1f) { ds *= f; w1 *= f; w2 *= f }
        text(c, p, g1, dayX, 162.99f, ds, pal.date, Fonts.bold)
        // দাগ = লেখার রঙ, একটু ফিকে; দুই পাশে ফাঁক যাতে আলাদা বোঝা যায়
        p.style = Paint.Style.FILL; p.color = (pal.date and 0xFFFFFF) or 0xBF000000.toInt()
        val dvx = dayX + w1 + (DATE_SEP - 2.2f) / 2f * f
        c.drawRect(dvx, 123.4f, dvx + 2.2f * f, 123.4f + 45.19f, p)
        text(c, p, g2, dayX + w1 + DATE_SEP * f, 162.99f, ds, pal.date, Fonts.bold)

        // ---- সূর্যোদয় পিল
        text(c, p, "সূর্যোদয়", 1006.18f + PILL_SHIFT, 89.51f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
        text(c, p, snap.sunrise, 1005.07f + PILL_SHIFT, 146.66f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

        // ---- ডিজাইন ১/২: নতুন লোগো — গোল-কোণার চৌকো (স্কুইরকল) আকারে, ভেতরে আমাদের লোগোর পাথ
        run {
            val lightLogo = lum(pal.date) > 150f
            val ink = pal.date
            val lx = 116f; val ly = 107f; val half = 79f; val rr = 46f
            p.shader = null
            p.style = Paint.Style.FILL; p.color = (ink and 0xFFFFFF) or 0x14000000
            c.drawRoundRect(lx - half, ly - half, lx + half, ly + half, rr, rr, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = ink
            c.drawRoundRect(lx - half, ly - half, lx + half, ly + half, rr, rr, p)
            p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
            val lg = Art.logoPath(ctx, lightLogo)
            val lh = 104f; val lw = lh * lg.width / lg.height
            c.drawBitmap(lg, null, RectF(lx - lw / 2f, ly - lh / 2f, lx + lw / 2f, ly + lh / 2f), p)
        }

        // ---- ডিজাইন ১: ঘড়ি ও সাহরী/ইফতার
        if (d == 1) {
            text(c, p, "সেহরি", 698.77f, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.sehri, 703.71f, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)
            text(c, p, "ইফতার", 995.9f + PILL_SHIFT, 279.37f, 52.19f, pal.pillLabel, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.iftar, 992.11f + PILL_SHIFT, 331.96f, 63.36f, pal.pillTime, Fonts.bold, Paint.Align.CENTER)

            val ampm = if (snap.isPm) "PM" else "AM"
            text(c, p, ampm, 424.41f, 299.25f, 40f, pal.pm, Fonts.bebas)
            // ঘণ্টা ও মিনিট বিটম্যাপেই (ডিজাইনের ফন্টে) আঁকা — প্রতি মিনিটের শুরুতে উইজেট নতুন করে আঁকা হয়।
            // শুধু সেকেন্ড লাইভ (TextClock), কারণ প্রতি সেকেন্ডে অ্যাপ জাগানো যাবে না।
            val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
            var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
            text(c, p, if (hh < 10) "0$hh" else "$hh", 65.32f, 332.48f, 136.17f, pal.clock, Fonts.bebas)
            text(c, p, pad2a(cal.get(Calendar.MINUTE)), 218.54f, 334.48f, 125f, pal.clock, Fonts.bebas)
            if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), 353.03f, 340.13f, 65f, pal.clock, Fonts.bebas)
            else ov.ss = TextSpec(0f, 0f, 0f, pal.clock)
        }

        // ---- পাঁচ ওয়াক্ত
        val nameY = 448.74f + yOff
        val timeY = 502.65f + yOff
        val hlY = 381.16f + yOff
        for (i in 0 until 5) {
            val cx = COL_CX[i]
            val hl = (snap.current == i) && snap.forbid == 0
            if (hl) {
                p.style = Paint.Style.FILL; p.color = pal.hlFill
                c.drawRoundRect(cx - HL_W / 2f, hlY, cx + HL_W / 2f, hlY + HL_H, HL_RX, HL_RX, p)
            }
            text(c, p, Bn.PRAYER_NAMES[i], cx, nameY + (if (hl) HL_NAME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.name, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, timeY + (if (hl) HL_TIME_DY else 0f), 60f,
                if (hl) pal.hlText else pal.time, Fonts.bold, Paint.Align.CENTER)
        }

        if (snap.forbid == 2) return   // "–" সময়: শুধু নিচের কাউন্টডাউন লাইন বাদ (কার্ডও ছোট); ওয়াক্তের নাম-সময় থাকে

        // ---- নিচের লাইন: "<ওয়াক্ত> -এর সময় অতিবাহিত: 00:20:59"
        val nowY = 577.67f + yOff
        val inForbid = snap.forbid == 1
        val warn = if (lum(pal.name) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val prefix = if (inForbid) "নিষিদ্ধ সময় বাকি:"
                     else if (snap.running) snap.currentName + " -এর সময় অতিবাহিত:"
                     else snap.currentName + " -এর সময় শুরু হতে বাকি:"
        var ps = 50f; val ds2 = 40f
        val digitsText = if (live) formatHms(
            if (inForbid) snap.forbidEndMs - nowMs else if (snap.running) nowMs - snap.periodStartMs else snap.periodEndMs - nowMs) else ""
        // অঙ্ক সবসময় একই জায়গায় (লাইভ Chronometer-এর বক্স স্থির), লেবেল তার বাঁ-পাশে ডান-সারিবদ্ধ
        val labelEnd = CH12_X - CH12_GAP
        var pw = measure(p, prefix, if (inForbid) Fonts.bold else Fonts.regular, ps)
        val maxLabel = labelEnd - 40f
        if (pw > maxLabel) { ps *= maxLabel / pw; pw = maxLabel }
        text(c, p, prefix, labelEnd - pw, nowY, ps, if (inForbid) warn else pal.now, if (inForbid) Fonts.bold else Fonts.regular)
        if (live) text(c, p, digitsText, CH12_X, nowY, ds2, pal.nowTime, Fonts.bebas)
        else ov.chrono = TextSpec(0f, 0f, 0f, pal.nowTime)
    }

    // লাইভ কাউন্টারের স্থির বাম-কিনারা (ডিজাইন-ইউনিট) ও লেবেলের ফাঁক
    const val CH12_X = 710f; const val CH12_GAP = 10f
    const val CH3_X = 548f
    private const val DATE_SEP = 30f      // ইংরেজি ও বাংলা তারিখের মাঝে মোট ফাঁক (দাগসহ)
    private const val CLOCK_X = 85f; private const val CLOCK_W = 621f; private const val CLOCK_BASE = 200f
    private const val SIDE_CX = 838f; private const val AMPM_BASE = 80f; private const val SEC_BASE = 197f

    private fun cwOf(d: Int) = cardW(d)
    private fun pad2a(n: Int) = if (n < 10) "0$n" else n.toString()

    // ------------------------------------------------------------------------------------------
    private fun drawD3(c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean,
                       nowMs: Long, ov: Overlay) {
        val pal = Palettes.of3(look.variant)
        val cw = cardW(3)
        val rule = (pal.month and 0xFFFFFF) or 0xBF000000.toInt()   // লেখার রঙ, সামান্য ফিকে
        val ruleW = 1.8f

        // ১) বড় ঘড়ি (বাঁয়ে), AM/PM + সেকেন্ড (ডানে, একটার ওপর আরেকটা)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val clockSize = CLOCK_W / measure(p, "00:00", Fonts.clockBold, 100f) * 100f   // সবচেয়ে চওড়া "00:00" ধরে মাপ
        // ঘণ্টা | কোলন | মিনিট আলাদা আঁকা — কোলন ঠিক অঙ্কের উচ্চতার মাঝখানে (ফন্টে সেটা নিচু বসে)
        p.typeface = Fonts.clockBold; p.textSize = clockSize
        val rb = Rect(); p.getTextBounds("0", 0, 1, rb)
        val digitMid = (rb.top + rb.bottom) / 2f
        val cb = Rect(); p.getTextBounds(":", 0, 1, cb)
        val colonMid = (cb.top + cb.bottom) / 2f
        val colonDy = digitMid - colonMid
        val hhS = hm.substring(0, 2); val mmS = hm.substring(3)
        val hhW = measure(p, hhS, Fonts.clockBold, clockSize)
        val colonW = measure(p, ":", Fonts.clockBold, clockSize)
        text(c, p, hhS, CLOCK_X, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, ":", CLOCK_X + hhW, CLOCK_BASE + colonDy, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, mmS, CLOCK_X + hhW + colonW, CLOCK_BASE, clockSize, pal.clock, Fonts.clockBold)
        text(c, p, if (snap.isPm) "PM" else "AM", SIDE_CX, AMPM_BASE, 80f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), SIDE_CX, SEC_BASE, 130f, pal.clock, Fonts.clockReg, Paint.Align.CENTER)
        else ov.s3 = TextSpec(0f, 0f, 0f, pal.clock)

        // ২) তিন কলামের তারিখ: ইংরেজি | হিজরি | বাংলা — সমান তিন ভাগ
        class Col(val day: String, val month: String, val year: String)
        val cols = arrayOf(
            Col(snap.gregDay, snap.gregMonth, snap.gregYear),
            Col(snap.hijriDay, snap.hijriMonth, snap.hijriYear),
            Col(snap.banglaDay, snap.banglaMonth, snap.banglaYear)
        )
        val colW = cw / 3f
        p.style = Paint.Style.FILL; p.color = rule
        for (i in 1..2) c.drawRect(colW * i - ruleW / 2f, 248f, colW * i + ruleW / 2f, 399f, p)
        for ((i, col) in cols.withIndex()) {
            val cx = colW * (i + 0.5f)
            text(c, p, col.day, cx, 312f, 100f, pal.day, Fonts.bold, Paint.Align.CENTER)
            val maxW = colW - 36f
            var ms = 52f
            val mw = measure(p, col.month, Fonts.regular, ms)
            if (mw > maxW) ms *= maxW / mw
            text(c, p, col.month, cx, 360f, ms, pal.month, Fonts.regular, Paint.Align.CENTER)
            text(c, p, col.year, cx, 392f, 44f, pal.month, Fonts.regular, Paint.Align.CENTER)
        }

        // ৩) নিচের লাইন: ── ইশা [চলছে] সময় বাকি: 01:54:56 ──
        //    অঙ্ক স্থির জায়গায় (লাইভ Chronometer), বাকি সব তার বাঁয়ে ডান-সারিবদ্ধ; দুই পাশে রেখা।
        //    নিষিদ্ধ সময়ে নাম = "নিষিদ্ধ সময়" (লাল-কমলা, বোল্ড), চলছে-ব্যাজ নেই; সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত নাম ও টাইমার = "–"
        val warn = if (lum(pal.month) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val label = if (snap.running || snap.forbid != 0) "সময় বাকি:" else "শুরু হতে বাকি:"
        val nameTxt = when (snap.forbid) { 1 -> "নিষিদ্ধ সময়"; 2 -> "–"; else -> snap.currentName }
        val nameTf = if (snap.forbid == 1) Fonts.bold else Fonts.regular
        val nameCol = when (snap.forbid) { 1 -> warn; 2 -> pal.subLabel; else -> pal.prayer }
        val lw = measure(p, label, Fonts.regular, 27f)
        val nameW = measure(p, nameTxt, nameTf, 36f)
        val badgeW = 70.25f
        var x = CH3_X - 8f - lw
        text(c, p, label, x, 436f, 27f, pal.subLabel, Fonts.regular)
        if (snap.running && snap.forbid == 0) {
            x -= 8f + badgeW
            p.style = Paint.Style.FILL; p.color = 0xFFFCB010.toInt()
            c.drawRoundRect(x, 412f, x + badgeW, 440.05f, 14.02f, 14.02f, p)
            text(c, p, "চলছে", x + 10.34f, 435f, 26.95f, pal.badgeText, Fonts.regular)
            p.style = Paint.Style.FILL; p.color = 0xFFFF0000.toInt()
            c.drawCircle(x + 60.98f, 426.4f, 3.15f, p)
        }
        x -= 6f + nameW
        text(c, p, nameTxt, x, 437f, 36f, nameCol, nameTf)
        if (snap.forbid == 2) {
            text(c, p, "–", CH3_X, 436f, 34f, pal.subTime, Fonts.bold)   // টাইমারের জায়গায় "–"
        } else {
            val endMs = if (snap.forbid == 1) snap.forbidEndMs else snap.periodEndMs
            if (live) text(c, p, formatHms(endMs - nowMs), CH3_X, 436f, 34f, pal.subTime, Fonts.bebas)
            else ov.chrono = TextSpec(0f, 0f, 0f, pal.subTime)
        }
        // রেখা
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(24f, 426f - ruleW / 2f, x - 10f, 426f + ruleW / 2f, p)
        c.drawRect(CH3_X + 108f + 10f, 426f - ruleW / 2f, cw - 24f, 426f + ruleW / 2f, p)
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৪ (মিনিমাল) ও ৫ (স্ট্রিপ) — কোনো আর্ট/লাইভ ওভারলে নেই; সবকিছু বিটম্যাপে, প্রতি মিনিটে নতুন।
    // ------------------------------------------------------------------------------------------
    /**
     * "০১:২৩:৫৬ বাকি" — অঙ্কগুলো লাইভ কাউন্টডাউন (প্রিভিউতে আঁকা, হোমস্ক্রিনে Chronometer), "বাকি" বিটম্যাপে।
     * dr = অঙ্ক-বক্সের ডান কিনারা (স্থির; genlayout.py-র REM বক্সের সাথে মেলাতে হবে), লেবেল তার ১০ ইউনিট ডানে।
     */
    private fun remLine(c: Canvas, p: Paint, ov: Overlay, live: Boolean, snap: Snapshot, nowMs: Long,
                        dr: Float, base: Float, dsz: Float, lsz: Float, dcol: Int, lcol: Int,
                        endMs: Long = snap.periodEndMs) {
        if (live) text(c, p, formatHms(endMs - nowMs), dr, base, dsz, dcol, Fonts.bebas, Paint.Align.RIGHT)
        else ov.chrono = TextSpec(0f, 0f, 0f, dcol)
        text(c, p, "বাকি", dr + 10f, base, lsz, lcol, Fonts.regular)
    }

    private val WEEKDAYS = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")
    private fun weekday(nowMs: Long): String {
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        return WEEKDAYS[cal.get(Calendar.DAY_OF_WEEK) - 1]
    }

    /** পাতলা ঘড়ি: ঘণ্টা | কোলন (অঙ্কের মাঝ বরাবর) | মিনিট। ফেরত: মোট প্রস্থ। */
    private fun slimClock(c: Canvas, p: Paint, hm: String, x: Float, base: Float, size: Float, color: Int): Float {
        p.typeface = Fonts.outfit; p.textSize = size
        val r0 = Rect(); p.getTextBounds("0", 0, 1, r0)
        val r1 = Rect(); p.getTextBounds(":", 0, 1, r1)
        val dy = (r0.top + r0.bottom) / 2f - (r1.top + r1.bottom) / 2f
        val a = hm.substring(0, 2); val b = hm.substring(3)
        val aw = measure(p, a, Fonts.outfit, size); val cw = measure(p, ":", Fonts.outfit, size)
        val bw = measure(p, b, Fonts.outfit, size)
        text(c, p, a, x, base, size, color, Fonts.outfit)
        text(c, p, ":", x + aw, base + dy, size, color, Fonts.outfit)
        text(c, p, b, x + aw + cw, base, size, color, Fonts.outfit)
        return aw + cw + bw
    }

    private fun bar(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
        p.style = Paint.Style.FILL; p.color = track
        c.drawRoundRect(x0, y, x1, y + h, h / 2f, h / 2f, p)
        val fx = x0 + (x1 - x0) * frac.coerceIn(0f, 1f)
        if (fx - x0 > h) { p.color = fill; c.drawRoundRect(x0, y, fx, y + h, h / 2f, h / 2f, p) }
    }

    private fun drawMin(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(4)
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val ampm = if (snap.isPm) "PM" else "AM"
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val L = 40f; val R = cw - 40f
        val colW = (R - L) / 5f

        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f4 = snap.forbid          // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত

        // ওপরের সারি: বাঁয়ে লোগো + ইংরেজি তারিখ (ব্র্যান্ড-লকআপ) | ডানে হিজরি তারিখ — বোল্ড
        val dsz = 39f
        logoRing(ctx, c, p, m, L + 29f, 64f, 29f)
        text(c, p, snap.gregorianLine, L + 74f, 80f, dsz, m.secondary, Fonts.bold)
        text(c, p, snap.hijriDay + " " + snap.hijriMonthYear, R, 80f, dsz, m.secondary, Fonts.bold, Paint.Align.RIGHT)

        // বড় পাতলা ঘড়ি (ডান কিনারা স্থির) + ডানে AM/PM, তার ঠিক নিচে লাইভ সেকেন্ড
        val clockSize = 172f
        val clockEnd = L - 6f + (measure(p, "00", Fonts.outfit, clockSize) * 2f + measure(p, ":", Fonts.outfit, clockSize))
        val hmNow = hm
        val cwNow = measure(p, hmNow.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hmNow.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hmNow, clockEnd - cwNow, 250f, clockSize, m.primary)
        val sx = clockEnd + 22f + measure(p, "00", Fonts.outfit, 44f) / 2f
        text(c, p, ampm, sx, 202f, 44f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), sx, 250f, 44f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ডানে চলমান ওয়াক্ত: নাম বড়, ডানে গোল-কোণা "চলমান" বক্স। নিষিদ্ধ সময়ে "নিষিদ্ধ সময়"; মাঝের ফাঁকে নাম ও টাইমার "–"
        val bx0 = clockEnd + 22f + 90f
        val chipTxt = "চলমান"; val chipSz = 26f
        val chipW = measure(p, chipTxt, Fonts.bold, chipSz) + 32f
        when (f4) {
            0 -> {
                val maxName = R - bx0 - chipW - 16f
                val nsz = fit(p, snap.currentName, Fonts.bold, 84f, maxName)
                val nw = measure(p, snap.currentName, Fonts.bold, nsz)
                val x0 = R - chipW - 16f - nw
                text(c, p, snap.currentName, x0, 204f, nsz, m.accent, Fonts.bold)
                val cx0 = R - chipW
                tile(c, p, cx0, 156f, R, 200f, 22f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x80000000.toInt())
                text(c, p, chipTxt, cx0 + chipW / 2f, 188f, chipSz, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 898f, 254f, 44f, 38f, m.primary, m.primary)
            }
            1 -> {
                val nsz = fit(p, "নিষিদ্ধ সময়", Fonts.bold, 84f, R - bx0)
                text(c, p, "নিষিদ্ধ সময়", R, 204f, nsz, warn, Fonts.bold, Paint.Align.RIGHT)
                remLine(c, p, ov, live, snap, nowMs, 898f, 254f, 44f, 38f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, "–", R, 204f, 84f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
                text(c, p, "–", R, 254f, 50f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
        }

        // প্রগ্রেস বার: স্বাভাবিকে ওয়াক্তের; নিষিদ্ধ সময়ে ওই সময়ের (লাল-কমলা); মাঝের ফাঁকে শুধু ফাঁকা ট্র্যাক
        val barFrac = when (f4) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        bar(c, p, L, R, 296f, 8f, barFrac, m.track, if (f4 == 1) warn else m.accent)

        // পাঁচ ওয়াক্ত (নিষিদ্ধ সময়ে ও মাঝের ফাঁকে কোনোটাই নির্বাচিত/হাইলাইট নয়)
        for (i in 0 until 5) {
            val cx = L + colW * (i + 0.5f)
            val on = f4 == 0 && snap.current == i
            text(c, p, Bn.PRAYER_NAMES[i], cx, 360f, 39f, if (on) m.accent else m.secondary, Fonts.bold, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cx, 416f, 48f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৫ (ড্যাশবোর্ড): সেকেন্ডসহ ঘড়ি · তিন তারিখ (ইংরেজি/হিজরি/বাংলা) · সাহরি-ইফতার · চলমান ওয়াক্ত · পাঁচ ওয়াক্ত
    // শুধু সেকেন্ডটা লাইভ (TextClock "ss"); বাকি সব বিটম্যাপে।
    // ------------------------------------------------------------------------------------------
    private const val D5_CLOCK_W = 380f; private const val D5_BASE = 224f
    const val D5_SIDE_CX = 456f
    private const val D5_DIV = 548f; private const val D5_RX = 572f

    private fun fit(p: Paint, s: String, tf: Typeface, size: Float, maxW: Float): Float {
        val w = measure(p, s, tf, size)
        return if (w > maxW) size * maxW / w else size
    }

    private fun drawD5(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(5)
        val L = 40f; val R = cw - 40f
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        val hm = (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000

        // ১) বার (ঘড়ির ওপরে) + ঘড়ি (বাঁয়ে) + AM/PM ও সেকেন্ড (একটার নিচে আরেকটা)
        logoRing(ctx, c, p, m, L + 28f, 52f, 26f)
        text(c, p, weekday(nowMs), L + 70f, 64f, 36f, m.accent, Fonts.bold)
        val clockSize = D5_CLOCK_W / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hm, L - 4f, D5_BASE, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", D5_SIDE_CX, 148f, 38f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(cal.get(Calendar.SECOND)), D5_SIDE_CX, 222f, 66f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ২) ডানে তিন তারিখ — লেবেল + তারিখ
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, 44f, D5_DIV + 1f, 258f, p)
        val dates = arrayOf(
            "ইংরেজি" to snap.gregorianLine,
            "হিজরি" to (snap.hijriDay + " " + snap.hijriMonthYear),
            "বাংলা" to snap.banglaLine
        )
        for ((i, dv) in dates.withIndex()) {
            val y0 = 66f + 72f * i
            text(c, p, dv.first, D5_RX, y0, 28f, m.accent, Fonts.regular)
            val sz = fit(p, dv.second, Fonts.bold, 39f, R - D5_RX)
            text(c, p, dv.second, D5_RX, y0 + 38f, sz, m.primary, Fonts.bold)
        }

        // ৩) সেহরি / ইফতার (বক্স ছাড়া: সরু অ্যাকসেন্ট দাগ + পাতলা ডিভাইডার) + চলমান ওয়াক্ত
        val ty = 282f
        val tiles = arrayOf("সেহরি" to snap.sehri, "ইফতার" to snap.iftar)
        val gx = floatArrayOf(L + 4f, L + 262f)
        for ((i, t) in tiles.withIndex()) {
            val x0 = gx[i]
            p.style = Paint.Style.FILL; p.color = rule      // তারিখের পাশের দাগের মতোই চিকন
            c.drawRect(x0 - 1f, ty + 8f, x0 + 1f, ty + 92f, p)
            text(c, p, t.first, x0 + 24f, ty + 38f, 31f, m.secondary, Fonts.regular)
            text(c, p, t.second, x0 + 24f, ty + 88f, 50f, m.primary, Fonts.bold)
        }
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(D5_DIV - 1f, ty + 8f, D5_DIV + 1f, ty + 92f, p)
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f5 = snap.forbid     // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("–")
        text(c, p, if (f5 == 1) "নামাজ আদায় নিষেধ" else "চলমান ওয়াক্ত", D5_RX, ty + 32f, 29f, if (f5 == 1) warn else m.secondary, Fonts.regular)
        when (f5) {
            2 -> {
                text(c, p, "–", D5_RX, ty + 76f, 56f, m.secondary, Fonts.bold)
                text(c, p, "–", R, ty + 76f, 44f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", D5_RX, ty + 76f, 50f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 912f, ty + 76f, 32f, 30f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, D5_RX, ty + 76f, 52f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 912f, ty + 76f, 32f, 30f, m.primary, m.primary)
            }
        }
        val f5Frac = when (f5) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        bar(c, p, D5_RX, R, ty + 92f, 8f, f5Frac, m.track, if (f5 == 1) warn else m.accent)
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৬ (সান-আর্ক): সূর্যোদয় থেকে সূর্যাস্তের আর্ক, তাতে সূর্যের বর্তমান অবস্থান; ভেতরে ঘড়ি;
    // দুই প্রান্তে সূর্যোদয়/সূর্যাস্ত, মাঝে চলমান ওয়াক্ত; নিচে পাঁচ ওয়াক্তের স্ট্রিপ।
    // ------------------------------------------------------------------------------------------
    private fun onColor(bg: Int): Int {
        val r = (bg shr 16) and 255; val g = (bg shr 8) and 255; val b = bg and 255
        return if (0.299f * r + 0.587f * g + 0.114f * b > 150f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
    }

    /** ৪-কোনা ছোট তারা (ভেক্টর-আইকনের মতো) */
    private fun sparkle(c: Canvas, p: Paint, x: Float, y: Float, r: Float, color: Int) {
        val k = r * 0.3f
        val path = Path()
        path.moveTo(x, y - r); path.lineTo(x + k, y - k); path.lineTo(x + r, y); path.lineTo(x + k, y + k)
        path.lineTo(x, y + r); path.lineTo(x - k, y + k); path.lineTo(x - r, y); path.lineTo(x - k, y - k)
        path.close()
        p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    /** সূর্য: গোল চাকতি + ৮টা গোল-মাথা রশ্মি (ফ্ল্যাট ভেক্টর আইকন) */
    private fun sun(c: Canvas, p: Paint, cx: Float, cy: Float, color: Int, halo: Boolean) {
        p.style = Paint.Style.FILL
        if (halo) {   // লাইট থিমে আভা/ছায়া নেই
            p.color = (color and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, 44f, p)
            p.color = (color and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, 33f, p)
        }
        p.color = color; c.drawCircle(cx, cy, 14f, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.5f; p.color = color
        for (i in 0 until 8) {
            val t = Math.PI / 4.0 * i
            val ca = Math.cos(t).toFloat(); val sa = Math.sin(t).toFloat()
            c.drawLine(cx + ca * 21f, cy + sa * 21f, cx + ca * 28.5f, cy + sa * 28.5f, p)
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
    }

    /**
     * চাঁদ: মসৃণ অর্ধচন্দ্র (বড় বৃত্ত − ছোট বৃত্ত) + দুটো ছোট তারা (ফ্ল্যাট ভেক্টর আইকন)।
     * rotDeg: চাঁদের "কামড়" যেদিকে মুখ করে (চলার দিক); পেছনের মোটা গোল কিনারা আর্কের দাগের সাথে মেলে।
     */
    private fun moon(c: Canvas, p: Paint, cx: Float, cy: Float, rad: Float, glow: Int, body: Int, halo: Boolean, rotDeg: Float) {
        p.style = Paint.Style.FILL
        if (halo) {   // লাইট থিমে আভা/ছায়া নেই
            p.color = (glow and 0xFFFFFF) or 0x22000000; c.drawCircle(cx, cy, rad + 22f, p)
            p.color = (glow and 0xFFFFFF) or 0x33000000; c.drawCircle(cx, cy, rad + 11f, p)
        }
        c.save()
        c.translate(cx, cy); c.rotate(rotDeg)
        val d = rad * 0.40f; val r2 = rad * 0.86f
        val x = (d * d + rad * rad - r2 * r2) / (2f * d)
        val y = Math.sqrt((rad * rad - x * x).toDouble()).toFloat()
        val aR = Math.atan2(y.toDouble(), x.toDouble())
        val bR = Math.atan2(y.toDouble(), (x - d).toDouble())
        val a = Math.toDegrees(aR).toFloat(); val b2 = Math.toDegrees(bR).toFloat()
        val path = Path()
        path.moveTo(rad * Math.cos(-aR).toFloat(), rad * Math.sin(-aR).toFloat())
        path.arcTo(RectF(-rad, -rad, rad, rad), -a, -(360f - 2f * a))
        path.arcTo(RectF(d - r2, -r2, d + r2, r2), b2, 360f - 2f * b2)
        path.close()
        p.color = body
        c.drawPath(path, p)
        c.restore()
    }

    private fun lum(col: Int): Float =
        0.299f * ((col shr 16) and 255) + 0.587f * ((col shr 8) and 255) + 0.114f * (col and 255)

    // ডিজাইন ৬-এর আকাশ-আর্ক: অর্ধ-উপবৃত্ত (চওড়া, গোল নয়)। অ্যানিমেশন ফ্রেমও একই ফাংশনে আঁকা।
    const val SKY_X0 = 30f; const val SKY_Y0 = 72f; const val SKY_W = 940f; const val SKY_H = 266f
    private const val SHC = 430f; private const val STOP = 118f; private const val SCY = 334f
    // চওড়া অগভীর বৃত্ত-চাপ: ভূমি-রেখায় cx±SHC, চূড়া y = STOP (পুরো উইজেট জুড়ে, নিচের দিকে ঢালু প্রান্ত)
    private val SH = SCY - STOP
    private val SR = (SHC * SHC + SH * SH) / (2f * SH)
    private val STH = Math.asin((SHC / SR).toDouble())
    private const val SUN_K = 0.8f; private const val MOON_R = 19f

    /** আকাশের পথ: পুরো উইজেট জুড়ে চওড়া অগভীর চাপ — দুই প্রান্ত ভূমি-রেখায়, চূড়া মাঝখানে; রেখার নিচে যায় না */
    private fun skyX(cx: Float, u: Double): Float =
        cx + SR * Math.sin(STH * (2.0 * u.coerceIn(0.0, 1.0) - 1.0)).toFloat()
    private fun skyY(cy: Float, u: Double): Float =
        (STOP + SR) - SR * Math.cos(STH * (2.0 * u.coerceIn(0.0, 1.0) - 1.0)).toFloat()

    /** fOv ≥ 0 হলে আর্কের ওপর ওই অনুপাতে (০..১) আইকন বসে (অ্যানিমেশন); নইলে এখনকার সময় অনুযায়ী। */
    private fun drawSky(c: Canvas, p: Paint, m: PaletteMin, lightText: Boolean, snap: Snapshot, nowMs: Long, fOv: Float) {
        val cx = cardW(6) / 2f; val cy = SCY
        val isDay = snap.sunsetMs > snap.sunriseMs && nowMs >= snap.sunriseMs && nowMs < snap.sunsetMs
        val a0 = if (isDay) snap.sunriseMs else snap.nightStartMs
        val a1 = if (isDay) snap.sunsetMs else snap.nightEndMs
        val f = if (fOv >= 0f) fOv.coerceIn(0f, 1f) else if (a1 > a0) ((nowMs - a0).toFloat() / (a1 - a0)).coerceIn(0f, 1f) else 0f
        val moonBody = if (lightText) 0xFFF4EEDC.toInt() else 0xFF2F4378.toInt()
        val nightGlow = if (lightText) 0xFFC9D6FF.toInt() else 0xFF3B4F8A.toInt()
        val lineCol = if (isDay) m.accent else moonBody      // আইকনের সাথে এক রঙ — দাগ আর চাঁদ একটাই টুকরো
        val u = if (isDay) f else 1f - f                     // বাঁ থেকে ডানে অবস্থান
        val n = 480
        val xs = FloatArray(n + 1); val ys = FloatArray(n + 1)
        for (i in 0..n) {
            xs[i] = skyX(cx, i.toDouble() / n); ys[i] = skyY(cy, i.toDouble() / n)
        }
        val ix = skyX(cx, u.toDouble()); val iy = skyY(cy, u.toDouble())
        val sgn = if (isDay) 1.0 else -1.0
        val tx = ((skyX(cx, u + 0.004) - skyX(cx, u - 0.004)) * sgn).toFloat()
        val ty = ((skyY(cy, u + 0.004) - skyY(cy, u - 0.004)) * sgn).toFloat()
        val gB = if (isDay) 28.5f * SUN_K + 3f else MOON_R           // পেছনের দাগ আইকনের কিনারায় থামে
        val gA = if (isDay) 28.5f * SUN_K + 6f else MOON_R + 5f  // সামনের ফিকে দাগ ফাঁক রেখে শুরু
        fun dist(i: Int) = Math.hypot((xs[i] - ix).toDouble(), (ys[i] - iy).toDouble()).toFloat()

        // পুরো আকাশ (দাগ, ট্র্যাক, আইকন) ভূমি-রেখার ওপরেই কাটা — গোল ক্যাপ বা আইকন রেখার নিচে নামে না
        c.save(); c.clipRect(-100f, -100f, cardW(6) + 100f, cy - 1f)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        // সামনের বাকি পথ: ফিকে ড্যাশ-রেখা (আইকনের দু'পাশে ফাঁক)
        p.strokeWidth = 3.5f; p.color = m.track
        var path = Path(); var open = false
        var acc = 0f
        for (i in 0..n) {
            if (i > 0) acc += Math.hypot((xs[i] - xs[i - 1]).toDouble(), (ys[i] - ys[i - 1]).toDouble()).toFloat()
            val on = dist(i) >= gA && (acc % 17f) < 7f
            if (on) { if (!open) { path.moveTo(xs[i], ys[i]); open = true } else path.lineTo(xs[i], ys[i]) }
            else if (open) { c.drawPath(path, p); path = Path(); open = false }
        }
        if (open) c.drawPath(path, p)
        // উজ্জ্বল অংশ: শুরু থেকে আইকনের কিনারা পর্যন্ত
        val ii = Math.round(u * n).coerceIn(0, n)
        path = Path(); var any = false
        if (isDay) {
            var e = ii; while (e > 0 && dist(e) < gB) e--
            if (e >= 1) { path.moveTo(xs[0], ys[0]); for (i in 1..e) path.lineTo(xs[i], ys[i]); any = true }
        } else {
            var s0 = ii; while (s0 < n && dist(s0) < gB) s0++
            if (s0 <= n - 1) { path.moveTo(xs[s0], ys[s0]); for (i in s0 + 1..n) path.lineTo(xs[i], ys[i]); any = true }
        }
        if (any) {
            // পেরিয়ে আসা পথের নিচে হালকা রঙের আভা (ভূমি-রেখা পর্যন্ত)
            val fillP = Path(); var fx0 = 0f; var fx1 = 0f
            // আভার কিনারা ঠিক সূর্য/চাঁদের কেন্দ্র বরাবর (আইকনের পেছনে) — আইকনের সাথে সাথে বাড়ে
            if (isDay) {
                fillP.moveTo(xs[0], cy)
                for (i in 0..n) { if (xs[i] >= ix) break; fillP.lineTo(xs[i], ys[i]) }
                fillP.lineTo(ix, iy); fillP.lineTo(ix, cy)
            } else {
                fillP.moveTo(ix, cy); fillP.lineTo(ix, iy)
                for (i in 0..n) { if (xs[i] > ix) fillP.lineTo(xs[i], ys[i]) }
                fillP.lineTo(xs[n], cy)
            }
            fillP.close()
            p.style = Paint.Style.FILL; p.color = (lineCol and 0xFFFFFF) or 0x16000000
            c.drawPath(fillP, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 5f; p.color = lineCol; c.drawPath(path, p)
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL

        // সূর্য/চাঁদ ভূমি-রেখার নিচে দেখা যায় না — ওঠা/ডোবার সময় রেখার আড়াল থেকে ওঠে
        if (isDay) {
            c.save(); c.translate(ix, iy); c.scale(SUN_K, SUN_K)
            sun(c, p, 0f, 0f, m.accent, false)
            c.restore()
        } else {
            // কামড় চলার দিকে মুখ করে, তবে ৩০° ওপরের দিকে হেলানো — পেছনের গোল কিনারা দাগের সাথে মেলে, চাঁদ দেখতে স্বাভাবিক থাকে
            val th = Math.toDegrees(Math.atan2(ty.toDouble(), tx.toDouble()))
            var dd = (-90.0 - th) % 360.0; if (dd > 180.0) dd -= 360.0; if (dd < -180.0) dd += 360.0
            moon(c, p, ix, iy, MOON_R, nightGlow, moonBody, false, (th + (if (dd >= 0) 30.0 else -30.0)).toFloat())
        }
        c.restore()
    }

    /** অ্যানিমেশনের একটা ফ্রেম: শুধু আকাশ-অংশ (কার্ডের SKY_* এলাকা), q = বিটম্যাপের স্কেল। */
    fun drawSkyFrame(ctx: Context, c: Canvas, look: Look, snap: Snapshot, nowMs: Long, fAnim: Float, scale: Float) {
        Fonts.init(ctx)
        val m = Palettes.ofMin(look.variant)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.save(); c.scale(scale, scale); c.translate(-SKY_X0, -SKY_Y0)
        drawSky(c, p, m, lum(m.primary) > 150f, snap, nowMs, fAnim)
        c.restore()
    }

    /** আজকের আর্কে আইকনের চূড়ান্ত অনুপাত (০..১) — অ্যানিমেশন এখানে থামে। */
    fun skyFraction(snap: Snapshot, nowMs: Long): Float {
        val isDay = snap.sunsetMs > snap.sunriseMs && nowMs >= snap.sunriseMs && nowMs < snap.sunsetMs
        val a0 = if (isDay) snap.sunriseMs else snap.nightStartMs
        val a1 = if (isDay) snap.sunsetMs else snap.nightEndMs
        return if (a1 > a0) ((nowMs - a0).toFloat() / (a1 - a0)).coerceIn(0f, 1f) else 0f
    }

    /** ডিজাইন ৬/৭/৮-এর এক লোগো: গোল বৃত্ত + ভেতরে লোগোর পাথ (লাইট/ডার্ক অনুযায়ী রঙ) */
    private fun logoRing(ctx: Context, c: Canvas, p: Paint, m: PaletteMin, cx: Float, cy: Float, lr: Float) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = (m.primary and 0xFFFFFF) or 0x14000000
        c.drawCircle(cx, cy, lr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = lr * 0.111f; p.color = m.primary
        c.drawCircle(cx, cy, lr, p)
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
        val lg = Art.logoPath(ctx, lum(m.primary) > 150f)
        val lh = lr * 1.333f; val lw = lh * lg.width / lg.height
        c.drawBitmap(lg, null, RectF(cx - lw / 2f, cy - lh / 2f, cx + lw / 2f, cy + lh / 2f), p)
    }

    /**
     * ডিজাইন ৬: চলমান ওয়াক্ত। স্বাভাবিক সময়ে "ইশা [চলমান]" + বাকি সময়; নিষিদ্ধ সময়ে "নিষিদ্ধ সময়" (লাল-কমলা) + বাকি সময়;
     * সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত নাম ও টাইমার দুটোতেই "–"।
     */
    private fun drawD6Current(c: Canvas, p: Paint, m: PaletteMin, lightText: Boolean, snap: Snapshot, nowMs: Long, live: Boolean, ov: Overlay, cx: Float) {
        val warn = if (lightText) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        when (snap.forbid) {
            2 -> {   // কোনো ওয়াক্ত নেই: নাম ও টাইমারে "–"
                text(c, p, "–", cx, 394f, 60f, m.secondary, Fonts.bold, Paint.Align.CENTER)
                text(c, p, "–", cx, 434f, 40f, m.secondary, Fonts.bold, Paint.Align.CENTER)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", cx, 394f, 52f, warn, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 520f, 434f, 34f, 32f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                val nsz = 52f
                val nw = measure(p, snap.currentName, Fonts.bold, nsz)
                val badge = "চলমান"
                val bsz = 27f
                val bw = measure(p, badge, Fonts.bold, bsz) + 34f
                val gap = 16f
                val x0 = cx - (nw + gap + bw) / 2f
                text(c, p, snap.currentName, x0, 394f, nsz, m.accent, Fonts.bold)
                val bx = x0 + nw + gap
                tile(c, p, bx, 355f, bx + bw, 397f, 21f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x80000000.toInt())
                text(c, p, badge, bx + bw / 2f, 385f, bsz, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 520f, 434f, 34f, 32f, m.primary, m.primary)
            }
        }
    }

    private fun drawD6(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, hideSky: Boolean) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(6)
        val L = 40f; val R = cw - 40f
        val cx = cw / 2f; val cy = SCY
        val rule = (m.primary and 0xFFFFFF) or 0x40000000
        val lightText = lum(m.primary) > 150f

        // ওপরের মাঝখানে লোগো: গোল বৃত্তের ভেতরে লোগোর পাথ
        logoRing(ctx, c, p, m, cx, 50f, 36f)

        // ওপরের কোণে তিন তারিখ: বাঁয়ে ইংরেজি + বাংলা, ডানে হিজরি (দুই লাইনে)
        text(c, p, snap.gregorianLine, L, 62f, 35f, m.secondary, Fonts.bold)
        text(c, p, snap.banglaLine, L, 106f, 35f, m.secondary, Fonts.bold)
        text(c, p, snap.hijriDay + " " + snap.hijriMonth, R, 62f, 35f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
        text(c, p, snap.hijriYear + " হিজরি", R, 106f, 35f, m.secondary, Fonts.bold, Paint.Align.RIGHT)

        // আর্ক (অর্ধ-উপবৃত্ত): দিনে সূর্যোদয় → সূর্যাস্ত (সূর্য, বাঁ থেকে ডানে); রাতে সূর্যাস্ত → পরদিন সূর্যোদয় (চাঁদ, ডান থেকে বাঁয়ে)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(L, cy - 1f, R, cy + 1f, p)
        if (!hideSky) drawSky(c, p, m, lightText, snap, nowMs, -1f)

        // আর্কের ভেতরে ঘড়ি + AM/PM
        // ঘড়ি (ডানে-সারিবদ্ধ, আগের AM/PM-এর জায়গায় একটু নামানো) + ডানে AM/PM ও তার নিচে লাইভ সেকেন্ড
        val clockSize = 124f
        val clockEnd = cx + 139f            // "00:00"-এর মাপে গোটা গুচ্ছ মাঝখানে বসে; ডান কিনারা স্থির, তাই AM/PM-সেকেন্ড মিনিটের গা ঘেঁষে থাকে
        val hmNow = hmOf(nowMs)
        val clockW = measure(p, hmNow.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hmNow.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hmNow, clockEnd - clockW, 308f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", cx + 191f, 262f, 32f, m.accent, Fonts.outfit, Paint.Align.CENTER)
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), cx + 191f, 308f, 32f, m.primary, Fonts.outfit, Paint.Align.CENTER)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)

        // ভূমি-রেখার নিচে: সূর্যোদয় | চলমান ওয়াক্ত + বাকি সময় (লাইভ) | সূর্যাস্ত
        text(c, p, "সূর্যোদয়", L, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.LEFT)
        text(c, p, snap.sunrise, L, 432f, 50f, m.primary, Fonts.bold, Paint.Align.LEFT)
        text(c, p, "সূর্যাস্ত", R, 382f, 31f, m.secondary, Fonts.regular, Paint.Align.RIGHT)
        text(c, p, snap.iftar, R, 432f, 50f, m.primary, Fonts.bold, Paint.Align.RIGHT)
        drawD6Current(c, p, m, lightText, snap, nowMs, live, ov, cx)
    }

    // ------------------------------------------------------------------------------------------
    // ডিজাইন ৭ ও ৮ — ডিজাইন ১-এর আইকন-মেডালিয়ন (সূর্যোদয়, সেহরি, ইফতার) ও লোগো, ডিজাইন ১-এর আর্ট থেকে নেওয়া।
    // ------------------------------------------------------------------------------------------
    private val MEDAL_SRC = arrayOf(
        Rect(832, 52, 925, 145),     // সূর্যোদয়
        Rect(533, 239, 627, 333),    // সেহরি
        Rect(819, 239, 913, 333)     // ইফতার
    )
    private val LOGO_SRC = Rect(56, 42, 197, 185)

    private fun medal(c: Canvas, p: Paint, art: Bitmap, i: Int, cx: Float, cy: Float, dia: Float) {
        val r = dia / 2f
        c.save()
        val path = Path(); path.addCircle(cx, cy, r * 0.985f, Path.Direction.CW)
        c.clipPath(path)
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFFFFFFFF.toInt()
        c.drawBitmap(art, MEDAL_SRC[i], RectF(cx - r, cy - r, cx + r, cy + r), p)
        c.restore()
    }

    private fun hmOf(nowMs: Long): String {
        val cal = Calendar.getInstance(); cal.timeInMillis = nowMs
        var hh = cal.get(Calendar.HOUR); if (hh == 0) hh = 12
        return (if (hh < 10) "0$hh" else "$hh") + ":" + pad2a(cal.get(Calendar.MINUTE))
    }

    private fun tile(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rx: Float, color: Int, edge: Int = 0) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawRoundRect(l, t, r, b, rx, rx, p)
        if (edge != 0) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = edge
            c.drawRoundRect(l + 0.75f, t + 0.75f, r - 0.75f, b - 0.75f, rx, rx, p)
            p.style = Paint.Style.FILL
        }
    }

    /** প্রগ্রেস বার + শেষ প্রান্তে গোল নব */
    private fun barK(c: Canvas, p: Paint, x0: Float, x1: Float, y: Float, h: Float, frac: Float, track: Int, fill: Int) {
        bar(c, p, x0, x1, y, h, frac, track, fill)
        val kx = (x0 + (x1 - x0) * frac.coerceIn(0f, 1f)).coerceIn(x0 + h, x1 - h)
        p.style = Paint.Style.FILL
        p.color = (fill and 0xFFFFFF) or 0x44000000; c.drawCircle(kx, y + h / 2f, h * 2.1f, p)
        p.color = fill; c.drawCircle(kx, y + h / 2f, h * 1.15f, p)
    }

    /** ডিজাইন ৭ (এডিটোরিয়াল): বক্স ছাড়া — চিকন রেখা দিয়ে ভাগ করা হেডার · বড় ঘড়ি · তিন আইকন-সারি · পাঁচ ওয়াক্ত (শুধু চলমানটা হাইলাইট) */
    private fun drawD7(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(7)
        val L = 40f; val R = cw - 40f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val hair = (m.primary and 0xFFFFFF) or 0x38000000
        fun hline(x0: Float, x1: Float, y: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x0, y - 0.75f, x1, y + 0.75f, p) }
        fun vline(x: Float, y0: Float, y1: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x - 0.75f, y0, x + 0.75f, y1, p) }

        // হেডার: লোগো · হিজরি · ইংরেজি | বাংলা · ডানে কোণায় বার
        logoRing(ctx, c, p, m, L + 35f, 62f, 35f)
        val hx = L + 70f + 22f
        val hijri = if (snap.gregFirst) snap.gregorianLine else snap.hijriLine
        val wd = weekday(nowMs)
        val wdW = measure(p, wd, Fonts.bold, 42f)
        text(c, p, wd, R, 82f, 42f, m.accent, Fonts.bold, Paint.Align.RIGHT)
        vline(R - wdW - 22f, 36f, 96f)
        val avail = R - wdW - 44f - hx
        val hSz = fit(p, hijri, Fonts.bold, 44f, avail)
        text(c, p, hijri, hx, 62f, hSz, m.primary, Fonts.bold)
        val g1 = if (snap.gregFirst) snap.hijriLine else snap.gregorianLine; val g2 = snap.banglaLine
        var ds = 33f
        val tw = measure(p, g1, Fonts.regular, ds) + 34f + measure(p, g2, Fonts.regular, ds)
        if (tw > avail) ds *= avail / tw
        val w1 = measure(p, g1, Fonts.regular, ds)
        text(c, p, g1, hx, 100f, ds, m.secondary, Fonts.regular)
        vline(hx + w1 + 17f, 76f, 104f)
        text(c, p, g2, hx + w1 + 34f, 100f, ds, m.secondary, Fonts.regular)
        hline(L, R, 124f)

        // বড় ঘড়ি: ঘড়ি · লাইভ সেকেন্ড + (একই লাইনে) AM/PM · প্রগ্রেস · ওয়াক্ত + বাকি সময় (লাইভ)
        val ty0 = 136f; val tr = 516f
        val clockSize = 372f / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        slimClock(c, p, hmOf(nowMs), L, 282f, clockSize, m.primary)
        // মিনিটের পাশে ছোট লাইভ সেকেন্ড (আসল ঘড়ি লঞ্চারের TextClock) + তার ডানে একই বেসলাইনে AM/PM
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), L + 364f, 282f, 50f, m.accent, Fonts.outfit)
        else ov.ss = TextSpec(0f, 0f, 0f, m.accent)
        text(c, p, if (snap.isPm) "PM" else "AM", L + 436f, 282f, 32f, m.secondary, Fonts.outfit)

        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f7 = snap.forbid     // ০ স্বাভাবিক · ১ নিষিদ্ধ সময় · ২ সকালের নিষিদ্ধ সময়ের পর থেকে দুপুরের নিষিদ্ধ সময়ের আগ পর্যন্ত ("–")
        val f7Frac = when (f7) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        barK(c, p, L + 6f, tr - 8f, 328f, 8f, f7Frac, m.track, if (f7 == 1) warn else m.accent)
        when (f7) {
            2 -> {
                text(c, p, "–", L + 4f, 390f, 46f, m.secondary, Fonts.bold)
                text(c, p, "–", tr - 8f, 390f, 40f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", L + 4f, 390f, 40f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 435f, 390f, 38f, 35f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, L + 4f, 390f, 42f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 435f, 390f, 38f, 35f, m.primary, m.primary)
            }
        }

        // তিন আইকন-সারি (চিকন রেখায় আলাদা)
        val labels = arrayOf("সূর্যোদয়", "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunrise, snap.sehri, snap.iftar)
        val tx0 = 562f; val rh = 90f
        vline(tx0 - 26f, ty0 + 6f, ty0 + rh * 3 - 6f)
        for (i in 0 until 3) {
            val y0 = ty0 + rh * i
            if (i > 0) hline(tx0, R, y0)
            medal(c, p, art, i, tx0 + 31f, y0 + rh / 2f, 62f)
            text(c, p, labels[i], tx0 + 84f, y0 + rh / 2f + 12f, 33f, m.secondary, Fonts.regular)
            text(c, p, times[i], R, y0 + rh / 2f + 16f, 46f, m.primary, Fonts.bold, Paint.Align.RIGHT)
        }
        hline(L, R, 424f)

        // পাঁচ ওয়াক্ত: শুধু চলমানটা হালকা রঙের পিলে
        val sy0 = 434f; val sy1 = 540f
        val colW = (R - L) / 5f
        for (i in 0 until 5) {
            val cc = L + colW * (i + 0.5f)
            val on = f7 == 0 && snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 6f, sy0, cc + colW / 2f - 6f, sy1, 30f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
            text(c, p, Bn.PRAYER_NAMES[i], cc, 476f, 32f, if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, snap.prayerTimes[i], cc, 522f, 42f, if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    /** ডিজাইন ৯ (ডায়াল): বাঁয়ে গোল ডায়াল — ভেতরে লোগো, ঘড়ি, AM/PM+সেকেন্ড, চলমান ওয়াক্ত ও বাকি সময়; ডায়ালের কিনারায় ওয়াক্তের প্রগ্রেস-রিং। ডানে তারিখ, সূর্যোদয়-সেহরি-ইফতার ও পাঁচ ওয়াক্ত। */
    private fun drawD9(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val R = cardW(9) - 44f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f9 = snap.forbid
        val hair = (m.primary and 0xFFFFFF) or 0x38000000
        fun hline(x0: Float, x1: Float, y: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x0, y - 0.75f, x1, y + 0.75f, p) }
        fun vline(x: Float, y0: Float, y1: Float) { p.style = Paint.Style.FILL; p.color = hair; c.drawRect(x - 0.75f, y0, x + 0.75f, y1, p) }

        // ---------- বাঁয়ে ডায়াল ----------
        val dcx = 250f; val dcy = 270f; val dR = 210f; val ringR = 195f
        p.style = Paint.Style.FILL; p.shader = null; p.color = (m.primary and 0xFFFFFF) or 0x0F000000
        c.drawCircle(dcx, dcy, dR, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = hair
        c.drawCircle(dcx, dcy, dR, p)
        // প্রগ্রেস-রিং: ট্র্যাক + চলমান ওয়াক্তের অংশ (নিষিদ্ধ সময়ে লাল-কমলা; "–" সময়ে খালি)
        p.strokeWidth = 12f; p.color = m.track
        c.drawCircle(dcx, dcy, ringR, p)
        val rf = when (f9) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        val ringCol = if (f9 == 1) warn else m.accent
        if (rf > 0.002f) {
            val steps = (rf * 240f).toInt().coerceAtLeast(2)
            val path = Path()
            for (i in 0..steps) {
                val a = Math.toRadians(-90.0 + 360.0 * rf * i / steps)
                val x = dcx + ringR * Math.cos(a).toFloat(); val y = dcy + ringR * Math.sin(a).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 12f; p.color = ringCol
            c.drawPath(path, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        if (f9 != 2) {
            val a = Math.toRadians(-90.0 + 360.0 * rf)
            val kx = dcx + ringR * Math.cos(a).toFloat(); val ky = dcy + ringR * Math.sin(a).toFloat()
            p.style = Paint.Style.FILL; p.color = ringCol; c.drawCircle(kx, ky, 15f, p)
            p.color = m.primary; c.drawCircle(kx, ky, 6.5f, p)
        }
        p.style = Paint.Style.FILL

        logoRing(ctx, c, p, m, dcx, 138f, 28f)
        val hm = hmOf(nowMs)
        val clockSize = 296f / measure(p, "00:00", Fonts.outfit, 100f) * 100f
        val cwid = measure(p, hm.substring(0, 2), Fonts.outfit, clockSize) + measure(p, ":", Fonts.outfit, clockSize) + measure(p, hm.substring(3), Fonts.outfit, clockSize)
        slimClock(c, p, hm, dcx - cwid / 2f, 270f, clockSize, m.primary)
        text(c, p, if (snap.isPm) "PM" else "AM", dcx - 8f, 324f, 34f, m.accent, Fonts.outfit, Paint.Align.RIGHT)
        if (live) text(c, p, pad2a(Calendar.getInstance().also { it.timeInMillis = nowMs }.get(Calendar.SECOND)), dcx + 10f, 324f, 34f, m.primary, Fonts.outfit)
        else ov.ss = TextSpec(0f, 0f, 0f, m.primary)
        when (f9) {
            2 -> {
                text(c, p, "–", dcx, 392f, 46f, m.secondary, Fonts.bold, Paint.Align.CENTER)
                text(c, p, "–", dcx, 436f, 38f, m.secondary, Fonts.bold, Paint.Align.CENTER)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", dcx, 390f, 40f, warn, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 270f, 432f, 32f, 30f, m.primary, m.secondary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, dcx, 390f, 42f, m.accent, Fonts.bold, Paint.Align.CENTER)
                remLine(c, p, ov, live, snap, nowMs, 270f, 432f, 32f, 30f, m.primary, m.secondary)
            }
        }

        // ---------- ডানে ----------
        val X0 = 520f
        p.style = Paint.Style.FILL; p.color = (m.accent and 0xFFFFFF) or 0xCC000000.toInt()
        c.drawRect(X0 - 18f, 56f, X0 - 14.5f, 218f, p)
        text(c, p, weekday(nowMs), X0, 84f, 30f, m.accent, Fonts.bold)
        val lines = if (snap.gregFirst) arrayOf(snap.gregorianLine, snap.hijriLine, snap.banglaLine) else arrayOf(snap.hijriLine, snap.gregorianLine, snap.banglaLine)
        val s0 = fit(p, lines[0], Fonts.bold, 46f, R - X0)
        text(c, p, lines[0], X0, 134f, s0, m.primary, Fonts.bold)
        text(c, p, lines[1], X0, 176f, fit(p, lines[1], Fonts.bold, 34f, R - X0), m.secondary, Fonts.bold)
        text(c, p, lines[2], X0, 214f, fit(p, lines[2], Fonts.bold, 34f, R - X0), m.secondary, Fonts.bold)
        hline(X0 - 18f, R, 240f)

        val labels = arrayOf("সূর্যোদয়", "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunrise, snap.sehri, snap.iftar)
        val c3 = (R - (X0 - 18f)) / 3f
        for (i in 0 until 3) {
            val cx = X0 - 18f + c3 * (i + 0.5f)
            medal(c, p, art, i, cx, 296f, 60f)
            text(c, p, labels[i], cx, 358f, 27f, m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, times[i], cx, 402f, 38f, m.primary, Fonts.bold, Paint.Align.CENTER)
            if (i > 0) vline(X0 - 18f + c3 * i, 268f, 408f)
        }
        hline(X0 - 18f, R, 428f)

        val px0 = X0 - 32f
        val colW = (R - px0) / 5f
        for (i in 0 until 5) {
            val cc = px0 + colW * (i + 0.5f)
            val on = f9 == 0 && snap.current == i
            if (on) tile(c, p, cc - colW / 2f + 3f, 440f, cc + colW / 2f - 3f, 520f, 22f, (m.accent and 0xFFFFFF) or 0x2E000000, (m.accent and 0xFFFFFF) or 0x66000000)
            val nm = Bn.PRAYER_NAMES[i]; val tm = snap.prayerTimes[i]
            text(c, p, nm, cc, 474f, fit(p, nm, Fonts.regular, 27f, colW - 8f), if (on) m.accent else m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, tm, cc, 508f, fit(p, tm, Fonts.bold, 32f, colW - 8f), if (on) m.accent else m.primary, Fonts.bold, Paint.Align.CENTER)
        }
    }

    /** ডিজাইন ৮ (স্ট্যাক): বাঁয়ে লম্বা টাইলে ওপর-নিচ সাজানো ঘড়ি · ডানে লোগো + তিন তারিখ, তিন আইকন, চলমান ওয়াক্ত, পাঁচ ওয়াক্ত */
    private fun drawD8(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(8)
        val R = cw - 36f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000
        val edge = (m.primary and 0xFFFFFF) or 0x1F000000

        // বাঁয়ে স্ট্যাক ঘড়ি (ঘণ্টা ওপরে, মিনিট ঠিক নিচে — মাঝে দাগ নেই; কমপ্যাক্ট)
        tile(c, p, 36f, 36f, 356f, 464f, 46f, m.track, edge)
        // আইফোন-ধাঁচের ভেতরের হালকা আলোর রেখা
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = (if (lum(m.primary) > 150f) 0x1CFFFFFF else 0x30FFFFFF)
        c.drawRoundRect(40f, 40f, 352f, 460f, 42f, 42f, p)
        p.style = Paint.Style.FILL
        val hm = hmOf(nowMs)
        val lcx = 196f
        val cs = 190f
        text(c, p, hm.substring(0, 2), lcx, 204f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        p.style = Paint.Style.FILL; p.color = (m.primary and 0xFFFFFF) or 0x4D000000   // ঘণ্টা-মিনিটের মাঝে চিকন হালকা রেখা
        c.drawRect(lcx - 70f, 219.25f, lcx + 70f, 220.75f, p)
        text(c, p, hm.substring(3), lcx, 370f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        text(c, p, if (snap.isPm) "PM" else "AM", lcx, 436f, 42f, m.accent, Fonts.outfit, Paint.Align.CENTER)

        // ডানে: লোগো + তিন তারিখ (তিনটাই বোল্ড, একই সাইজ; লোগো ও দাগ তিন তারিখের ঠিক মাঝে)
        val X0 = 392f
        val dx = X0 + 114f
        val dates = if (snap.gregFirst) arrayOf(snap.gregorianLine, snap.hijriLine, snap.banglaLine) else arrayOf(snap.hijriLine, snap.gregorianLine, snap.banglaLine)
        var dsz = 40f
        for (dtx in dates) dsz = minOf(dsz, fit(p, dtx, Fonts.bold, 40f, R - dx))
        val dys = floatArrayOf(68f, 108f, 148f)
        val hcy = 99f
        logoRing(ctx, c, p, m, X0 + 39f, hcy, 39f)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(X0 + 94f, hcy - 62f, X0 + 96f, hcy + 62f, p)
        for ((i, dtx) in dates.withIndex()) text(c, p, dtx, dx, dys[i], dsz, if (i == 0) m.primary else m.secondary, Fonts.bold)

        // তারিখের নিচে চিকন রেখা, তারপর তিন আইকন (সূর্যোদয় | সেহরি | ইফতার)
        p.style = Paint.Style.FILL; p.color = (m.primary and 0xFFFFFF) or 0x38000000
        c.drawRect(X0, 170f, R, 171.5f, p)
        val labels = arrayOf("সূর্যোদয়", "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunrise, snap.sehri, snap.iftar)
        val colW3 = (R - X0) / 3f
        for (i in 0 until 3) {
            val cx = X0 + colW3 * (i + 0.5f)
            medal(c, p, art, i, cx, 232f, 80f)
            text(c, p, labels[i], cx, 312f, 31f, m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, times[i], cx, 358f, 44f, m.primary, Fonts.bold, Paint.Align.CENTER)
            if (i > 0) { p.style = Paint.Style.FILL; p.color = rule; c.drawRect(X0 + colW3 * i - 1f, 196f, X0 + colW3 * i + 1f, 362f, p) }
        }

        // চলমান ওয়াক্ত / নিষিদ্ধ সময় / "–" + বাকি সময় (লাইভ) + প্রগ্রেস
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f8 = snap.forbid
        val bf = when (f8) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        when (f8) {
            2 -> {
                text(c, p, "–", X0, 436f, 46f, m.secondary, Fonts.bold)
                text(c, p, "–", R, 436f, 40f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", X0, 436f, 44f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 906f, 436f, 36f, 34f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, X0, 436f, 46f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 906f, 436f, 36f, 34f, m.primary, m.primary)
            }
        }
        barK(c, p, X0 + 6f, R - 6f, 454f, 8f, bf, m.track, if (f8 == 1) warn else m.accent)
    }
}
