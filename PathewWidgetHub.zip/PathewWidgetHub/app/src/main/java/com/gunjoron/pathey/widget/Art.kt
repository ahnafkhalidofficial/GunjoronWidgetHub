package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.gunjoron.pathey.R

/** স্ট্যাটিক আর্ট-লেয়ার (লোগো, আইকন, পিল, ঘড়ির টাইল) — আপনার শিট থেকে হুবহু এক্সপোর্ট করা। */
object Art {
    private val cache = LruCache<Int, Bitmap>(4)

    private fun resId(d: Int, v: Variant): Int = when (d) {
        1 -> when (v) {
            Variant.GLASS -> R.drawable.art_d1_glass; Variant.LIGHT -> R.drawable.art_d1_light
            Variant.NOBG_DARK -> R.drawable.art_d1_nobg_dark; Variant.NOBG_LIGHT -> R.drawable.art_d1_nobg_light
        }
        2 -> when (v) {
            Variant.GLASS -> R.drawable.art_d2_glass; Variant.LIGHT -> R.drawable.art_d2_light
            Variant.NOBG_DARK -> R.drawable.art_d2_nobg_dark; Variant.NOBG_LIGHT -> R.drawable.art_d2_nobg_light
        }
        else -> 0   // ডিজাইন ৩-এ আর্ট নেই — সবকিছু কোডে আঁকা
    }

    @Synchronized
    fun get(ctx: Context, d: Int, v: Variant): Bitmap {
        val id = resId(d, v)
        cache.get(id)?.let { return it }
        val o = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val b = BitmapFactory.decodeResource(ctx.applicationContext.resources, id, o)
        cache.put(id, b)
        return b
    }
}
