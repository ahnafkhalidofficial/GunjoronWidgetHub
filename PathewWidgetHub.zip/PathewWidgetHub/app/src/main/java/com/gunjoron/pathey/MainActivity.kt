package com.gunjoron.pathey

import android.app.Activity
import android.os.Bundle
import com.gunjoron.pathey.hub.HubScreen
import com.gunjoron.pathey.widget.WidgetUpdater

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(HubScreen(this).build())
    }

    override fun onResume() {
        super.onResume()
        // হাব খুললে উইজেট সতেজ থাকে (তারিখ/ওয়াক্ত বদলে থাকলেও)
        WidgetUpdater.updateAll(this)
    }
}
