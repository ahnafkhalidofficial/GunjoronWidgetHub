package com.gunjoron.pathey

import android.Manifest
import android.app.Activity
import android.os.Bundle
import com.gunjoron.pathey.data.DeviceLocation
import com.gunjoron.pathey.data.RemoteConfig
import com.gunjoron.pathey.hub.HubScreen
import com.gunjoron.pathey.widget.WidgetUpdater

class MainActivity : Activity() {
    private lateinit var hub: HubScreen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hub = HubScreen(this)
        setContentView(hub.build())
        // নামাজের সময়ের জন্য লোকেশন অটো নেওয়া হয় — প্রথমবার অনুমতি চাওয়া হয়
        if (!DeviceLocation.hasPermission(this)) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 11)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshData()
    }

    override fun onResume() {
        super.onResume()
        // হাব খুললে উইজেট সতেজ থাকে (তারিখ/ওয়াক্ত বদলে থাকলেও)
        WidgetUpdater.updateAll(this)
        refreshData()
    }

    /** অটো লোকেশন + ফায়ারবেজের হিজরি কনফিগ; কিছু বদলালে হাব-প্রিভিউ ও উইজেট নতুন করে আঁকা হয়। */
    private fun refreshData() {
        val app = applicationContext
        val changed = { runOnUiThread { hub.onDataChanged(); WidgetUpdater.updateAll(app) } }
        DeviceLocation.refresh(app, changed)
        Thread { if (RemoteConfig.fetch(app)) changed() }.start()
    }
}
