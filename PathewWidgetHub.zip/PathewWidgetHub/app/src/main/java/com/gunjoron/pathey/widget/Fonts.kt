package com.gunjoron.pathey.widget

import android.content.Context
import android.graphics.Typeface
import com.gunjoron.pathey.R

/** ফন্ট একবারই লোড হয় (static TTF — ভেরিয়েবল ফন্ট নয়, তাই পুরনো ফোনেও উইজেট ভাঙে না)। */
object Fonts {
    @Volatile private var ready = false
    lateinit var regular: Typeface; private set   // গুঞ্জরণ রেগুলার
    lateinit var bold: Typeface; private set      // গুঞ্জরণ বোল্ড
    lateinit var bebas: Typeface; private set     // ডিজিটাল সংখ্যা
    lateinit var serif: Typeface; private set     // ডিজাইন ৩-এর বড় ঘড়ি
    lateinit var ui: Typeface; private set        // হাব অ্যাপের UI ফন্ট (Kothamala)

    fun init(ctx: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val r = ctx.applicationContext.resources
            regular = r.getFont(R.font.gunjoron_regular)
            bold = r.getFont(R.font.gunjoron_bold)
            bebas = r.getFont(R.font.bebas_neue)
            serif = r.getFont(R.font.liberation_serif)
            ui = r.getFont(R.font.kothamala)
            ready = true
        }
    }
}
