package com.gunjoron.pathey.widget.designs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.gunjoron.pathey.data.Snapshot
import com.gunjoron.pathey.widget.WidgetRenderer.cardW
import com.gunjoron.pathey.widget.assets.Fonts
import com.gunjoron.pathey.widget.render.*
import com.gunjoron.pathey.widget.theme.Look
import com.gunjoron.pathey.widget.theme.Palettes

/** ডিজাইন ৮ (স্ট্যাক): বাঁয়ে লম্বা টাইলে ওপর-নিচ ঘড়ি, ডানে তারিখ ও আইকন। */
internal object StackDesign {
    /** ডিজাইন ৮ (স্ট্যাক): বাঁয়ে লম্বা টাইলে ওপর-নিচ সাজানো ঘড়ি · ডানে লোগো + তিন তারিখ, তিন আইকন, চলমান ওয়াক্ত, পাঁচ ওয়াক্ত */
    fun draw(ctx: Context, c: Canvas, p: Paint, look: Look, snap: Snapshot, live: Boolean, nowMs: Long, ov: Overlay, art: Bitmap) {
        val m = Palettes.ofMin(look.variant)
        val cw = cardW(8)
        val R = cw - 36f
        val span = (snap.periodEndMs - snap.periodStartMs).coerceAtLeast(1L)
        val frac = ((nowMs - snap.periodStartMs).toFloat() / span).coerceIn(0f, 1f)
        val rule = (m.primary and 0xFFFFFF) or 0x66000000
        val edge = (m.primary and 0xFFFFFF) or 0x1F000000

        // বাঁয়ে স্ট্যাক ঘড়ি (ঘণ্টা ওপরে, মিনিট ঠিক নিচে — মাঝে দাগ নেই; কমপ্যাক্ট)
        tile(c, p, 36f, 36f, 356f, 464f, 46f, m.track, edge)
        // আইফোন-ধাঁচের ভেতরের হালকা আলোর রেখা
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = (if (lum(m.primary) > 150f) 0x1CFFFFFF else 0x30FFFFFF)
        c.drawRoundRect(40f, 40f, 352f, 460f, 42f, 42f, p)
        p.style = Paint.Style.FILL
        val hm = hmOf(nowMs)
        val lcx = 196f
        val cs = 190f
        text(c, p, hm.substring(0, 2), lcx, 204f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        p.style = Paint.Style.FILL; p.color = (m.primary and 0xFFFFFF) or 0x4D000000   // ঘণ্টা-মিনিটের মাঝে চিকন হালকা রেখা
        c.drawRect(lcx - 70f, 219.25f, lcx + 70f, 220.75f, p)
        text(c, p, hm.substring(3), lcx, 370f, cs, m.primary, Fonts.outfit, Paint.Align.CENTER)
        text(c, p, if (snap.isPm) "PM" else "AM", lcx, 436f, 42f, m.accent, Fonts.outfit, Paint.Align.CENTER)

        // ডানে: লোগো + তিন তারিখ (তিনটাই বোল্ড, একই সাইজ; লোগো ও দাগ তিন তারিখের ঠিক মাঝে)
        val X0 = 392f
        val dx = X0 + 114f
        val dates = if (snap.gregFirst) arrayOf(snap.gregorianLine, snap.hijriLine, snap.banglaLine) else arrayOf(snap.hijriLine, snap.gregorianLine, snap.banglaLine)
        var dsz = 40f
        for (dtx in dates) dsz = minOf(dsz, fit(p, dtx, Fonts.bold, 40f, R - dx))
        val dys = floatArrayOf(68f, 108f, 148f)
        val hcy = 99f
        logoRing(ctx, c, p, m, X0 + 39f, hcy, 39f)
        p.style = Paint.Style.FILL; p.color = rule
        c.drawRect(X0 + 94f, hcy - 62f, X0 + 96f, hcy + 62f, p)
        for ((i, dtx) in dates.withIndex()) text(c, p, dtx, dx, dys[i], dsz, if (i == 0) m.primary else m.secondary, Fonts.bold)

        // তারিখের নিচে চিকন রেখা, তারপর তিন আইকন (সূর্যোদয় | সেহরি | ইফতার)
        p.style = Paint.Style.FILL; p.color = (m.primary and 0xFFFFFF) or 0x38000000
        c.drawRect(X0, 170f, R, 171.5f, p)
        val labels = arrayOf(snap.sunLabel, "সেহরি", "ইফতার")
        val times = arrayOf(snap.sunTime, snap.sehri, snap.iftar)
        val colW3 = (R - X0) / 3f
        for (i in 0 until 3) {
            val cx = X0 + colW3 * (i + 0.5f)
            medal(c, p, art, i, cx, 232f, 80f)
            text(c, p, labels[i], cx, 312f, 31f, m.secondary, Fonts.regular, Paint.Align.CENTER)
            text(c, p, times[i], cx, 358f, 44f, m.primary, Fonts.bold, Paint.Align.CENTER)
            if (i > 0) { p.style = Paint.Style.FILL; p.color = rule; c.drawRect(X0 + colW3 * i - 1f, 196f, X0 + colW3 * i + 1f, 362f, p) }
        }

        // চলমান ওয়াক্ত / নিষিদ্ধ সময় / "–" + বাকি সময় (লাইভ) + প্রগ্রেস
        val warn = if (lum(m.primary) > 150f) 0xFFFF8F7A.toInt() else 0xFFC62828.toInt()
        val f8 = snap.forbid
        val bf = when (f8) {
            1 -> ((nowMs - snap.forbidStartMs).toFloat() / (snap.forbidEndMs - snap.forbidStartMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
            2 -> 0f
            else -> frac
        }
        when (f8) {
            2 -> {
                text(c, p, "–", X0, 436f, 46f, m.secondary, Fonts.bold)
                text(c, p, "–", R, 436f, 40f, m.secondary, Fonts.bold, Paint.Align.RIGHT)
            }
            1 -> {
                text(c, p, "নিষিদ্ধ সময়", X0, 436f, 44f, warn, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 906f, 436f, 36f, 34f, m.primary, m.primary, snap.forbidEndMs)
            }
            else -> {
                text(c, p, snap.currentName, X0, 436f, 46f, m.accent, Fonts.bold)
                remLine(c, p, ov, live, snap, nowMs, 906f, 436f, 36f, 34f, m.primary, m.primary)
            }
        }
        barK(c, p, X0 + 6f, R - 6f, 454f, 8f, bf, m.track, if (f8 == 1) warn else m.accent)
    }
}
