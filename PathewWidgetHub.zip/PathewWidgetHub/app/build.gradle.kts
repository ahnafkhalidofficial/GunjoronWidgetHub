plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gunjoron.pathey"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gunjoron.pathey.widgethub"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // R8 + রিসোর্স শ্রিঙ্ক: ছোট APK, দ্রুত ইনস্টল ও কোল্ড-স্টার্ট
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        // WebP/TTF আগে থেকেই কম্প্রেসড
        noCompress += listOf("ttf", "webp")
    }
    lint {
        abortOnError = false
    }
}

// ইচ্ছাকৃতভাবে কোনো থার্ড-পার্টি ডিপেন্ডেন্সি নেই (AndroidX/Compose/WebView কিছুই না) —
// এতে APK খুব ছোট, ক্লাস-লোডিং ন্যূনতম এবং অ্যাপ স্টার্টআপ সুপার ফাস্ট।
dependencies {
}
