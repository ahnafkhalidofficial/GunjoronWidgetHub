import os
PAD=23.0
CARD={1:(1114.25,608.16),2:(1114.25,445.15),3:(981.41,465.35),4:(1000.0,440.0),5:(1000.0,520.0),6:(1000.0,500.0)}
# (kind, id, x0,y0,x1,y1, gravity, font, style)  — design units, card top-left origin
OV={
 1:[('tc','tc_ss',350,284,408,345,'center','sans-serif-condensed','bold',30),
    ('ch','ch_main',710,533,850,590,'start|center_vertical','sans-serif-condensed','bold',28)],
 2:[('ch','ch_main',710,373,850,430,'start|center_vertical','sans-serif-condensed','bold',28)],
 3:[('tc','tc_ss',768,95,908,218,'center','serif','normal',54),
    ('ch','ch_main',548,406,656,446,'start|center_vertical','sans-serif-condensed','bold',22)],
}
OV[4]=[]; OV[6]=[]
OV[5]=[('tc','tc_ss',530,124,640,206,'center','sans-serif-light','normal',30)]
FMT={'tc_ss':{1:'ss',3:'ss',5:'ss'}}
def w(v): return ('%.4f'%v).rstrip('0').rstrip('.')
def frame(wt): return f'<FrameLayout android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="{w(wt)}"/>'
def vframe(wt): return f'<FrameLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="{w(wt)}"/>'
def overlay(d,o):
    kind,i,x0,y0,x1,y1,grav,font,style,maxsp=o
    W=CARD[d][0]+2*PAD; H=CARD[d][1]+2*PAD
    l=(PAD+x0)/W; r=(PAD+x1)/W; t=(PAD+y0)/H; b=(PAD+y1)/H
    attrs=f'''android:id="@+id/{i}"
                    android:layout_width="0dp"
                    android:layout_height="match_parent"
                    android:layout_weight="{w(r-l)}"
                    android:gravity="{grav}"
                    android:fontFamily="{font}"
                    android:textStyle="{style}"
                    android:includeFontPadding="false"
                    android:maxLines="1"
                    android:textColor="#FFFFFF"
                    android:autoSizeTextType="uniform"
                    android:autoSizeMinTextSize="4sp"
                    android:autoSizeMaxTextSize="{maxsp}sp"
                    android:autoSizeStepGranularity="1sp"'''
    if kind=='tc':
        f=FMT[i][d]
        view=f'<TextClock {attrs}\n                    android:format12Hour="{f}"\n                    android:format24Hour="{f}"/>'
    else:
        view=f'<Chronometer {attrs}/>'
    return f'''
        <LinearLayout android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical">
            {vframe(t)}
            <LinearLayout android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="{w(b-t)}" android:orientation="horizontal">
                {frame(l)}
                {view.replace(chr(10)+'                    ',chr(10)+'                        ')}
                {frame(1-r)}
            </LinearLayout>
            {vframe(1-b)}
        </LinearLayout>'''
for d in (1,2,3,4,5,6):
    for mode in ('w','h'):
        if mode=='w':
            box='android:layout_width="match_parent" android:layout_height="wrap_content"'
            img='android:layout_width="match_parent" android:layout_height="wrap_content"'
        else:
            box='android:layout_width="wrap_content" android:layout_height="match_parent"'
            img='android:layout_width="wrap_content" android:layout_height="match_parent"'
        ovs=''.join(overlay(d,o) for o in OV[d])
        xml=f'''<?xml version="1.0" encoding="utf-8"?>
<!--
  GENERATED (genlayout.py) — ডিজাইন {d}, {'প্রস্থ-সীমিত' if mode=='w' else 'উচ্চতা-সীমিত'} লেআউট।
  • bg: পুরো ডিজাইন একটা বিটম্যাপ (কার্ড + আইকন + তারিখ + ঘণ্টা:মিনিট + নামাজের সময়)।
  • বিটম্যাপের অনুপাত স্থির; ImageView adjustViewBounds দিয়ে বক্সটা ওই অনুপাতেই থাকে, তাই
    লাইভ ওভারলেগুলো (সেকেন্ড, কাউন্টার) বক্সের "শতাংশ" (layout_weight) হিসেবে বসানো —
    উইজেটের আসল মাপ যা-ই হোক, জায়গা ঠিক থাকে।
-->
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/root"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <FrameLayout
        android:id="@+id/box"
        {box}
        android:layout_gravity="center">

        <ImageView
            android:id="@+id/bg"
            {img}
            android:adjustViewBounds="true"
            android:scaleType="fitXY" />
{ovs}
    </FrameLayout>
</FrameLayout>
'''
        open(f'/home/claude/PathewWidgetHub/app/src/main/res/layout/widget_d{d}_{mode}.xml','w',encoding='utf-8').write(xml)
print('ok')
