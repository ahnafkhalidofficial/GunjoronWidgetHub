# পাথেয় উইজেট হাব

হোম স্ক্রিনের নামাজের সময়সূচি উইজেট (৯টা ডিজাইন) আর সেটা সাজানোর হাব অ্যাপ। Android (Kotlin), কোনো বাইরের লাইব্রেরি নেই।

## চালানোর নিয়ম
1. Android Studio (Koala/2024.1 বা নতুন) দিয়ে এই ফোল্ডার Open করুন; Gradle Sync শেষ হতে দিন (JDK 17)।
2. ফোনে/এমুলেটরে Run করুন (minSdk 26)।
3. অ্যাপ খুলে লোকেশনের অনুমতি দিন, ডিজাইন ও থিম বেছে নিন, ডিজাইন কার্ডের কোণার গোল বাটনে চেপে হোম স্ক্রিনের জন্য সেট করুন, তারপর "হোম স্ক্রিনে উইজেট যুক্ত করুন" চাপুন (অথবা হোম স্ক্রিনে লং-প্রেস → উইজেট → পাথেয়)।

## ফোল্ডার-মানচিত্র
```
PathewWidgetHub/
├── README.md                  ← এই ফাইল (শুরুর গাইড)
├── docs/                      ← বিস্তারিত নথি
│   ├── ARCHITECTURE.md        কোড কীভাবে সাজানো, কে কী করে
│   ├── DESIGNS.md             ৯টা ডিজাইনের বর্ণনা ও নিয়ম
│   ├── SETTINGS_AND_DATA.md   লোকেশন, ফায়ারবেজ হিজরি তারিখ, ট্রগল, ডিজাইন বাছা
│   └── LAYOUTS.md             জেনারেট করা লেআউট ও ভার্শন (wv…) নিয়ম
├── tools/
│   └── genlayout.py           লাইভ-অংশের (সেকেন্ড/কাউন্টডাউন) লেআউট XML বানানোর স্ক্রিপ্ট
└── app/
    ├── build.gradle.kts, proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/gunjoron/pathey/
        │   ├── MainActivity.kt         অ্যাপের প্রবেশদ্বার (অনুমতি, ডেটা রিফ্রেশ)
        │   ├── data/                   ডেটা ও হিসাব (UI-মুক্ত)
        │   │   ├── Prefs.kt            সব সেটিং (SharedPreferences)
        │   │   ├── Snapshot.kt         "এই মুহূর্তের" সব তথ্য এক জায়গায় (সময়, তারিখ, ওয়াক্ত, নিষিদ্ধ সময়)
        │   │   ├── prayer/             নামাজের সময় হিসাব (PrayerCalc), শহর-তালিকা (Cities)
        │   │   ├── calendar/           বাংলা সংখ্যা/মাসের নাম (Bn), হিজরি-বাংলা তারিখ (Calendars)
        │   │   └── remote/             ফায়ারবেজ কনফিগ (RemoteConfig), অটো লোকেশন (DeviceLocation)
        │   ├── hub/                    হাব অ্যাপের স্ক্রিন
        │   │   ├── HubScreen.kt        মূল স্ক্রিন (প্রিভিউ, থিম, ডিজাইন কার্ড, তারিখ সেটিং)
        │   │   └── ui/                 ছোট UI অংশ: Ui (সরঞ্জাম), PreviewView, ColorWheelView, GradientSlider
        │   └── widget/                 হোম-স্ক্রিন উইজেট
        │       ├── PrayerWidgetProvider.kt   সিস্টেম থেকে আসা ইভেন্ট (আপডেট, আনলক, তারিখ বদল)
        │       ├── WidgetUpdater.kt          উইজেট আঁকিয়ে RemoteViews বানিয়ে পাঠায়, পরের আপডেট ঠিক করে
        │       ├── WidgetRenderer.kt         কার্ড + ডিজাইন বেছে আঁকার প্রবেশদ্বার
        │       ├── designs/                  প্রতি ডিজাইনের জন্য আলাদা ফাইল (ClassicDesign … DialDesign)
        │       ├── render/                   DrawKit (শেয়ার করা আঁকার সরঞ্জাম), Overlay (লাইভ অংশ)
        │       ├── theme/                    Look (ডিজাইন+থিম), Palettes (রঙ)
        │       └── assets/                   Art (ছবির আর্ট লোড), Fonts (ফন্ট লোড)
        └── res/
            ├── font/            সব ফন্ট (.ttf)
            ├── drawable/        হাবের ভেক্টর আইকন (ic_*.xml)
            ├── drawable-nodpi/  ডিজাইনের আর্ট ছবি (art_d1/d2_*, লোগো, প্রিভিউ)
            ├── layout/          wv…_d*_*.xml (জেনারেট করা — হাতে বদলাবেন না) + anim_frame.xml
            ├── xml/             widget_info.xml (উইজেটের মেটা তথ্য)
            └── values/, values-v31/, mipmap-anydpi-v26/   স্ট্রিং, রঙ, থিম, অ্যাপ-আইকন
```
> Android নিয়মে `res/` এর ভেতরের সাব-ফোল্ডার নাম নির্দিষ্ট, তাই ফন্ট/আর্ট/লেআউট ওই ভাগেই আছে। এই প্রজেক্টে HTML নেই — পুরো UI Kotlin (Canvas) দিয়ে আঁকা।

## দ্রুত দিকনির্দেশ
- নতুন ডিজাইন যোগ করতে → `docs/ARCHITECTURE.md` এর "নতুন ডিজাইন যোগ করা" অংশ।
- কোনো ডিজাইনের চেহারা বদলাতে → `widget/designs/` এর ওই ডিজাইনের ফাইল।
- লেআউট (সেকেন্ড/কাউন্টডাউনের জায়গা) বদলালে → `tools/genlayout.py` + `docs/LAYOUTS.md`।
- ফায়ারবেজ/লোকেশন/ট্রগল → `docs/SETTINGS_AND_DATA.md`।
