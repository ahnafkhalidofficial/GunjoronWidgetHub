# ফ্রন্টএন্ড কাঠামো (v55)

```
app/src/main/assets/
  index.html                 ← পুরো ফ্রন্টএন্ড (একটাই ফাইল)
  azan.mp3                   ← Kotlin AzanForegroundService ব্যবহার করে
  fonts/*.ttf                ← Kotlin (AppFonts, SplashView) ব্যবহার করে
  notifications_config.json  ← নোটিফিকেশন কনফিগ
  widget_style_config.json   ← উইজেট স্টাইল কনফিগ
  notification_images/       ← নোটিফিকেশন ছবি
  widget_preview_images/     ← উইজেট হাবের প্রিভিউ ছবি 01–24.png (বদলানো যায়) + README.md (কোন নম্বরে কোনটা)
```

## index.html-এর ভেতরে
- শেল (হোম, ফুটার, সেটিংস, স্প্ল্যাশ) + `<script type="application/json" id="…-src">` ব্লকে ৭টা অ্যাপ (JSON-স্ট্রিং), যেগুলো `srcdoc` iframe-এ চলে।
- নামাজ ফ্রেমে আছে পুরোনো প্রজেক্টের JS (আজান, হিজরি সিঙ্ক, উইজেট ব্রিজ)।
- ফাইলের শেষে `<script id="native-bridge">` (Kotlin ↔ JS):
  - `setNativeNetworkStatus`, `setNativeHijriConfig`, `onAzanStopped` → নামাজ ফ্রেমে ফরওয়ার্ড (দেরিতে লোড হলে রিপ্লে)
  - `handleNativeBackPress` → খোলা পেজ থাকলে `history.back()`
  - সেটিংসের পারমিশন সেন্টার (`AndroidWidgetBridge`)
- **এই স্ক্রিপ্টটা সবসময় ফাইলের শেষে রাখুন।**

## Kotlin ↔ কুরআন ডাউনলোড
- `quran/QuranFileBridge.kt`, `quran/QuranLocalServer.kt` — বিস্তারিত: `docs/QURAN_DOWNLOAD_NOTE.md`
- `MainActivity.setupWebView()`-এ `QuranNative` / `QuranTarjamaNative` ব্রিজ ও `shouldInterceptRequest` যুক্ত।
