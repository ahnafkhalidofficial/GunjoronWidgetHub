package com.gunjoron.patheyo.alarm

// রাখতে হবে: app/src/main/java/com/gunjoron/Patheyo/alarm/AlarmScheduler.kt
//
// এই অবজেক্টটা প্রতিটা সক্রিয় ওয়াক্তের জন্য একটা করে exact alarm (AlarmManager) সেট করে রাখে,
// যাতে অ্যাপ পুরোপুরি বন্ধ থাকলেও ঠিক টাইমে আজান বেজে ওঠে। ইন্টারনেট লাগে না — শুধু আগে সেভ করা
// (ক্যাশ করা) নামাজের সময় আর ফোনের লোকাল ঘড়ি দিয়েই হিসাব হয়।
//
// JS থেকে WidgetJSBridge.saveAlarmConfigs(jsonString) কল হলে এখানে এসে শিডিউল হয়।
// jsonString ফরম্যাট: {"Fajr":{"active":true,"time":"05:20"}, "Dhuhr":{"active":true,"time":"12:30"}, ...}
// (time = ২৪ ঘণ্টা ফরম্যাটে, JS-ই কাস্টম/অটো হিসাব করে চূড়ান্ত সময় পাঠায়)

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject
import java.util.Calendar

object AlarmScheduler {
    const val PREFS_NAME = "ibadat_alarm_prefs"
    const val KEY_ALARM_CONFIG = "alarm_config_json"

    private val WAQT_KEYS = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private const val SHOW_REQUEST_CODE = 9100
    private val REQUEST_CODES = mapOf(
        "Fajr" to 9001, "Dhuhr" to 9002, "Asr" to 9003, "Maghrib" to 9004, "Isha" to 9005
    )

    fun saveAlarmConfig(context: Context, jsonString: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ALARM_CONFIG, jsonString).apply()
        scheduleAllAlarms(context)
    }

    fun canScheduleExact(context: Context): Boolean {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) alarmManager.canScheduleExactAlarms() else true
    }

    // ✅ v44: আজান অ্যালার্ম সেট করার নতুন পদ্ধতি — সব ফোনে (বিশেষত পুরনো Honor/Huawei/Xiaomi/Oppo ইত্যাদি
    // OEM ফোনে) যাতে নির্ভরযোগ্যভাবে বাজে:
    //  ১) আগে setAlarmClock() — এটাই অ্যান্ড্রয়েডের "আসল অ্যালার্ম ঘড়ি" API। Doze/অ্যাপ-স্ট্যান্ডবাই এটাকে
    //     আটকায় না, বেশিরভাগ OEM-ও এটাকে ব্যাকগ্রাউন্ড-ক্লিনার থেকে ছাড় দেয়, আর "Alarms & reminders"
    //     (exact alarm) পারমিশন ছাড়াও কাজ করে। বাজার সময় সিস্টেম অ্যাপকে ফোরগ্রাউন্ড সার্ভিস/স্ক্রিন চালুর ছাড়ও দেয়।
    //  ২) ব্যর্থ হলে setExactAndAllowWhileIdle() (পারমিশন থাকলে)।
    //  ৩) তাও না হলে setAndAllowWhileIdle() — অন্তত কিছু সময়ের মধ্যে বাজবে, একদম নীরব থাকবে না।
    // আগে exact পারমিশন না থাকলে এই ফাংশন কোনো অ্যালার্মই সেট না করে চুপচাপ বেরিয়ে যেত।
    fun scheduleAllAlarms(context: Context) {
        val appCtx = context.applicationContext
        val alarmManager = appCtx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val timingsPrefs = appCtx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val timingsJson = timingsPrefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)
        val alarmPrefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val configJson = alarmPrefs.getString(KEY_ALARM_CONFIG, null) ?: return

        try {
            val timings = if (timingsJson != null) JSONObject(timingsJson) else null
            val config = JSONObject(configJson)

            for (waqt in WAQT_KEYS) {
                val reqCode = REQUEST_CODES[waqt] ?: continue
                // প্রতিটা ওয়াক্ত আলাদা try-catch-এ — একটায় সমস্যা হলে বাকিগুলো যেন সেট হয়
                try {
                    val intent = Intent(appCtx, AzanAlarmReceiver::class.java).apply { putExtra("waqt", waqt) }
                    val pendingIntent = PendingIntent.getBroadcast(
                        appCtx, reqCode, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )

                    val waqtConfig = config.optJSONObject(waqt)
                    val active = waqtConfig?.optBoolean("active", false) ?: false
                    if (!active) {
                        alarmManager.cancel(pendingIntent)
                        continue
                    }

                    var timeStr = waqtConfig?.optString("time", "") ?: ""
                    if (timeStr.isEmpty() && timings != null) {
                        timeStr = timings.optString(waqt.lowercase(), "")
                    }
                    if (timeStr.isEmpty()) { alarmManager.cancel(pendingIntent); continue }

                    val triggerMillis = nextOccurrence(timeStr) ?: continue
                    setBestAlarm(appCtx, alarmManager, triggerMillis, pendingIntent)
                } catch (_: Throwable) { /* এই ওয়াক্ত স্কিপ, বাকিগুলো চলবে */ }
            }
        } catch (e: Exception) { /* নষ্ট/অসম্পূর্ণ ডেটা হলে শিডিউল স্কিপ */ }
    }

    internal fun setBestAlarm(ctx: Context, am: AlarmManager, triggerMillis: Long, pi: PendingIntent) {
        // ১) অ্যালার্ম-ক্লক — অ্যাপের ভেতরের ঘড়ির আইকনে ট্যাপ করলে MainActivity খুলবে
        try {
            val showIntent = PendingIntent.getActivity(
                ctx, SHOW_REQUEST_CODE,
                Intent(ctx, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerMillis, showIntent), pi)
            return
        } catch (_: Throwable) { }

        // ২) এক্সাক্ট (পারমিশন থাকলে)
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
                return
            }
        } catch (_: Throwable) { }

        // ৩) শেষ ভরসা — ইনএক্সাক্ট কিন্তু Doze ভেদ করে বাজে
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            } else {
                am.set(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            }
        } catch (_: Throwable) { }
    }

    // আজকের HH:mm যদি পার হয়ে গিয়ে থাকে, কালকেরটার জন্য সেট হবে — exact alarm এক-বারের জন্য তাই
    // AzanAlarmReceiver বাজার পর নিজেই পরের দিনের জন্য আবার শিডিউল করে দেয়
    fun nextOccurrence(hhmm: String): Long? {
        return try {
            val clean = hhmm.trim().split(" ")[0]
            val parts = clean.split(":")
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            cal.set(Calendar.MINUTE, parts[1].toInt())
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            cal.timeInMillis
        } catch (e: Exception) { null }
    }
}
