package com.gunjoron.patheyo.widget

// app/src/main/java/com/gunjoron/Patheyo/widget/WidgetStyleConfig.kt
//
// ✅ v10-v14: এই ফাইলটা ইউজারের ম্যানুয়ালি উইজেটের প্রায় প্রতিটা টেক্সট/বক্স/আইকন — সাইজ, রঙ,
// বোল্ড, দৃশ্যমানতা, পজিশন, স্বচ্ছতা, ছায়া, লেখা পাল্টানো — ইচ্ছামতো ঠিক করার রিকোয়েস্ট অনুযায়ী
// ধাপে ধাপে বানানো হয়েছে (সর্বশেষ v14: প্রতিটা এলিমেন্ট আলাদা আলাদাভাবে নিয়ন্ত্রণযোগ্য)।
//
// কীভাবে কাজ করে (বিস্তারিত গাইড দেখুন: WIDGET_CUSTOMIZATION_GUIDE.md, প্রজেক্টের রুট ফোল্ডারে):
//   ১) আসল কনফিগ ফাইলটা থাকে app/src/main/assets/widget_style_config.json —
//      এটা এডিট করে অ্যাপ রিবিল্ড করলে সবসময় কাজ করবে (গ্যারান্টিসহ, যেকোনো Android ভার্সনে)।
//   ২) অ্যাপ প্রথমবার চালু/আপডেট হওয়ার সময় এই একই ফাইলটার একটা কপি ফোনের
//      Android/data/com.gunjoron.patheyo/files/widget_style_config.json -এ বসিয়ে দেয় —
//      যদি আপনার ফোনের ফাইল-ম্যানেজার/PC (USB) দিয়ে ওই ফোল্ডারে যেতে পারেন, তাহলে ওই কপিটা
//      সরাসরি এডিট করলেই পরের widget-রিফ্রেশে (সর্বোচ্চ ১৫ মিনিট, বা অ্যাপ খুললেই সাথে সাথে)
//      পরিবর্তন দেখা যাবে — রিবিল্ড ছাড়াই।
//   ৩) widget আপডেট হওয়ার সময় প্রতিবার এই দুটো ফাইলের মধ্যে যেটা থাকে সেটা পড়া হয় (বাইরের
//      কপি অগ্রাধিকার পায়, না থাকলে assets-এর ডিফল্টটা ব্যবহার হয়)। ফাইল না থাকলে, বা কোনো
//      একটা মান ভুল/অনুপস্থিত থাকলে — সেই একটা মানের জন্যই নিরাপদ ডিফল্ট ব্যবহার হয় (পুরো
//      widget কখনো ক্র্যাশ করবে না বা ভাঙবে না)।
//
// ✅ v14 ডিজাইন নীতি (v16: শিপ করা JSON-এ এখন কোনো null নেই — সব মান বাস্তব সংখ্যা/রঙ; তবু কোনো key বাদ পড়লে নিচের ডিফল্ট কাজ করবে):
//   TextStyle.sizeSp/colorHex/bold — এগুলো nullable। JSON-এ এই key বাদ দিলে (বা null রাখলে)
//   widget তার নিজের স্বাভাবিক (থিম অনুযায়ী পাল্টানো) মান ব্যবহার করবে, ঠিক যেমন v13-এ ছিল।
//   একটা নির্দিষ্ট মান (যেমন "#FF0000") দিলে সেটাই সবসময় (থিম নির্বিশেষে) ব্যবহার হবে।

import android.content.Context
import org.json.JSONObject
import java.io.File

object WidgetStyleConfig {

    const val CONFIG_FILE_NAME = "widget_style_config.json"
    private const val ASSET_PATH = "widget_style_config.json"

    // ================================================================================
    //  টেক্সট এলিমেন্ট (প্রতিটা লেখার নিজস্ব দেখানো/লুকানো, সাইজ, রঙ, বোল্ড)
    // ================================================================================
    data class TextStyle(
        val visible: Boolean = true,
        // null = widget-এর নিজস্ব স্বাভাবিক সাইজ ব্যবহার হবে (থিম/সাইজ-প্রিসেট অনুযায়ী)
        val sizeSp: Float? = null,
        // null = widget-এর নিজস্ব স্বাভাবিক রঙ (থিম অনুযায়ী) ব্যবহার হবে; "#RRGGBB" বা
        // "#AARRGGBB" ফরম্যাটে একটা রঙ দিলে সেটাই (থিম নির্বিশেষে) সবসময় ব্যবহার হবে
        val colorHex: String? = null,
        // null = widget-এর নিজস্ব ডিফল্ট বোল্ড/আনবোল্ড আচরণ বজায় থাকবে
        val bold: Boolean? = null,
        // ✅ v15: শুধু এই লেখাটাকে (পুরো বক্স না) আড়াআড়ি/লম্বালম্বি টানা-লম্বা/চেপ্টা করার জন্য —
        // 1.0 = স্বাভাবিক, 1.3 = ৩০% চওড়া/লম্বা, 0.8 = ২০% সরু/খাটো। শুধু ঘড়ির সময়/সেকেন্ডের
        // জন্য ব্যবহারিকভাবে কার্যকর (বাকি এলিমেন্টেও কাজ করে, কিন্তু চাহিদা মূলত ঘড়ির জন্য)।
        val scaleX: Float = 1f,
        val scaleY: Float = 1f,
        // ✅ v15: এই লেখার নিজস্ব অক্ষর/সংখ্যার মাঝের ফাঁকা (em এককে) — global letter_spacing-
        // এর থেকে আলাদা, শুধু এই একটা এলিমেন্টের জন্য। null = global মানই ব্যবহার হবে।
        val letterSpacingEm: Float? = null,
        // ✅ v16: লাইট থিমে ব্যবহারের রঙ (null হলে colorHex-ই সব থিমে)
        val colorLightHex: String? = null,
        // ✅ v16: নিষিদ্ধ সময়ের রঙ (শুধু কাউন্টডাউন লেখা/সংখ্যার জন্য; null হলে ডিফল্ট লাল)
        val colorForbiddenHex: String? = null
    )

    // ================================================================================
    //  আইকন এলিমেন্ট (গোল ব্যাজ + ভেতরের ছোট আইকন, একসাথে একটা ইউনিট হিসেবে)
    // ================================================================================
    data class IconStyle(
        val visible: Boolean = true,
        val scale: Float = 1f
    )

    data class Texts(
        val hijriDayNumber: TextStyle = TextStyle(),
        val hijriMonthYear: TextStyle = TextStyle(),
        val dateOthers: TextStyle = TextStyle(),
        val celestialTitle: TextStyle = TextStyle(),
        val celestialTime: TextStyle = TextStyle(),
        val clockTime: TextStyle = TextStyle(scaleY = 1.3f, letterSpacingEm = 0.02f),
        val clockSeconds: TextStyle = TextStyle(scaleY = 1.1f),
        val clockAmPm: TextStyle = TextStyle(),
        val weatherTitle: TextStyle = TextStyle(),
        val weatherValue: TextStyle = TextStyle(),
        val sehriTitle: TextStyle = TextStyle(),
        val sehriTime: TextStyle = TextStyle(),
        val iftarTitle: TextStyle = TextStyle(),
        val iftarTime: TextStyle = TextStyle(),
        // prayerNames/prayerTimes — ৫টা ওয়াক্তের নাম/সময় একসাথে একই স্টাইল শেয়ার করে (গ্রুপ)
        val prayerNames: TextStyle = TextStyle(),
        val prayerTimes: TextStyle = TextStyle(),
        val countdownLabel: TextStyle = TextStyle(),
        val countdownChrono: TextStyle = TextStyle()
    )

    data class Icons(
        val logo: IconStyle = IconStyle(),
        val celestialIcon: IconStyle = IconStyle(),
        val clockIcon: IconStyle = IconStyle(scale = 0.9f),
        val sehriIcon: IconStyle = IconStyle(),
        val iftarIcon: IconStyle = IconStyle(),
        val weatherIcon: IconStyle = IconStyle(),
        val countdownWarningIcon: IconStyle = IconStyle()
    )

    // ================================================================================
    //  প্রতিটা নামাজের রো আলাদাভাবে দেখানো/লুকানো
    // ================================================================================
    data class PrayerRowsVisible(
        val fajr: Boolean = true,
        val dhuhr: Boolean = true,
        val asr: Boolean = true,
        val maghrib: Boolean = true,
        val isha: Boolean = true
    )

    // ================================================================================
    //  লেখার আসল শব্দ পাল্টানো (যেমন "সূর্যোদয়"-এর বদলে আপনার নিজের শব্দ)। null = ডিফল্ট শব্দ।
    // ================================================================================
    // ✅ v15: আগে সব null ছিল (ইউজারকে ইংরেজি key নাম দেখে বুঝতে হতো কোনটা কী)। এখন প্রতিটার
    // ডিফল্ট মান সরাসরি আসল বাংলা শব্দটাই — JSON ফাইলে খুললেই সরাসরি "ফজর"/"সূর্যোদয়" ইত্যাদি
    // দেখা যাবে, এখানেই বানান ঠিক করা বা সম্পূর্ণ নতুন শব্দ বসানো যাবে (ইংরেজি জানার দরকার নেই)।
    data class Labels(
        val sunrise: String = "সূর্যোদয়",
        val sunset: String = "সূর্যাস্ত",
        val sehri: String = "সাহরী",
        val iftar: String = "ইফতার",
        val weather: String = "আবহাওয়া",
        val fajr: String = "ফজর",
        val dhuhr: String = "যোহর",
        val jumma: String = "জুম'আ",
        val asr: String = "আসর",
        val maghrib: String = "মাগরিব",
        val isha: String = "ইশা"
    )

    // ================================================================================
    //  বক্স/শেপ ট্রান্সফর্ম (v12 থেকে, v14-এ backgroundVisible যোগ হলো)
    // ================================================================================
    data class BoxTransform(
        val translateXDp: Float = 0f,
        val translateYDp: Float = 0f,
        val scale: Float = 1f,
        // ✅ v14: আলাদাভাবে শুধু প্রস্থ (X) বা শুধু উচ্চতা (Y) বদলানো — null হলে উপরের "scale"-ই
        // দুই দিকে ব্যবহার হয়। (মনে রাখবেন: ভিউ-স্কেল বক্সের ভেতরের কনটেন্টকেও একসাথে স্কেল করে)
        val scaleX: Float? = null,
        val scaleY: Float? = null,
        val alpha: Float = 1f,
        val elevationDp: Float = 0f,
        // পুরো বক্স (ব্যাকগ্রাউন্ড শেপ + ভেতরের সব কনটেন্ট) দেখানো/লুকানো
        val visible: Boolean = true,
        // ✅ v14: শুধু ব্যাকগ্রাউন্ড শেপ/রঙটা লুকিয়ে ফেলে (কনটেন্ট/লেখা/আইকন ঠিক জায়গায় থেকে
        // যাবে, শুধু পেছনের কালার্ড বক্সটাই থাকবে না) — "visible" থেকে আলাদা, কারণ visible
        // পুরো জিনিসটাই (কনটেন্টসহ) সরিয়ে দেয়, আর এটা শুধু "বক্সটা" সরায়।
        val backgroundVisible: Boolean = true
    )

    data class Boxes(
        val mainCard: BoxTransform = BoxTransform(elevationDp = 30f),
        val logoFrame: BoxTransform = BoxTransform(),
        val clockPill: BoxTransform = BoxTransform(),
        val celestialPill: BoxTransform = BoxTransform(),
        val sehriPill: BoxTransform = BoxTransform(),
        val iftarPill: BoxTransform = BoxTransform(),
        val weatherPill: BoxTransform = BoxTransform(),
        // ✅ v15: ঘড়ির AM/PM-এর নিচের গোল ব্যাকগ্রাউন্ড বৃত্ত — বাকি বক্সের মতোই সরানো/ছোট-বড়/
        // স্বচ্ছতা/ছায়া/লুকানো, প্লাস শুধু ব্যাকগ্রাউন্ড-বৃত্তটা লুকিয়ে ভেতরের "AM"/"PM" লেখাটা
        // রেখে দেওয়া (background_visible)।
        val clockAmpmBox: BoxTransform = BoxTransform(translateXDp = -8f)
    )

    // ================================================================================
    //  ৪টা মূল সারি (লাইন) — পুরো লাইনটা (তার ভেতরের সব বক্স/লেখাসহ) উপরে-নিচে/ডানে-বামে সরানো,
    //  ছোট-বড়, স্বচ্ছতা, ছায়া, লুকানো। এটা কোনো একটা নির্দিষ্ট বক্সের জন্য না, পুরো লাইনের জন্য।
    // ================================================================================
    data class Rows(
        // সারি ১: লোগো + তারিখ + সূর্যোদয়/সূর্যাস্ত
        val topRow: BoxTransform = BoxTransform(),
        // সারি ২: ঘড়ি + সাহরী/ইফতার/আবহাওয়া
        val clockWeatherRow: BoxTransform = BoxTransform(),
        // সারি ৩: নামাজের নাম + সময় (৫ ওয়াক্তই একসাথে, পুরো লাইনটা)
        val prayersRow: BoxTransform = BoxTransform(),
        // সারি ৪: নিচের কাউন্টডাউন লাইন
        val countdownRow: BoxTransform = BoxTransform()
    )

    // ================================================================================
    //  চলমান ওয়াক্তের হাইলাইট বক্স — সাইজ/অ্যাসপেক্ট-রেশিও/ছায়া/পজিশন (রঙ এখনও
    //  widget_card_highlight.xml / widget_card_highlight_light.xml-এ, রিবিল্ড লাগে — কারণ ব্যাখ্যা
    //  গাইডে দেওয়া আছে)। scaleX/scaleY দিয়ে অ্যাসপেক্ট-রেশিও (যেমন 1:1, 1:2) বদলানো যায়, আর
    //  Android-এর ডিফল্ট পিভট-পয়েন্ট (ভিউর কেন্দ্র) ব্যবহার হয় বলে ছোট-বড়/রেশিও যাই করুন না কেন
    //  এটা সবসময় তার নিজের জায়গার কেন্দ্রেই থেকে যায় — আলাদা করে কিছু করা লাগে না।
    // ================================================================================
    data class Highlight(
        val translateXDp: Float = 0f,
        val translateYDp: Float = 0f,
        val scale: Float = 1f,
        val scaleX: Float? = null,
        val scaleY: Float? = null,
        val elevationDp: Float = 0f,
        // ✅ v16: হাইলাইট বক্স এখন আলাদা ১:১ রাউন্ডেড-স্কয়ার বিটম্যাপ (লেখা অক্ষত)।
        //  sizeAdjustDp = বক্সের বাহুর মাপে যোগ/বিয়োগ (dp; 0 = ঠিক ঘরের উচ্চতার সমান স্কয়ার)
        //  cornerRadiusDp = কোণার গোলাকার ভাব (dp)
        val sizeAdjustDp: Float = 0f,
        val cornerRadiusDp: Float = 10f,
        // ✅ v17: হাইলাইট বক্সের রঙ JSON থেকে (রিবিল্ড ছাড়াই)। null হলে res/values/colors.xml-এর
        // widget_highlight_dark / widget_highlight_light ব্যবহার হয়। ডার্ক ডিফল্ট = #E6E6E6।
        val colorHex: String? = null,
        val colorLightHex: String? = null,
        // ✅ v20: হাইলাইট বক্সের প্রস্থ-ফ্যাক্টর — উচ্চতা (= ঘরের উচ্চতা) অপরিবর্তিত থাকে, শুধু ডান-বাম
        // সামান্য চওড়া হয় (১.০ = আগের মতো ১:১; ডিফল্ট ১.১২ = ১২% চওড়া)। ঘরের প্রস্থের বেশি হয় না
        // (পাশের ঘরে ঢুকে যাবে না — কোডে নিরাপত্তা-সীমা আছে)। সব Android ভার্সনে কাজ করে।
        val widthScale: Float = 1.12f
    )

    // ✅ v17: মূল কার্ডের কিনারা থেকে ভেতরের দৃশ্যমান কনটেন্ট পর্যন্ত ফাঁকা — উপর/নিচ/ডান/বাম চারদিকে
    // একই (edge_padding_dp)। কোড প্রতিটা ভ্যারিয়েন্টে (কাউন্টডাউন আছে/নেই, হাইলাইট আছে/নেই) নিজে
    // হিসাব করে নিচের ফাঁকাও ঠিক উপরের ফাঁকার সমান রাখে। bottom_extra_dp = শুধু নিচে হাতে-ধরে বাড়ানো/কমানো
    // (ডিফল্ট ০)। min_edge_padding_dp = খুব ছোট সাইজে রিসাইজ করলে ফাঁকা কমতে কমতে যে মান পর্যন্ত নামবে।
    data class Layout(
        val edgePaddingDp: Float = 10f,
        val bottomExtraDp: Float = 0f,
        val minEdgePaddingDp: Float = 5f
    )

    // ✅ v17: আইকনের গোল ব্যাকগ্রাউন্ড বৃত্ত — ডার্ক (গ্লাস/ট্রান্সপারেন্ট-ডার্ক) ও লাইট (লাইট/ট্রান্সপারেন্ট-লাইট)
    // আলাদা রঙ + অপাসিটি। opacity = ভেতরের ভরাট রঙের অপাসিটি (০.০–১.০), border_opacity = বৃত্তের কিনারার।
    // ডিফল্ট মানগুলো v16-এর আগের ড্রয়েবল (#40 = ০.২৫, #73 = ০.৪৫) থেকে নেওয়া — অর্থাৎ দেখতে আগের মতোই।
    data class CircleStyle(
        val colorHex: String,
        val opacity: Float = 0.25f,
        val borderOpacity: Float = 0.45f,
        val colorLightHex: String,
        val opacityLight: Float = 0.25f,
        val borderOpacityLight: Float = 0.45f
    )

    data class IconCircles(
        val celestial: CircleStyle = CircleStyle("#FBBF24", colorLightHex = "#D97706"),
        val clock: CircleStyle = CircleStyle("#6E92FF", colorLightHex = "#235FFE"),
        val sehri: CircleStyle = CircleStyle("#235FFE", colorLightHex = "#1D4FD4"),
        val iftar: CircleStyle = CircleStyle("#FB923C", colorLightHex = "#EA580C"),
        val weather: CircleStyle = CircleStyle("#34D399", colorLightHex = "#059669"),
        val ampm: CircleStyle = CircleStyle("#6E92FF", colorLightHex = "#235FFE")
    )

    // ✅ v17: ইংরেজি ও বাংলা তারিখের মাঝের দাগ (|) — এখন ফন্টের অক্ষর না, সরাসরি এঁকে দেওয়া একটা
    // নরম-কোণা দাগ (তাই নেট/ফন্ট কিছুর উপর নির্ভর করে না)। height_em = লেখার সাইজের কতগুণ লম্বা,
    // (আগের ফন্টের '|' ছিল প্রায় ০.৫১ em লম্বা, এখন ০.৭২ em) width_dp = দাগের চওড়াই (মোটা/চিকন), color/color_light_theme = রঙ (#AARRGGBB দিলে স্বচ্ছতাও ঠিক হয়)।
    data class DateSeparator(
        val visible: Boolean = true,
        val heightEm: Float = 0.72f,
        val widthDp: Float = 1.1f,
        val gapEm: Float = 0.5f,
        val colorHex: String = "#A6FFFFFF",
        val colorLightHex: String = "#99464749"
    )

    data class Config(
        val texts: Texts = Texts(),
        val icons: Icons = Icons(),
        val prayerRows: PrayerRowsVisible = PrayerRowsVisible(),
        val labels: Labels = Labels(),
        val letterSpacingEm: Float = 0.05f,
        val lineGapExtraDp: Float = 5f,
        val boxes: Boxes = Boxes(),
        val rows: Rows = Rows(),
        val highlight: Highlight = Highlight(),
        val layout: Layout = Layout(),
        val iconCircles: IconCircles = IconCircles(),
        val dateSeparator: DateSeparator = DateSeparator()
    )

    /** widget আপডেট হওয়ার শুরুতে একবার কল করুন — বাইরের/assets JSON পড়ে Config রিটার্ন করে। */
    fun load(context: Context): Config {
        return try {
            val json = readConfigJson(context)
            if (json == null) Config() else parseConfig(json)
        } catch (_: Throwable) {
            Config()
        }
    }

    /** অ্যাপ চালু হওয়ার সময় বাইরের এডিটযোগ্য কপিটা তৈরি করে দেয়, যদি আগে থেকে না থাকে। */
    fun ensureExternalCopyExists(context: Context) {
        try {
            val dir = context.getExternalFilesDir(null) ?: return
            val file = File(dir, CONFIG_FILE_NAME)
            // ✅ v14: আগের ভার্সনের (v10-v13) পুরনো কাঠামোর ফাইল থাকলে (যেখানে নতুন "texts" সেকশন
            // নেই) সেটা .old নামে ব্যাকআপ রেখে নতুন ফাইল বসিয়ে দেওয়া হয় — নাহলে ফোনের পুরনো
            // কপি অগ্রাধিকার পেয়ে নতুন অপশনগুলো (লেখা/আইকন/বক্স কন্ট্রোল) আর দেখাই যেত না।
            // ✅ v17: নতুন সেকশন (icon_circles, date_separator, layout.edge_padding_dp, highlight.color)
            // যোগ হয়েছে — তাই "config_version" >= 17 না থাকলে ফোনের পুরনো কপিটা .old ব্যাকআপ করে নতুনটা বসে।
            val isOldSchema = file.exists() && !isCurrentSchema(file.readText())
            if (isOldSchema) {
                try { file.copyTo(File(dir, "$CONFIG_FILE_NAME.old"), overwrite = true) } catch (_: Throwable) {}
                file.delete()
            }
            if (!file.exists()) {
                val defaultText = context.assets.open(ASSET_PATH).bufferedReader().use { it.readText() }
                file.writeText(defaultText)
            }
        } catch (_: Throwable) {
            // ব্যর্থ হলেও widget assets-এর ডিফল্ট JSON দিয়ে স্বাভাবিকভাবেই কাজ চালিয়ে যাবে
        }
    }

    const val SCHEMA_VERSION = 18

    private fun isCurrentSchema(text: String): Boolean {
        return try {
            val o = JSONObject(text)
            o.has("texts") && o.optInt("config_version", 0) >= SCHEMA_VERSION
        } catch (_: Throwable) { false }
    }

    private fun readConfigJson(context: Context): JSONObject? {
        try {
            val dir = context.getExternalFilesDir(null)
            if (dir != null) {
                val file = File(dir, CONFIG_FILE_NAME)
                if (file.exists()) {
                    val text = file.readText()
                    if (text.isNotBlank() && isCurrentSchema(text)) return JSONObject(text)
                }
            }
        } catch (_: Throwable) { /* নিচে assets ফলব্যাক */ }

        return try {
            val text = context.assets.open(ASSET_PATH).bufferedReader().use { it.readText() }
            JSONObject(text)
        } catch (_: Throwable) {
            null
        }
    }

    private fun jFloat(obj: JSONObject, key: String, default: Float): Float =
        if (obj.has(key) && !obj.isNull(key)) obj.optDouble(key, default.toDouble()).toFloat() else default

    private fun jFloatOrNull(obj: JSONObject, key: String, default: Float?): Float? =
        if (obj.has(key) && !obj.isNull(key)) obj.optDouble(key, Double.NaN).let { if (it.isNaN()) default else it.toFloat() } else default

    private fun jBool(obj: JSONObject, key: String, default: Boolean): Boolean =
        if (obj.has(key) && !obj.isNull(key)) obj.optBoolean(key, default) else default

    private fun jBoolOrNull(obj: JSONObject, key: String, default: Boolean?): Boolean? =
        if (obj.has(key) && !obj.isNull(key)) obj.optBoolean(key) else default

    private fun jStringOrNull(obj: JSONObject, key: String, default: String?): String? =
        if (obj.has(key) && !obj.isNull(key)) obj.optString(key).ifBlank { default } else default

    private fun parseTextStyle(obj: JSONObject?, default: TextStyle): TextStyle {
        if (obj == null) return default
        return TextStyle(
            visible = jBool(obj, "visible", default.visible),
            sizeSp = jFloatOrNull(obj, "size_sp", default.sizeSp),
            colorHex = jStringOrNull(obj, "color", default.colorHex),
            bold = jBoolOrNull(obj, "bold", default.bold),
            scaleX = jFloat(obj, "stretch_x", default.scaleX),
            scaleY = jFloat(obj, "stretch_y", default.scaleY),
            letterSpacingEm = jFloatOrNull(obj, "letter_spacing_em", default.letterSpacingEm),
            colorLightHex = jStringOrNull(obj, "color_light_theme", default.colorLightHex),
            colorForbiddenHex = jStringOrNull(obj, "color_forbidden", default.colorForbiddenHex)
        )
    }

    private fun parseIconStyle(obj: JSONObject?, default: IconStyle): IconStyle {
        if (obj == null) return default
        return IconStyle(
            visible = jBool(obj, "visible", default.visible),
            scale = jFloat(obj, "scale", default.scale)
        )
    }

    private fun parseBoxTransform(obj: JSONObject?, default: BoxTransform): BoxTransform {
        if (obj == null) return default
        return BoxTransform(
            translateXDp = jFloat(obj, "move_right_dp", default.translateXDp),
            translateYDp = jFloat(obj, "move_down_dp", default.translateYDp),
            scale = jFloat(obj, "scale", default.scale),
            scaleX = jFloatOrNull(obj, "scale_x", default.scaleX),
            scaleY = jFloatOrNull(obj, "scale_y", default.scaleY),
            alpha = jFloat(obj, "opacity", default.alpha),
            elevationDp = jFloat(obj, "shadow_dp", default.elevationDp),
            visible = jBool(obj, "visible", default.visible),
            backgroundVisible = jBool(obj, "background_visible", default.backgroundVisible)
        )
    }

    private fun parseConfig(root: JSONObject): Config {
        val d = Config()

        val t = root.optJSONObject("texts")
        val texts = if (t == null) d.texts else Texts(
            hijriDayNumber = parseTextStyle(t.optJSONObject("hijri_day_number"), d.texts.hijriDayNumber),
            hijriMonthYear = parseTextStyle(t.optJSONObject("hijri_month_year"), d.texts.hijriMonthYear),
            dateOthers = parseTextStyle(t.optJSONObject("date_others"), d.texts.dateOthers),
            celestialTitle = parseTextStyle(t.optJSONObject("celestial_title"), d.texts.celestialTitle),
            celestialTime = parseTextStyle(t.optJSONObject("celestial_time"), d.texts.celestialTime),
            clockTime = parseTextStyle(t.optJSONObject("clock_time"), d.texts.clockTime),
            clockSeconds = parseTextStyle(t.optJSONObject("clock_seconds"), d.texts.clockSeconds),
            clockAmPm = parseTextStyle(t.optJSONObject("clock_ampm"), d.texts.clockAmPm),
            weatherTitle = parseTextStyle(t.optJSONObject("weather_title"), d.texts.weatherTitle),
            weatherValue = parseTextStyle(t.optJSONObject("weather_value"), d.texts.weatherValue),
            sehriTitle = parseTextStyle(t.optJSONObject("sehri_title"), d.texts.sehriTitle),
            sehriTime = parseTextStyle(t.optJSONObject("sehri_time"), d.texts.sehriTime),
            iftarTitle = parseTextStyle(t.optJSONObject("iftar_title"), d.texts.iftarTitle),
            iftarTime = parseTextStyle(t.optJSONObject("iftar_time"), d.texts.iftarTime),
            prayerNames = parseTextStyle(t.optJSONObject("prayer_names"), d.texts.prayerNames),
            prayerTimes = parseTextStyle(t.optJSONObject("prayer_times"), d.texts.prayerTimes),
            countdownLabel = parseTextStyle(t.optJSONObject("countdown_label"), d.texts.countdownLabel),
            countdownChrono = parseTextStyle(t.optJSONObject("countdown_chrono"), d.texts.countdownChrono)
        )

        val ic = root.optJSONObject("icons")
        val icons = if (ic == null) d.icons else Icons(
            logo = parseIconStyle(ic.optJSONObject("logo"), d.icons.logo),
            celestialIcon = parseIconStyle(ic.optJSONObject("celestial_icon"), d.icons.celestialIcon),
            clockIcon = parseIconStyle(ic.optJSONObject("clock_icon"), d.icons.clockIcon),
            sehriIcon = parseIconStyle(ic.optJSONObject("sehri_icon"), d.icons.sehriIcon),
            iftarIcon = parseIconStyle(ic.optJSONObject("iftar_icon"), d.icons.iftarIcon),
            weatherIcon = parseIconStyle(ic.optJSONObject("weather_icon"), d.icons.weatherIcon),
            countdownWarningIcon = parseIconStyle(ic.optJSONObject("countdown_warning_icon"), d.icons.countdownWarningIcon)
        )

        val pr = root.optJSONObject("prayer_rows")
        val prayerRows = if (pr == null) d.prayerRows else PrayerRowsVisible(
            fajr = jBool(pr, "fajr", d.prayerRows.fajr),
            dhuhr = jBool(pr, "dhuhr", d.prayerRows.dhuhr),
            asr = jBool(pr, "asr", d.prayerRows.asr),
            maghrib = jBool(pr, "maghrib", d.prayerRows.maghrib),
            isha = jBool(pr, "isha", d.prayerRows.isha)
        )

        val lb = root.optJSONObject("labels")
        fun jStr(o: JSONObject, key: String, default: String): String =
            if (o.has(key) && !o.isNull(key)) o.optString(key).ifBlank { default } else default
        val labels = if (lb == null) d.labels else Labels(
            sunrise = jStr(lb, "sunrise", d.labels.sunrise),
            sunset = jStr(lb, "sunset", d.labels.sunset),
            sehri = jStr(lb, "sehri", d.labels.sehri),
            iftar = jStr(lb, "iftar", d.labels.iftar),
            weather = jStr(lb, "weather", d.labels.weather),
            fajr = jStr(lb, "fajr", d.labels.fajr),
            dhuhr = jStr(lb, "dhuhr", d.labels.dhuhr),
            jumma = jStr(lb, "jumma", d.labels.jumma),
            asr = jStr(lb, "asr", d.labels.asr),
            maghrib = jStr(lb, "maghrib", d.labels.maghrib),
            isha = jStr(lb, "isha", d.labels.isha)
        )

        val ls = root.optJSONObject("letter_spacing")
        val letterSpacingEm = if (ls == null) d.letterSpacingEm else jFloat(ls, "value_em", d.letterSpacingEm)

        val lg = root.optJSONObject("line_gap")
        val lineGapExtraDp = if (lg == null) d.lineGapExtraDp else jFloat(lg, "extra_gap_dp", d.lineGapExtraDp)

        val boxesObj = root.optJSONObject("boxes")
        val boxes = if (boxesObj == null) d.boxes else Boxes(
            mainCard = parseBoxTransform(boxesObj.optJSONObject("main_card"), d.boxes.mainCard),
            logoFrame = parseBoxTransform(boxesObj.optJSONObject("logo_frame"), d.boxes.logoFrame),
            clockPill = parseBoxTransform(boxesObj.optJSONObject("clock_pill"), d.boxes.clockPill),
            celestialPill = parseBoxTransform(boxesObj.optJSONObject("celestial_pill"), d.boxes.celestialPill),
            sehriPill = parseBoxTransform(boxesObj.optJSONObject("sehri_pill"), d.boxes.sehriPill),
            iftarPill = parseBoxTransform(boxesObj.optJSONObject("iftar_pill"), d.boxes.iftarPill),
            weatherPill = parseBoxTransform(boxesObj.optJSONObject("weather_pill"), d.boxes.weatherPill),
            clockAmpmBox = parseBoxTransform(boxesObj.optJSONObject("clock_ampm_box"), d.boxes.clockAmpmBox)
        )

        val rowsObj = root.optJSONObject("rows")
        val rows = if (rowsObj == null) d.rows else Rows(
            topRow = parseBoxTransform(rowsObj.optJSONObject("top_row"), d.rows.topRow),
            clockWeatherRow = parseBoxTransform(rowsObj.optJSONObject("clock_weather_row"), d.rows.clockWeatherRow),
            prayersRow = parseBoxTransform(rowsObj.optJSONObject("prayers_row"), d.rows.prayersRow),
            countdownRow = parseBoxTransform(rowsObj.optJSONObject("countdown_row"), d.rows.countdownRow)
        )

        val hlObj = root.optJSONObject("highlight")
        val highlight = if (hlObj == null) d.highlight else Highlight(
            translateXDp = jFloat(hlObj, "move_right_dp", d.highlight.translateXDp),
            translateYDp = jFloat(hlObj, "move_down_dp", d.highlight.translateYDp),
            scale = jFloat(hlObj, "scale", d.highlight.scale),
            scaleX = jFloatOrNull(hlObj, "scale_x", d.highlight.scaleX),
            scaleY = jFloatOrNull(hlObj, "scale_y", d.highlight.scaleY),
            elevationDp = jFloat(hlObj, "shadow_dp", d.highlight.elevationDp),
            sizeAdjustDp = jFloat(hlObj, "size_adjust_dp", d.highlight.sizeAdjustDp),
            cornerRadiusDp = jFloat(hlObj, "corner_radius_dp", d.highlight.cornerRadiusDp),
            colorHex = jStringOrNull(hlObj, "color", d.highlight.colorHex),
            colorLightHex = jStringOrNull(hlObj, "color_light_theme", d.highlight.colorLightHex),
            widthScale = jFloat(hlObj, "width_scale", d.highlight.widthScale)
        )

        val lyObj = root.optJSONObject("layout")
        val layout = if (lyObj == null) d.layout else Layout(
            edgePaddingDp = jFloat(lyObj, "edge_padding_dp", d.layout.edgePaddingDp).coerceIn(0f, 40f),
            bottomExtraDp = jFloat(lyObj, "bottom_extra_dp", d.layout.bottomExtraDp).coerceIn(-20f, 40f),
            minEdgePaddingDp = jFloat(lyObj, "min_edge_padding_dp", d.layout.minEdgePaddingDp).coerceIn(0f, 40f)
        )

        fun parseCircle(o: JSONObject?, def: CircleStyle): CircleStyle {
            if (o == null) return def
            return CircleStyle(
                colorHex = jStr(o, "color", def.colorHex),
                opacity = jFloat(o, "opacity", def.opacity).coerceIn(0f, 1f),
                borderOpacity = jFloat(o, "border_opacity", def.borderOpacity).coerceIn(0f, 1f),
                colorLightHex = jStr(o, "color_light_theme", def.colorLightHex),
                opacityLight = jFloat(o, "opacity_light_theme", def.opacityLight).coerceIn(0f, 1f),
                borderOpacityLight = jFloat(o, "border_opacity_light_theme", def.borderOpacityLight).coerceIn(0f, 1f)
            )
        }
        val icObj = root.optJSONObject("icon_circles")
        val iconCircles = if (icObj == null) d.iconCircles else IconCircles(
            celestial = parseCircle(icObj.optJSONObject("celestial"), d.iconCircles.celestial),
            clock = parseCircle(icObj.optJSONObject("clock"), d.iconCircles.clock),
            sehri = parseCircle(icObj.optJSONObject("sehri"), d.iconCircles.sehri),
            iftar = parseCircle(icObj.optJSONObject("iftar"), d.iconCircles.iftar),
            weather = parseCircle(icObj.optJSONObject("weather"), d.iconCircles.weather),
            ampm = parseCircle(icObj.optJSONObject("ampm"), d.iconCircles.ampm)
        )

        val dsObj = root.optJSONObject("date_separator")
        val dateSeparator = if (dsObj == null) d.dateSeparator else DateSeparator(
            visible = jBool(dsObj, "visible", d.dateSeparator.visible),
            heightEm = jFloat(dsObj, "height_em", d.dateSeparator.heightEm).coerceIn(0.4f, 3f),
            widthDp = jFloat(dsObj, "width_dp", d.dateSeparator.widthDp).coerceIn(0.5f, 6f),
            gapEm = jFloat(dsObj, "gap_em", d.dateSeparator.gapEm).coerceIn(0f, 2f),
            colorHex = jStr(dsObj, "color", d.dateSeparator.colorHex),
            colorLightHex = jStr(dsObj, "color_light_theme", d.dateSeparator.colorLightHex)
        )

        return Config(texts, icons, prayerRows, labels, letterSpacingEm, lineGapExtraDp, boxes, rows, highlight, layout, iconCircles, dateSeparator)
    }
}
