package com.gunjoron.patheyo.notification

import java.util.Calendar

object HijriCalendarHelper {

    fun getTodayHijri(maghribPassed: Boolean, adjustment: Int = 0): HijriDate {
        val calendar = Calendar.getInstance()
        if (maghribPassed) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        
        // Tabular Islamic Calendar Algorithm
        val y = calendar.get(Calendar.YEAR)
        val m = calendar.get(Calendar.MONTH) + 1
        val d = calendar.get(Calendar.DAY_OF_MONTH)
        
        val a = (14 - m) / 12
        val y2 = y + 4800 - a
        val m2 = m + 12 * a - 3
        val jdn = d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
        
        val islamicEpoch = 1948440
        var l = jdn - islamicEpoch + 10632 + adjustment
        
        val n = (l - 1) / 10631
        l = l - 10631 * n + 354
        val j = (10985 - l) / 5316 * (50 * l / 17719) + (l / 5670) * (43 * l / 15238)
        l = l - (30 - j) / 15 * (17719 * j / 50) - (j / 16) * (15238 * j / 43) + 29
        
        val month = (24 * l) / 709
        val day = l - (709 * month) / 24
        val year = 30 * n + j - 30
        
        return HijriDate(day.toInt(), month.toInt(), year.toInt())
    }

    data class HijriDate(val day: Int, val month: Int, val year: Int)
}
