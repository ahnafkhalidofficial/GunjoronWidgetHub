package com.gunjoron.patheyo

// app/src/main/java/com/gunjoron/Patheyo/FirebaseDataManager.kt
//
// Firebase Realtime Database থেকে আরবি তারিখ রিয়েল-টাইমে নিয়ে উইজেটে দেওয়া।
// কাজের পদ্ধতি (Messenger-এর মতো):
//  - অ্যাপ চালু থাকলে → RTDB WebSocket সংযোগ থাকে, পরিবর্তন হলেই সাথে সাথে পায়
//  - অ্যাপ বন্ধ থাকলে → FCM push জাগিয়ে দেয় (PatheyoMessagingService দেখুন)
//  - নেট বন্ধ ১২+ ঘন্টা → RTDB offline disk cache থেকে শেষ তারিখ দেখায়
//
// Firebase Console-এ যা পরিবর্তন করবেন:
//   Realtime Database → prayer_config → hijri_override (true/false) + bn / en → {day, month} (বিস্তারিত: docs/HIJRI_OVERRIDE_GUIDE.md)
//   পুরনো পদ্ধতি (hijri_override না থাকলে): hijri_date → তারিখ লিখুন (বাংলা/ইংরেজি, বছর না দিলেও চলবে)
//   উদাহরণ: "৩০ রবিউস সানি"  বা  "30 Rabi al-Thani"  বা  "২৬ যিলহজ ১৪৪৬"; ফাঁকা রাখলে অটোমেটিক

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.tasks.Tasks
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.gunjoron.patheyo.notification.HijriCalendarHelper
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

object FirebaseDataManager {

    // v62: widget   (  UI thread   )
    private val widgetExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    const val RTDB_URL = "https://hijri-tarikh-default-rtdb.firebaseio.com/"

    // Firebase Realtime Database-এ এই পাথে এডজাস্টমেন্ট রাখতে হবে (-১, ০, ১)
    private const val RTDB_CONFIG_PATH = "prayer_config"
    private const val KEY_ADJ = "hijri_adjustment"
    private const val KEY_DATE = "hijri_date"
    private const val KEY_OVERRIDE_ACTIVE = "hijri_override_active"   // ওভাররাইড চালু থাকলে true — saveTimings যেন উইজেটের তারিখ মুছে না দেয়
    private const val KEY_OVERRIDE = "hijri_override"   // true/false সুইচ; সাথে bn / en / … (প্রতিটায় day, month, ঐচ্ছিক year)

    // SharedPreferences-এ এই key-তে তারিখ সেভ হবে
    const val KEY_HIJRI_FIREBASE = "hijri_date_firebase"
    private const val KEY_LAST_ADJUSTMENT = "last_rtdb_adjustment"

    // ✅ FIX #1: hijriFirebase কোন গ্রেগরিয়ান তারিখে সেভ হয়েছিল সেটা মনে রাখার key।
    // এটা না থাকলে রাত ১২টার পর "আজকের মাগরিব সময়" এর সাথে তুলনা করতে গিয়ে
    // তারিখ আবার আগের দিনে ফিরে যাচ্ছিল (বাগ)। এখন দিন-গণনা করে হিসাব হয়, তাই
    // মাগরিবের পর যে +১ দিন শিফট হয়, সেটা মধ্যরাতেও অক্ষুণ্ণ থাকবে — পরের মাগরিব
    // না হওয়া পর্যন্ত আর পরিবর্তন হবে না।
    const val KEY_HIJRI_FIREBASE_SET_ON = "hijri_date_firebase_set_on"

    // ✅ FIX #NEW (v3 — মধ্যরাতে/ব্যাকগ্রাউন্ডে তারিখ রিভার্ট হওয়ার মূল কারণ):
    // RTDB থেকে সর্বশেষ যে raw "hijri_date" মান দেখা গিয়েছিল সেটা আলাদাভাবে মনে রাখার key।
    // আগে onDataChange()-এ raw RTDB মানকে KEY_HIJRI_FIREBASE (যেটাতে আসলে হিসাব-করা/shifted
    // মান থাকে) এর সাথে তুলনা করা হতো — এই দুটো কখনোই সমান হতো না (একটা raw, আরেকটা derived),
    // ফলে প্রতিবার ব্যাকগ্রাউন্ড প্রসেস জেগে উঠে listener re-attach হলেই (যেমন প্রতি ১৫ মিনিট
    // পরপর WorkManager/AlarmManager দিয়ে) সিস্টেম ভাবত "নতুন পরিবর্তন এসেছে", আর পুরনো
    // (stale) baseHijri থেকে পুনরায় হিসাব করে days-elapsed শিফট মুছে ফেলত — এটাই তারিখ
    // রিভার্ট হওয়ার আসল কারণ ছিল। এখন raw-এর সাথে raw তুলনা হবে, তাই প্রকৃত পরিবর্তন
    // ছাড়া আর কখনো অকারণে রিক্যালকুলেট হবে না।
    private const val KEY_LAST_RTDB_RAW_DATE = "last_rtdb_raw_date"

    fun todayDateOnlyStr(): String {
        val c = Calendar.getInstance()
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    // দুইটা "yyyy-MM-dd" তারিখের মধ্যে পূর্ণ ক্যালেন্ডার-দিনের পার্থক্য বের করা (সময়ের অংশ উপেক্ষা করে)
    fun daysBetweenDateStr(fromStr: String, toStr: String): Int {
        return try {
            fun parse(s: String): Calendar {
                val p = s.split("-")
                val c = Calendar.getInstance()
                c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt(), 0, 0, 0)
                c.set(Calendar.MILLISECOND, 0)
                return c
            }
            val from = parse(fromStr)
            val to = parse(toStr)
            val diffMs = to.timeInMillis - from.timeInMillis
            (diffMs / 86400000L).toInt().coerceAtLeast(0)
        } catch (_: Exception) { 0 }
    }

    private var isListening = false
    private var lastKnownAdjustment: Int? = null

    /**
     * UI বা অন্য কোথাও থেকে অ্যাডজাস্টমেন্ট ও সরাসরি তারিখ আপডেট পেতে এটি ব্যবহার করা যাবে।
     */
    var onConfigChanged: ((adjustment: Int, directDate: String?, overrideJson: String?) -> Unit)? = null

    private var lastDirectDate: String? = null
    private var lastOverrideJson: String? = null   // ভাষা-ভিত্তিক ওভাররাইড (JS-এর জন্য JSON), না থাকলে null

    /**
     * FCM push থেকে সরাসরি এডজাস্টমেন্ট বা তারিখ প্রয়োগ (RTDB সংযোগ ছাড়াই)।
     */
    fun applyRemoteUpdate(context: Context, adjustment: Int?, hijriDate: String?) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        if (adjustment != null) {
            lastKnownAdjustment = adjustment
            prefs.edit().putInt(KEY_LAST_ADJUSTMENT, adjustment).apply()
            onConfigChanged?.invoke(adjustment, hijriDate ?: prefs.getString(KEY_HIJRI_FIREBASE, null), lastOverrideJson)
        }
        if (!hijriDate.isNullOrBlank()) {
            prefs.edit().putBoolean(KEY_OVERRIDE_ACTIVE, true).apply()
            saveAndRefreshWidget(context, normalizeDirectDate(context, hijriDate))
        } else if (adjustment != null) {
            prefs.edit().putBoolean(KEY_OVERRIDE_ACTIVE, false).apply()
            applyAdjustmentAndRefresh(context, adjustment)
        }
    }

    /**
     * RTDB লিসেনার চালু করা।
     */
    fun startRtdbListener(context: Context) {
        if (isListening) {
            lastKnownAdjustment?.let { onConfigChanged?.invoke(it, lastDirectDate, lastOverrideJson) }
            return
        }
        isListening = true
        
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        lastKnownAdjustment = prefs.getInt(KEY_LAST_ADJUSTMENT, 0)

        val ref = FirebaseDatabase.getInstance(RTDB_URL).getReference(RTDB_CONFIG_PATH)
        ref.keepSynced(true)

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                handleSnapshot(context, prefs, snapshot)
            }

            override fun onCancelled(error: DatabaseError) {
                // v62: listener  -   30   (  )
                isListening = false
                val appCtx = context.applicationContext
                mainHandler.postDelayed({
                    try { startRtdbListener(appCtx) } catch (_: Throwable) {}
                }, 30_000L)
            }
        })
    }

    /**
     * RTDB-র prayer_config স্ন্যাপশট প্রয়োগ (লিসেনার ও সরাসরি সার্ভার-রিড দুই পথেই এটাই চলে)।
     * @return true = সত্যিই কিছু বদলেছিল ও প্রয়োগ হয়েছে; false = আগের মতোই, কিছু করা হয়নি
     */
    private fun handleSnapshot(context: Context, prefs: android.content.SharedPreferences, snapshot: DataSnapshot): Boolean {
        // ১. ওভাররাইড সুইচ (hijri_override) + ভাষা-ভিত্তিক তারিখ (bn / en / …) + পুরনো একক hijri_date
        val legacyDate = snapshot.child(KEY_DATE).getValue(String::class.java)?.trim()?.takeIf { it.isNotEmpty() }
        val flag = parseBoolFlag(snapshot.child(KEY_OVERRIDE).value)
        val langs = readLangDates(snapshot)

        // ২. অ্যাডজাস্টমেন্ট চেক করা (hijri_adjustment)
        val adjRaw = snapshot.child(KEY_ADJ).value
        val adjustment = when (adjRaw) {
            is Long -> adjRaw.toInt()
            is String -> adjRaw.toIntOrNull() ?: 0
            else -> 0
        }

        // ৩. কার্যকর ওভাররাইড: সুইচ true → bn/en তারিখ; false → অটোমেটিক; সুইচ না থাকলে → পুরনো hijri_date
        var directDate: String? = null     // উইজেট/নোটিফিকেশনের জন্য "দিন মাস বছর" (বাংলায়)
        var overrideJson: String? = null   // WebView-এর জন্য ভাষা-ভিত্তিক JSON
        when (flag) {
            true -> {
                directDate = buildDirectDateBn(context, langs)
                if (directDate != null) overrideJson = buildOverrideJson(langs)
            }
            false -> {}
            null -> directDate = legacyDate
        }

        // ✅ FIX #NEW (v3): পরিবর্তন হয়েছে কিনা চেক করা — raw RTDB মানের সাথে raw (আগে দেখা) মান
        // তুলনা হয়, derived/shifted widget-value-এর সাথে নয় (ব্যাকগ্রাউন্ডে অকারণ রিক্যালকুলেশন ও
        // তারিখ রিভার্ট ঠেকাতে)। এখন raw মান = সুইচ + পুরনো hijri_date + সব ভাষার day/month/year।
        val signature = "$flag|${legacyDate ?: ""}|$langs"
        val lastAdj = prefs.getInt(KEY_LAST_ADJUSTMENT, 0)
        val lastRawDate = prefs.getString(KEY_LAST_RTDB_RAW_DATE, null)

        if (adjustment == lastAdj && signature == lastRawDate) {
            return false // কোনো প্রকৃত পরিবর্তন নেই, তাই কিছু করার দরকার নেই
        }

        lastKnownAdjustment = adjustment
        lastDirectDate = directDate
        lastOverrideJson = overrideJson
        prefs.edit()
            .putInt(KEY_LAST_ADJUSTMENT, adjustment)
            .putBoolean(KEY_OVERRIDE_ACTIVE, !directDate.isNullOrBlank())
            .putString(KEY_LAST_RTDB_RAW_DATE, signature)
            .apply()
        onConfigChanged?.invoke(adjustment, directDate, overrideJson)

        if (!directDate.isNullOrBlank()) {
            saveAndRefreshWidget(context, normalizeDirectDate(context, directDate))
        } else {
            applyAdjustmentAndRefresh(context, adjustment)
        }
        return true
    }

    @Volatile private var lastSyncAt = 0L

    /**
     * অ্যাপ খোলা/সামনে আসার সাথে সাথে সার্ভার থেকে সর্বশেষ prayer_config একবার সরাসরি টেনে এনে প্রয়োগ করে।
     * (লিসেনার প্রথমে ক্যাশের পুরনো মান দেয় ও সার্ভারের নতুন মানের জন্য অপেক্ষা করে — তাই উইজেটে দেরি হতো।)
     * কিছু না বদলালেও উইজেট একবার নতুন করে আঁকা হয়। ১৫ সেকেন্ডের মধ্যে বারবার ডাকলে একবারই চলে।
     */
    fun syncNow(context: Context, force: Boolean = false) {
        val nowMs = System.currentTimeMillis()
        if (!force && nowMs - lastSyncAt < 15_000L) return
        lastSyncAt = nowMs
        try {
            val appCtx = context.applicationContext
            val prefs = appCtx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            FirebaseDatabase.getInstance(RTDB_URL).getReference(RTDB_CONFIG_PATH).get()
                .addOnSuccessListener { snap ->
                    try {
                        if (!handleSnapshot(appCtx, prefs, snap)) PrayerWidgetProvider.updateWidgetDirectly(appCtx)
                    } catch (_: Throwable) {}
                }
                .addOnFailureListener {
                    try { PrayerWidgetProvider.updateWidgetDirectly(appCtx) } catch (_: Throwable) {}
                }
        } catch (_: Throwable) {}
    }

    /**
     * বর্তমানে জানা অ্যাডজাস্টমেন্ট ব্যবহার করে তারিখ রিফ্রেশ করা।
     * WebView যখন নতুন সময় সেভ করে (saveTimings), তখন এটি কল করা উচিত।
     */
    fun refreshWithLastAdjustment(context: Context) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val adj = if (lastKnownAdjustment != null) {
            lastKnownAdjustment!!
        } else {
            prefs.getInt(KEY_LAST_ADJUSTMENT, 0)
        }
        applyAdjustmentAndRefresh(context, adj)
    }

    // ✅ FIX #NEW (v3): এখন baseHijri (শেষ যেবার অ্যাপ খুলে fetch করা হয়েছিল) থেকে সরাসরি
    // শুধু adjustment যোগ করা হতো না — timings_fetched_on থেকে আজ পর্যন্ত কত দিন পার
    // হয়ে গেছে (daysElapsed) সেটাও যোগ করা হচ্ছে, ঠিক যেভাবে PrayerWidgetProvider নিজে
    // হিসাব করে। এটা ছাড়া, RTDB থেকে সত্যিকারের কোনো adjustment-পরিবর্তন এলেও (অ্যাপ অনেক
    // দিন না খোলা অবস্থায়) তারিখ ভুলভাবে পুরনো/স্টেল হয়ে যেত।
    private fun applyAdjustmentAndRefresh(context: Context, adjustment: Int) {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)

        // ✅ ওভাররাইড (hijri_override / hijri_date) চালু থাকলে অটোমেটিক তারিখ দিয়ে উইজেটের তারিখ মুছে ফেলা চলবে না।
        // (আগে অ্যাপ খুললেই saveTimings → এই ফাংশন → ওভাররাইড মুছে যেত, তাই উইজেট দেরিতে/ভুল তারিখ দেখাত।)
        if (prefs.getBoolean(KEY_OVERRIDE_ACTIVE, false) && !prefs.getString(KEY_HIJRI_FIREBASE, null).isNullOrBlank()) {
            refreshWidgetsAsync(context)
            return
        }
        val jsonString = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null) ?: return

        try {
            val obj = JSONObject(jsonString)
            val baseHijri = obj.optString("hijri", "")
            if (baseHijri.isNotBlank()) {
                val today = todayDateOnlyStr()
                val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
                val daysElapsed = daysBetweenDateStr(fetchedOn, today)
                val adjustedDate = adjustHijriDate(baseHijri, adjustment + daysElapsed)
                saveAndRefreshWidget(context, adjustedDate)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * ✅ FIX #11 (তারিখ "পিছিয়ে যাওয়ার" আসল কারণ — এখানেই ছিল মূল বাগ):
     *
     * আগে এই ফাংশন শুধু দিনের সংখ্যাটার সাথে সরাসরি যোগ/বিয়োগ করত (যেমন "২৯ সফর"-এর সাথে
     * +২ করলে হয়ে যেত "৩১ সফর") — মাস কতদিনে শেষ (২৯ নাকি ৩০ দিন) সেটা মোটেও হিসাবে নিত না,
     * তাই মাস/বছর কখনো পরিবর্তন (rollover) হতো না। ফলে অ্যাপ কয়েকদিন না খোলা অবস্থায় প্রতিদিন
     * এক্সট্রাপোলেট হতে হতে দিনসংখ্যা ভুলভাবে বেড়েই যেত (যেমন "৩২ সফর", "৩৫ সফর"...)। তারপর
     * যখনই অ্যাপ খোলা হতো, অ্যাপ নতুন করে API থেকে সঠিক আরবি তারিখ (ছোট, বাস্তব দিনসংখ্যা)
     * নিয়ে আসত — আগের ভুলভাবে বড় হয়ে যাওয়া সংখ্যার তুলনায় সেটা ছোট দেখাত, যেটা ইউজারের কাছে
     * "তারিখ পিছিয়ে গেছে" বলে মনে হতো। প্রকৃতপক্ষে তারিখ পিছোয়নি — আগেরটাই ভুলভাবে বেশি এগিয়ে
     * গিয়েছিল, নতুনটা সঠিক ছিল।
     *
     * সমাধান: এখন দিন যোগ/বিয়োগ করার সময় প্রতিটা হিজরি মাস আসলে ২৯ নাকি ৩০ দিনে শেষ হয়
     * (স্ট্যান্ডার্ড Tabular Islamic Calendar নিয়ম, যেটা HijriCalendarHelper.kt-তেও ব্যবহৃত)
     * সেটা মাথায় রেখে প্রয়োজনে মাস ও বছর বদলে (rollover করে) সঠিক তারিখে পৌঁছানো হয়।
     *
     * ইনপুট ফরম্যাট: "২৬ যিলহজ ১৪৪৬" (Bengali)
     */
    fun adjustHijriDate(hijriStr: String, adjustment: Int): String {
        if (adjustment == 0) return hijriStr

        try {
            val parts = hijriStr.trim().split(" ")
            if (parts.size < 2) return hijriStr

            val dayInt = convertBengaliToEnglish(parts[0]).toIntOrNull() ?: return hijriStr
            val yearInt = convertBengaliToEnglish(parts.last()).toIntOrNull()
            val monthName = if (yearInt != null && parts.size >= 3) {
                parts.subList(1, parts.size - 1).joinToString(" ")
            } else {
                parts.subList(1, parts.size).joinToString(" ")
            }

            val monthIdx = hijriMonthNameToIndex(monthName) // 1..12
            if (monthIdx == -1 || yearInt == null) {
                // মাস/বছর বুঝতে না পারলে পুরনো (নিরাপদ ফলব্যাক) আচরণে ফিরে যাওয়া, যাতে অন্তত ক্র্যাশ না করে
                val newDayInt = dayInt + adjustment
                return "${toBengaliDigits(newDayInt)} $monthName${if (yearInt != null) " ${toBengaliDigits(yearInt)}" else ""}"
            }

            var day = dayInt
            var month = monthIdx
            var year = yearInt
            var remaining = adjustment

            while (remaining > 0) {
                val len = hijriMonthLength(month, year)
                val spaceLeftInMonth = len - day
                if (remaining <= spaceLeftInMonth) {
                    day += remaining
                    remaining = 0
                } else {
                    remaining -= spaceLeftInMonth + 1
                    day = 1
                    month += 1
                    if (month > 12) { month = 1; year += 1 }
                }
            }
            while (remaining < 0) {
                if (day + remaining >= 1) {
                    day += remaining
                    remaining = 0
                } else {
                    remaining += day
                    month -= 1
                    if (month < 1) { month = 12; year -= 1 }
                    day = hijriMonthLength(month, year)
                }
            }

            return "${toBengaliDigits(day)} ${HIJRI_MONTHS_BN[month - 1]} ${toBengaliDigits(year)}"
        } catch (e: Exception) {
            return hijriStr
        }
    }

    /** স্ট্যান্ডার্ড ৩০-বছরের Tabular Islamic Calendar চক্র অনুযায়ী অধিবর্ষ (leap year) কিনা */
    private fun isHijriLeapYear(year: Int): Boolean = (11 * year + 14) % 30 < 11

    /** হিজরি মাসের দৈর্ঘ্য (দিন সংখ্যা): বিজোড় মাস ৩০ দিনে, জোড় মাস ২৯ দিনে — শেষ মাস (১২তম) অধিবর্ষে ৩০ দিনে */
    private fun hijriMonthLength(month: Int, year: Int): Int = when {
        month == 12 && isHijriLeapYear(year) -> 30
        month % 2 == 1 -> 30
        else -> 29
    }

    /** মাসের বাংলা নাম থেকে ইনডেক্স (১=মুহাররম...১২=জিলহজ) বের করা, বানান-ভিন্নতা হ্যান্ডেল সহ */
    private fun hijriMonthNameToIndex(monthName: String): Int {
        for (i in HIJRI_MONTHS_BN.indices) {
            if (monthName.contains(HIJRI_MONTHS_BN[i]) || HIJRI_MONTHS_BN[i].contains(monthName)) return i + 1
        }
        // পুরনো/ভিন্ন বানান (যেমন মুহাররম, জুমাদাল উলা) ও ইংরেজি নামও চিনবে
        val anyIdx = hijriMonthIndexFromAnyName(monthName)
        if (anyIdx >= 0) return anyIdx + 1
        if (monthName.contains("জিলহজ") || monthName.contains("যিলহজ")) return 12
        return -1
    }

    private fun toBengaliDigits(n: Int): String {
        val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        var out = ""
        for (char in n.toString()) {
            val d = char.toString().toIntOrNull()
            out += if (d != null) bengaliDigits[d] else char
        }
        return out
    }

    /**
     * বাংলা সংখ্যাকে ইংরেজি সংখ্যায় রূপান্তর (অভ্যন্তরীণ ব্যবহারের জন্য)
     */
    fun convertBengaliToEnglish(input: String): String {
        val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        var output = ""
        for (char in input) {
            val index = bengaliDigits.indexOf(char)
            output += if (index != -1) index.toString() else char
        }
        return output
    }

    /**
     * ✅ FIX #NEW (v6, প্রয়োজনীয়তা #৪): ইংরেজি সংখ্যাকে বাংলা সংখ্যায় রূপান্তর — উইজেটে সব
     * জায়গায় (নামাজের সময়, সাহরী/ইফতার, আবহাওয়া, সূর্যোদয়/সূর্যাস্ত, ইংরেজি/বাংলা ক্যালেন্ডার
     * লাইন, হিজরি তারিখ) এখন বাংলা সংখ্যা দেখানোর জন্য এটাই মূল হেল্পার। শুধুমাত্র '0'-'9'
     * (ASCII) ক্যারেক্টার বদলায়, বাকি সব ক্যারেক্টার (":", "°C", স্পেস, বাংলা অক্ষর, এমনকি
     * ইতোমধ্যে বাংলা সংখ্যা থাকলেও) অপরিবর্তিত থাকে — তাই এটা যেকোনো মিশ্র-ফরম্যাট ইনপুটেও
     * (যেমন হিজরি স্ট্রিং কখনো ইংরেজি, কখনো বাংলা সংখ্যায় আসতে পারে) নিরাপদে বারবার কল করা যায়।
     */
    fun convertEnglishToBengali(input: String): String {
        val bengaliDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val sb = StringBuilder(input.length)
        for (char in input) {
            if (char in '0'..'9') sb.append(bengaliDigits[char - '0']) else sb.append(char)
        }
        return sb.toString()
    }

    /**
     * তারিখ SharedPrefs-এ সেভ করে উইজেট রিফ্রেশ করা।
     */
    private val HIJRI_MONTHS_BN = listOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল উলা", "জমাদিউস সানি",
        "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
    )

    /**
     * ✅ অ্যাপ ও উইজেটের তারিখ এক রাখা: ফায়ারবেসে হিজরি ওভাররাইড চালু থাকলে অ্যাপ সেই তারিখ হুবহু (কোনো দিন-এগোনো বা
     * মাগরিব-শিফট ছাড়া) দেখায় — উইজেট/নোটিফিকেশনও ঠিক সেটাই ব্যবহার করে। ওভাররাইড না থাকলে null (তখন অটোমেটিক হিসাব)।
     */
    fun overrideHijriOrNull(prefs: android.content.SharedPreferences): String? {
        if (!prefs.getBoolean(KEY_OVERRIDE_ACTIVE, false)) return null
        return prefs.getString(KEY_HIJRI_FIREBASE, null)?.takeIf { it.isNotBlank() }
    }

    /**
     * ✅ FIX #6: নোটিফিকেশন সিস্টেম যেন Aladhan API-এর তারিখ না দেখে, বরং উইজেটে যে সঠিক
     * (Firebase-এডজাস্ট করা) আরবি তারিখ দেখানো হচ্ছে ঠিক সেই তারিখ অনুযায়ী চলে — এই ফাংশনটা
     * PrayerWidgetProvider-এর মতোই একই লজিক দিয়ে "আজকের প্রকৃত আরবি (দিন, মাস)" বের করে।
     * @return Pair(day, month) — month হলো 1..12 (1=মুহাররম)। বের করতে না পারলে null।
     */
    fun getCorrectedTodayHijriDayMonth(context: Context): Pair<Int, Int>? =
        getCorrectedHijriForToday(context, afterMaghrib = null)

    /**
     * ✅ v43: আজকের গ্রেগরিয়ান দিনের জন্য আরবি তারিখ — মাগরিব পার হয়েছে কিনা তা বাইরে থেকে ঠিক করে দেওয়া যায়।
     *   afterMaghrib = false → আজকের দিনের বেলার আরবি তারিখ (সূর্যাস্তের আগ পর্যন্ত যা চলে)
     *   afterMaghrib = true  → আজ সূর্যাস্তের পর যে রাত শুরু হবে সেই রাতের আরবি তারিখ
     *   afterMaghrib = null  → এই মুহূর্তের ঘড়ি দেখে নিজে ঠিক করবে (আগের আচরণ হুবহু)
     * এর ফলে সকালবেলাতেই "আজ রাতের তারিখ কত" জানা যায়, তাই রাতের নোটিফিকেশন আগে থেকে শিডিউল করা যায়।
     */
    fun getCorrectedHijriForToday(context: Context, afterMaghrib: Boolean?): Pair<Int, Int>? {
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val timingsJson = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)
        var maghrib = ""
        var baseHijri = "-- --- ----"
        if (timingsJson != null) {
            try {
                val obj = JSONObject(timingsJson)
                maghrib = obj.optString("maghrib", "")
                baseHijri = obj.optString("hijri", "-- --- ----")
            } catch (_: Exception) {}
        }

        val hijriFirebase = prefs.getString(KEY_HIJRI_FIREBASE, null)
        val adjustment = prefs.getInt(KEY_LAST_ADJUSTMENT, 0)
        val today = todayDateOnlyStr()

        val overrideDate = overrideHijriOrNull(prefs)
        var dateToShift = if (overrideDate != null) {
            overrideDate
        } else if (!hijriFirebase.isNullOrBlank()) {
            val setOn = prefs.getString(KEY_HIJRI_FIREBASE_SET_ON, today) ?: today
            adjustHijriDate(hijriFirebase, daysBetweenDateStr(setOn, today))
        } else if (baseHijri != "-- --- ----") {
            val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
            adjustHijriDate(baseHijri, adjustment + daysBetweenDateStr(fetchedOn, today))
        } else {
            baseHijri
        }

        if (dateToShift == "-- --- ----") return null

        if (afterMaghrib == true) {
            dateToShift = adjustHijriDate(dateToShift, 1)
        } else if (afterMaghrib == null && maghrib.isNotBlank() && overrideDate == null) {   // ওভাররাইডে মাগরিব-শিফট নেই (অ্যাপের মতো)
            try {
                val p = maghrib.trim().split(" ")[0].split(":")
                val mMin = p[0].toInt() * 60 + p[1].toInt()
                val c = Calendar.getInstance()
                val nowMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
                if (nowMin >= mMin) dateToShift = adjustHijriDate(dateToShift, 1)
            } catch (_: Exception) {}
        }

        return try {
            val parts = dateToShift.trim().split(" ")
            if (parts.size < 2) return null
            val day = convertBengaliToEnglish(parts[0]).toIntOrNull() ?: return null
            val monthName = parts[1]
            var monthIdx = -1
            for (i in HIJRI_MONTHS_BN.indices) {
                if (monthName.contains(HIJRI_MONTHS_BN[i]) || HIJRI_MONTHS_BN[i].contains(monthName)) { monthIdx = i + 1; break }
            }
            if (monthIdx == -1) { val a = hijriMonthIndexFromAnyName(monthName); if (a >= 0) monthIdx = a + 1 }
            // "জিলহজ" বানানের ভিন্নতা (যিলহজ/জিলহজ) হ্যান্ডেল করা
            if (monthIdx == -1 && (monthName.contains("জিলহজ") || monthName.contains("যিলহজ"))) monthIdx = 12
            if (monthIdx == -1) null else Pair(day, monthIdx)
        } catch (_: Exception) { null }
    }

    /**
     * ভবিষ্যতের কোনো নির্দিষ্ট দিনের (আজ থেকে dayOffset দিন পরের) কারেক্টেড হিজরি (day, month)
     * বের করে — একই লজিক ব্যবহার করে যা getCorrectedTodayHijriDayMonth ব্যবহার করে, শুধু
     * টার্গেট গ্রেগরিয়ান তারিখ ও "মাগরিব পার হয়ে গেছে" (পূর্ণাঙ্গ ইসলামিক দিন) ধরে নেওয়া হয়।
     * আইয়ামে বিয-এর "মাসের শেষ ৩ দিন" নির্ণয়ে ব্যবহৃত হয়।
     */
    fun getCorrectedHijriDayMonthForOffset(context: Context, dayOffset: Int): Pair<Int, Int>? {
        if (dayOffset == 0) return getCorrectedTodayHijriDayMonth(context)
        val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val timingsJson = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)
        var baseHijri = "-- --- ----"
        if (timingsJson != null) {
            try {
                val obj = JSONObject(timingsJson)
                baseHijri = obj.optString("hijri", "-- --- ----")
            } catch (_: Exception) {}
        }

        val hijriFirebase = prefs.getString(KEY_HIJRI_FIREBASE, null)
        val adjustment = prefs.getInt(KEY_LAST_ADJUSTMENT, 0)
        val today = todayDateOnlyStr()
        val targetDateStr = shiftDateStr(today, dayOffset)

        val overrideDate = overrideHijriOrNull(prefs)
        var dateToShift = if (overrideDate != null) {
            adjustHijriDate(overrideDate, dayOffset)   // ওভাররাইড = আজকের তারিখ; ভবিষ্যৎ দিন = আজ + অফসেট
        } else if (!hijriFirebase.isNullOrBlank()) {
            val setOn = prefs.getString(KEY_HIJRI_FIREBASE_SET_ON, today) ?: today
            adjustHijriDate(hijriFirebase, daysBetweenDateStr(setOn, targetDateStr))
        } else if (baseHijri != "-- --- ----") {
            val fetchedOn = prefs.getString("timings_fetched_on", today) ?: today
            adjustHijriDate(baseHijri, adjustment + daysBetweenDateStr(fetchedOn, targetDateStr))
        } else {
            baseHijri
        }
        // ভবিষ্যতের তারিখ সবসময় "মাগরিব পার হয়ে যাওয়া" পূর্ণাঙ্গ ইসলামিক দিন হিসেবে ধরা হচ্ছে
        dateToShift = adjustHijriDate(dateToShift, 1)

        if (dateToShift == "-- --- ----") return null
        return try {
            val parts = dateToShift.trim().split(" ")
            if (parts.size < 2) return null
            val day = convertBengaliToEnglish(parts[0]).toIntOrNull() ?: return null
            val monthName = parts[1]
            var monthIdx = -1
            for (i in HIJRI_MONTHS_BN.indices) {
                if (monthName.contains(HIJRI_MONTHS_BN[i]) || HIJRI_MONTHS_BN[i].contains(monthName)) { monthIdx = i + 1; break }
            }
            if (monthIdx == -1) { val a = hijriMonthIndexFromAnyName(monthName); if (a >= 0) monthIdx = a + 1 }
            if (monthIdx == -1 && (monthName.contains("জিলহজ") || monthName.contains("যিলহজ"))) monthIdx = 12
            if (monthIdx == -1) null else Pair(day, monthIdx)
        } catch (_: Exception) { null }
    }

    private fun shiftDateStr(dateStr: String, days: Int): String {
        val p = dateStr.split("-")
        val c = Calendar.getInstance()
        c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt(), 0, 0, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, days)
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /**
     * আজকের দিনটি চলতি হিজরি মাসের শেষ তিন দিনের মধ্যে কিনা যাচাই করে (আইয়ামে বিয-এর
     * তৃতীয় সেট — ২৭/২৮/২৯ বা ২৮/২৯/৩০ — নির্ণয়ের জন্য)। চন্দ্র মাস ২৯ বা ৩০ দিনের হতে
     * পারে এবং তা আগে থেকে নিশ্চিতভাবে জানা যায় না, তাই সামনের কয়েক দিনের কারেক্টেড
     * হিজরি মাস চেক করে মাস কবে বদলাচ্ছে তা বের করে নেওয়া হয়।
     */
    fun isWithinLastThreeDaysOfHijriMonth(context: Context): Boolean {
        val today = getCorrectedTodayHijriDayMonth(context) ?: return false
        val (todayDay, todayMonth) = today
        if (todayDay < 26) return false // অপ্রয়োজনীয় হিসাব এড়াতে দ্রুত বাদ
        for (offset in 1..4) {
            val future = getCorrectedHijriDayMonthForOffset(context, offset) ?: return false
            if (future.second != todayMonth) {
                val daysRemainingInCurrentMonth = offset - 1
                return daysRemainingInCurrentMonth in 0..2
            }
        }
        return false
    }

    private fun parseBoolFlag(v: Any?): Boolean? = when (v) {
        is Boolean -> v
        is Long -> v != 0L
        is Double -> v != 0.0
        is String -> when (v.trim().lowercase(Locale.ROOT)) {
            "true", "on", "yes", "1" -> true
            "false", "off", "no", "0" -> false
            else -> null
        }
        else -> null
    }

    /** prayer_config-এর ভাষা-ভিত্তিক ঘরগুলো (bn, en, ar…: যেগুলোতে day/month আছে) → ভাষা → {day, month, year} */
    private fun readLangDates(snapshot: DataSnapshot): Map<String, Map<String, String>> {
        val out = LinkedHashMap<String, Map<String, String>>()
        for (child in snapshot.children) {
            val key = child.key ?: continue
            if (!child.hasChildren()) continue
            val day = child.child("day").value?.toString()?.trim().orEmpty()
            val month = child.child("month").value?.toString()?.trim().orEmpty()
            val year = child.child("year").value?.toString()?.trim().orEmpty()
            if (day.isEmpty() && month.isEmpty()) continue
            out[key] = mapOf("day" to day, "month" to month, "year" to year)
        }
        return out
    }

    /** ভাষা-ভিত্তিক তারিখ → উইজেট/নোটিফিকেশনের জন্য "দিন মাস বছর" (বাংলা সংখ্যা); দিন/মাস বোঝা না গেলে null (= অটোমেটিক) */
    private fun buildDirectDateBn(context: Context, langs: Map<String, Map<String, String>>): String? {
        val order = listOf("bn", "en") + langs.keys.filter { it != "bn" && it != "en" }
        var dayStr = ""
        var monthIdx = -1
        var yearStr = ""
        for (k in order) {
            val m = langs[k] ?: continue
            if (dayStr.isEmpty()) dayStr = m["day"].orEmpty()
            if (monthIdx == -1) monthIdx = hijriMonthIndexFromAnyName(m["month"].orEmpty())
            if (yearStr.isEmpty()) {
                val y = convertBengaliToEnglish(m["year"].orEmpty()).trim()
                if (y.length in 3..4 && y.all { it.isDigit() }) yearStr = y
            }
        }
        val day = convertBengaliToEnglish(dayStr).filter { it.isDigit() }.toIntOrNull() ?: return null
        if (day !in 1..30 || monthIdx == -1) return null
        val year = yearStr.toIntOrNull() ?: deriveHijriYear(context, monthIdx) ?: return null
        // মাসের নাম সবসময় নির্ধারিত বানানে (HIJRI_MONTHS_BN) দেখানো হয়, ইউজার যে বানানেই লিখুক
        val monthText = HIJRI_MONTHS_BN[monthIdx]
        return "${toBengaliDigits(day)} $monthText ${toBengaliDigits(year)}"
    }

    /** WebView (JS)-এর জন্য: {"on":true,"bn":{"day":..,"month":..,"year":..},"en":{...}} */
    private fun buildOverrideJson(langs: Map<String, Map<String, String>>): String {
        val o = JSONObject()
        o.put("on", true)
        for ((k, m) in langs) {
            val j = JSONObject()
            for ((f, v) in m) if (v.isNotEmpty()) j.put(f, v)
            o.put(k, j)
        }
        return o.toString()
    }

    /**
     * Firebase-এর hijri_date বাংলা বা ইংরেজি সংখ্যা ও মাসের নামে, বছর ছাড়াও লেখা যায়
     * (যেমন "৩০ রবিউস সানি", "30 Rabi al-Thani", "৩০ রবিউস সানি ১৪৪৮")।
     * এটাকে সবসময় "দিন মাস বছর" (বাংলা সংখ্যা ও বাংলা মাস) ফরম্যাটে এনে দেয়, যাতে উইজেট ও নোটিফিকেশন
     * (যেগুলো এই স্ট্রিং থেকে মাস/বছর বের করে) ঠিকঠাক চলে। বোঝা না গেলে মূল লেখাটাই ফেরত দেয় (আগের আচরণ)।
     */
    fun normalizeDirectDate(context: Context, raw: String): String {
        return try {
            val parts = convertBengaliToEnglish(raw).trim().replace(",", " ").split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (parts.size < 2) return raw
            val day = parts[0].toIntOrNull() ?: return raw
            if (day !in 1..30) return raw
            var yearGiven: Int? = null
            var monthParts = parts.subList(1, parts.size)
            val last = parts.last()
            if (parts.size >= 3 && last.length in 3..4 && last.all { it.isDigit() }) {
                yearGiven = last.toInt()
                monthParts = parts.subList(1, parts.size - 1)
            }
            val monthIdx = hijriMonthIndexFromAnyName(monthParts.joinToString(" "))
            if (monthIdx == -1) return raw
            val year: Int = yearGiven ?: deriveHijriYear(context, monthIdx) ?: return raw
            "${toBengaliDigits(day)} ${HIJRI_MONTHS_BN[monthIdx]} ${toBengaliDigits(year)}"
        } catch (_: Exception) { raw }
    }

    /** মাসের নাম (বাংলা/ইংরেজি, বানান-ভিন্নতাসহ) থেকে ০–১১ ইনডেক্স; চিনতে না পারলে -১ (JS-এর hijriMonthIndexFromName-এর হুবহু সমতুল্য) */
    private fun hijriMonthIndexFromAnyName(name: String): Int {
        val c = name.lowercase(Locale.ROOT).replace(Regex("[’'‘`ʼʿʾ\\-_.,\\s]"), "")
        if (c.isEmpty()) return -1
        val second = Regex("thani|thaani|sani|akhir|akher|আখ[িে]র|আখেরা|সানি|সানী|দ্বিতীয়|ii\$|2\$")
        return when {
            Regex("q[ai]d|kad|কদ|ক্বদ").containsMatchIn(c) -> 10
            Regex("hij|haj|হজ").containsMatchIn(c) -> 11
            Regex("muharr?am|moharr?am|মুহা?র+ম|মহর+ম").containsMatchIn(c) -> 0
            Regex("safar|sofar|সফর|ছফর").containsMatchIn(c) -> 1
            Regex("rabi|রবি").containsMatchIn(c) -> if (second.containsMatchIn(c)) 3 else 2
            Regex("jum?ad|jamad|জুমা|জামাদ|জমাদ").containsMatchIn(c) -> if (second.containsMatchIn(c)) 5 else 4
            Regex("rajab|রজব").containsMatchIn(c) -> 6
            Regex("sha+ban|শা?বান").containsMatchIn(c) -> 7
            Regex("ramad|ramz|ramaz|রমজান|রমযান|রামাদান").containsMatchIn(c) -> 8
            Regex("shaw+al|শাওয়াল|শাউয়াল|শওয়াল").containsMatchIn(c) -> 9
            else -> -1
        }
    }

    /** বছর না দেওয়া থাকলে অ্যাপের নিজস্ব হিসাব (সর্বশেষ সেভ হওয়া timings, না থাকলে টেবুলার ক্যালেন্ডার) থেকে বছর নেওয়া — বছরের সীমানা মিলিয়ে */
    private fun deriveHijriYear(context: Context, monthIdx: Int): Int? {
        return try {
            val prefs = context.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            var baseYear = 0
            var baseMonth0 = -1
            val timingsJson = prefs.getString(PrayerWidgetProvider.KEY_TIMINGS, null)
            if (timingsJson != null) {
                val h = JSONObject(timingsJson).optString("hijri", "")
                val p = convertBengaliToEnglish(h).trim().split(Regex("\\s+"))
                val y = p.lastOrNull()?.toIntOrNull()
                if (p.size >= 3 && y != null && y > 1000) {
                    baseYear = y
                    baseMonth0 = hijriMonthNameToIndex(p.subList(1, p.size - 1).joinToString(" ")) - 1
                }
            }
            if (baseYear == 0) {
                val t = HijriCalendarHelper.getTodayHijri(false, 0)
                baseYear = t.year
                baseMonth0 = t.month - 1
            }
            when {
                monthIdx == 0 && baseMonth0 == 11 -> baseYear + 1
                monthIdx == 11 && baseMonth0 == 0 -> baseYear - 1
                else -> baseYear
            }
        } catch (_: Exception) { null }
    }


    fun saveAndRefreshWidget(context: Context, hijriDate: String) {
        val prefs = context.getSharedPreferences(
            PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)

        // ✅ FIX #1: এই মুহূর্তের গ্রেগরিয়ান তারিখটাও সেভ করে রাখা হচ্ছে, যাতে পরের দিনগুলোতে
        // ঠিক কত দিন এগিয়েছে হিসাব করে দিন-ভিত্তিক শিফট করা যায় (শুধু সময়-ভিত্তিক তুলনা নয়)
        prefs.edit()
            .putString(KEY_HIJRI_FIREBASE, hijriDate)
            .putString(KEY_HIJRI_FIREBASE_SET_ON, todayDateOnlyStr())
            .apply()
        refreshWidgetsAsync(context)
    }

    /** v62: widget  -      (UI thread   ) */
    fun refreshWidgetsAsync(context: Context) {
        val appCtx = context.applicationContext
        widgetExecutor.execute {
            try {
                PrayerWidgetProvider.updateWidgetDirectly(appCtx)
                PrayerWidgetProvider.updateAllWidgets(appCtx)
            } catch (_: Throwable) {}
            // v63: Hijri      
            try {
                com.gunjoron.patheyo.notification.ScheduledNotificationScheduler.scheduleAllNotifications(appCtx)
            } catch (_: Throwable) {}
        }
    }

    /**
     * v62: Background thread-  RTDB  prayer_config  -  
     * (WidgetUpdateWorker / RtdbSyncWorker  ).  -    widget   .
     */
    fun fetchBlocking(context: Context) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val snap = Tasks.await(
            FirebaseDatabase.getInstance(RTDB_URL).getReference(RTDB_CONFIG_PATH).get(),
            20, TimeUnit.SECONDS
        )
        if (!handleSnapshot(appCtx, prefs, snap)) refreshWidgetsAsync(appCtx)
    }
}
