package com.gunjoron.patheyo.ui

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ScrollView
import com.gunjoron.patheyo.R

/**
 * v36: আপডেট ও লোকেশন — দুই পপআপেরই একই গ্লাস-ডিজাইন এক জায়গা থেকে।
 *  • Android 12+ (ব্লার সাপোর্টেড): আসল window-blur
 *  • পুরনো ফোন / ব্লার বন্ধ: ঝাপসা স্ক্রিন-ব্যাকগ্রাউন্ড (GlassBackground)
 * ব্যবহার: dialog তৈরির পর prepare() → dialog.show() → present()
 */
object GlassStyle {

    private const val CORNER_DP = 28
    private const val MAX_WIDTH_DP = 360
    private const val SIDE_MARGIN_DP = 24

    class Prepared internal constructor(internal val snapshot: Bitmap?)

    /** ফোনে অ্যাপের যে নাম আছে (Settings-এ যা দেখায়) */
    fun appLabel(activity: Activity): String = try {
        activity.applicationInfo.loadLabel(activity.packageManager).toString()
    } catch (_: Exception) { activity.getString(R.string.app_name) }

    /**
     * নোট এলাকা সর্বোচ্চ [maxDp] উঁচু — কিন্তু ছোট স্ক্রিনে স্ক্রিনের [maxScreenFraction] অংশের বেশি নয়।
     * লেখা এর চেয়ে বড় হলে স্ক্রল হবে (নিচে ফেড-আউট সহ)।
     */
    fun limitHeight(scroll: ScrollView, maxDp: Int, maxScreenFraction: Float = 0.40f) {
        // v47: সাজসজ্জার কোনো ধাপ ব্যর্থ হলেও যেন অ্যাপ ক্র্যাশ না করে
        try {
            val dm = scroll.resources.displayMetrics
            val maxPx = minOf((maxDp * dm.density).toInt(), (dm.heightPixels * maxScreenFraction).toInt())
            scroll.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    try {
                        if (scroll.viewTreeObserver.isAlive) scroll.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        if (scroll.height > maxPx) scroll.layoutParams = scroll.layoutParams.apply { height = maxPx }
                    } catch (_: Throwable) { }
                }
            })
        } catch (_: Throwable) { }
    }

    /** dialog.show()-এর আগে */
    fun prepare(activity: Activity, dialog: Dialog): Prepared {
        val w = dialog.window ?: return Prepared(null)
        var blur = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blur = try { activity.windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
        }
        // v47: প্রতিটা ধাপ আলাদাভাবে সুরক্ষিত — কোনো ফোনে (OEM) ব্লার/ব্যাকগ্রাউন্ড সেট ব্যর্থ হলেও পপআপ ক্র্যাশ করবে না
        try {
            w.setBackgroundDrawableResource(if (blur) R.drawable.bg_update_dialog else R.drawable.bg_update_dialog_solid)
            w.setDimAmount(if (blur) 0.30f else 0.50f)
        } catch (_: Throwable) { }
        if (blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                w.attributes = w.attributes.apply { blurBehindRadius = 20 }
                w.setBackgroundBlurRadius(50)
            } catch (_: Throwable) {
                // ব্লার চালু করা গেল না → সলিড গ্লাসে ফিরে যাওয়া
                blur = false
                try { w.setBackgroundDrawableResource(R.drawable.bg_update_dialog_solid); w.setDimAmount(0.50f) } catch (_: Throwable) { }
            }
        }
        return Prepared(if (blur) null else GlassBackground.captureFrosted(activity))
    }

    /** dialog.show()-এর পরে: সাইজ, ফন্ট, এন্ট্রি অ্যানিমেশন, (দরকারে) ঝাপসা ব্যাকগ্রাউন্ড */
    fun present(activity: Activity, dialog: Dialog, view: View, prepared: Prepared) {
        // v47: dialog.show() হয়ে যাওয়ার পর এখানকার কোনো ধাপ ব্যর্থ হলে পপআপ যেমন আছে তেমনই (সম্পূর্ণ দৃশ্যমান) থাকবে —
        // অ্যাপ কখনো ক্র্যাশ করবে না এবং পপআপ অদৃশ্যও হয়ে যাবে না।
        try {
            val dm = activity.resources.displayMetrics
            val width = minOf(dm.widthPixels - (SIDE_MARGIN_DP * 2 * dm.density).toInt(), (MAX_WIDTH_DP * dm.density).toInt())
            dialog.window?.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        } catch (_: Throwable) { }

        try { DialogText.applyFonts(activity, view) } catch (_: Throwable) { }

        try {
            view.alpha = 0f; view.scaleX = 0.96f; view.scaleY = 0.96f
            view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(DecelerateInterpolator(1.5f)).start()
        } catch (_: Throwable) {
            view.alpha = 1f; view.scaleX = 1f; view.scaleY = 1f
        }

        try { prepared.snapshot?.let { installFrosted(activity, dialog, it) } } catch (_: Throwable) { }
    }

    private fun installFrosted(activity: Activity, dialog: Dialog, snap: Bitmap) {
        val card = dialog.window?.decorView ?: return
        card.post {
            try {
                val screen = activity.window.decorView
                if (screen.width <= 0 || card.width <= 0) return@post
                val a = IntArray(2); val b = IntArray(2)
                card.getLocationOnScreen(a); screen.getLocationOnScreen(b)
                val sx = snap.width.toFloat() / screen.width
                val sy = snap.height.toFloat() / screen.height
                val l = ((a[0] - b[0]) * sx).toInt().coerceIn(0, snap.width - 1)
                val t = ((a[1] - b[1]) * sy).toInt().coerceIn(0, snap.height - 1)
                val r = (l + card.width * sx).toInt().coerceIn(l + 1, snap.width)
                val bt = (t + card.height * sy).toInt().coerceIn(t + 1, snap.height)
                dialog.window?.setBackgroundDrawable(
                    GlassBackground.GlassDrawable(
                        snap, Rect(l, t, r, bt), CORNER_DP * activity.resources.displayMetrics.density,
                        activity.getColor(R.color.update_glass_frost_top),
                        activity.getColor(R.color.update_glass_frost_bottom),
                        activity.getColor(R.color.update_glass_stroke),
                        activity.resources.displayMetrics.density
                    )
                )
            } catch (_: Throwable) { /* ব্যর্থ হলে সলিড গ্লাস-ই থাকবে */ }
        }
    }
}
