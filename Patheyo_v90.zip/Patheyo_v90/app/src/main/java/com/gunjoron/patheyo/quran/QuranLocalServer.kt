package com.gunjoron.patheyo.quran

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * ডাউনলোড করা কুরআন ফাইল WebView-কে একটা নকল ঠিকানায় দেখায়: https://quran-local.invalid/<ফাইল>
 * (JS এখান থেকে XHR দিয়ে সরাসরি বাইট পড়ে; কাজ না করলে readChunk ব্রিজ ফলব্যাক)।
 * file:// পেজ থেকে ক্রস-অরিজিন তাই Access-Control-Allow-Origin দেওয়া হয়।
 */
object QuranLocalServer {
    const val HOST = "quran-local.invalid"
    const val DIR_NAME = "quran"

    private val HEADERS = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Access-Control-Allow-Methods" to "GET, OPTIONS",
        "Access-Control-Allow-Headers" to "*",
        "Cache-Control" to "no-store"
    )

    fun intercept(context: Context, request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url ?: return null
        if (!HOST.equals(uri.host, ignoreCase = true)) return null
        val name = uri.lastPathSegment ?: return null
        val mime = when (name) {
            "Hafezi-Quran.pdf" -> "application/pdf"
            "Quran-Tarjama.json" -> "application/json"
            else -> return empty(404, "Not Found", "text/plain")
        }
        if ("OPTIONS".equals(request.method, ignoreCase = true)) return empty(200, "OK", mime)
        val f = File(File(context.filesDir, DIR_NAME), name)
        if (!f.exists() || f.length() <= 0L) return empty(404, "Not Found", mime)
        val enc = if (mime == "application/json") "utf-8" else null
        return WebResourceResponse(mime, enc, 200, "OK", HEADERS, FileInputStream(f))
    }

    private fun empty(code: Int, reason: String, mime: String) =
        WebResourceResponse(mime, "utf-8", code, reason, HEADERS, ByteArrayInputStream(ByteArray(0)))
}
