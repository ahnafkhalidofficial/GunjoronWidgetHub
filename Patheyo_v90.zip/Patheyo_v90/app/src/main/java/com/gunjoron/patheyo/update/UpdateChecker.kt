package com.gunjoron.patheyo.update

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object UpdateChecker {

    // আগের লিংক (যেমন ছিল তেমনই) — যদি আপনার রিপোতে এই ফাইল থাকে, সেটাও কাজ করবে।
    private const val UPDATE_JSON_URL =
        "https://patheyobygunjoron.github.io/docs/update.json"

    // v49: নতুন লিংক — GitHub Action নতুন রিলিজ দিলে নিজে থেকে এই ফাইল বানায় (ওয়েবসাইটের ফোল্ডারে)।
    private const val SITE_UPDATE_JSON_URL =
        "https://patheyobygunjoron.github.io/patheyo/data/update.json"

    private val SOURCES = listOf(UPDATE_JSON_URL, SITE_UPDATE_JSON_URL)

    /** বর্তমানে ইনস্টল থাকা অ্যাপের versionCode */
    fun installedVersionCode(ctx: Context): Long {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        return PackageInfoCompat.getLongVersionCode(pi)
    }

    /** ইনস্টল থাকা অ্যাপের versionName (যেমন 1.6.0) */
    fun installedVersionName(ctx: Context): String =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }

    /** নতুন ভার্সন থাকলে UpdateInfo, না থাকলে (বা ইন্টারনেট সমস্যা হলে) null */
    suspend fun checkForUpdate(ctx: Context): UpdateInfo? {
        val info = fetchLatest(ctx) ?: return null
        return if (isNewer(ctx, info)) info else null
    }

    /**
     * সব সূত্র (দুটি ফাইল + পুশে পাওয়া তথ্য) থেকে সবচেয়ে নতুন ভার্সনটি। কিছুই না পেলে null।
     * (নতুন কি না সেটা এখানে দেখা হয় না — দেখতে [isNewer] ব্যবহার করুন)
     */
    suspend fun fetchLatest(ctx: Context): UpdateInfo? {
        var best: UpdateInfo? = UpdatePrefs.getPushed(ctx)
        for (u in SOURCES) {
            val c = fetch(u) ?: continue
            if (best == null || compare(c, best) > 0) best = c
        }
        return best
    }

    /** [info] ইনস্টল করা অ্যাপের চেয়ে নতুন কি না */
    fun isNewer(ctx: Context, info: UpdateInfo): Boolean =
        if (info.codeKnown) info.versionCode > installedVersionCode(ctx)
        else semverCompare(info.versionName, installedVersionName(ctx)) > 0

    private fun compare(a: UpdateInfo, b: UpdateInfo): Int =
        if (a.codeKnown && b.codeKnown && a.versionCode != b.versionCode)
            a.versionCode.compareTo(b.versionCode)
        else semverCompare(a.versionName, b.versionName)

    /** "v1.6.0" / "1.10.2" ধরনের নাম তুলনা: ধনাত্মক = a নতুন */
    fun semverCompare(a: String, b: String): Int {
        fun parts(s: String) = Regex("\\d+").findAll(s).map { it.value.toLongOrNull() ?: 0L }.toList()
        val x = parts(a)
        val y = parts(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrElse(i) { 0L }).compareTo(y.getOrElse(i) { 0L })
            if (d != 0) return d
        }
        return 0
    }

    /** versionName থেকে প্রম্পট-হিসাবের জন্য একটি সংখ্যা (যেমন 1.6.0 → 10600) */
    private fun nameKey(name: String): Long {
        val p = Regex("\\d+").findAll(name).map { it.value.toLongOrNull() ?: 0L }.toList()
        return p.getOrElse(0) { 0L } * 10000 + p.getOrElse(1) { 0L } * 100 + p.getOrElse(2) { 0L }
    }

    /** FCM পুশ বা অন্য সূত্র থেকে নামসহ UpdateInfo বানাতে (আসল versionCode না থাকলে) */
    fun infoFromName(name: String, apkUrl: String, notes: String, sizeMb: Int, mandatory: Boolean): UpdateInfo =
        UpdateInfo(nameKey(name), name, apkUrl, notes, sizeMb, mandatory, codeKnown = false)

    private suspend fun fetch(url: String): UpdateInfo? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            // ?t=... দিয়ে ক্যাশ এড়ানো হচ্ছে
            conn = (URL("$url?t=${System.currentTimeMillis()}")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
                useCaches = false
                setRequestProperty("Cache-Control", "no-cache")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
            parse(conn.inputStream.bufferedReader().use { it.readText() })
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun parse(json: String): UpdateInfo? = try {
        val o = JSONObject(json)
        val notes = when (val n = o.opt("release_notes")) {
            is JSONArray -> (0 until n.length()).joinToString("\n") { "•  " + n.getString(it) }
            is String -> n
            else -> ""
        }
        val name = o.getString("versionName")
        val apk = o.getString("apk_url")
        val code = o.optLong("versionCode", 0L)
        if (code > 0L) {
            UpdateInfo(code, name, apk, notes, o.optInt("size_mb", 0), o.optBoolean("mandatory", false))
        } else {
            infoFromName(name, apk, notes, o.optInt("size_mb", 0), o.optBoolean("mandatory", false))
        }
    } catch (e: Exception) {
        null
    }
}
