package com.gunjoron.patheyo.alarm

// app/src/main/java/com/gunjoron/Patheyo/alarm/BootCompletedReceiver.kt
//
// ফিক্স করা সমস্যা:
//  - #1/#5: ফোন reboot দিলে AlarmManager-এর সব alarm মুছে যায়।
//           আগে শুধু azan alarm reschedule হত, widget alarm হত না।
//           এখন widget refresh alarm-ও reschedule হবে।
//           ফলে reboot-এর পরেও widget auto-update চলতে থাকবে।

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.gunjoron.patheyo.notification.IslamicNotificationWorker
import com.gunjoron.patheyo.notification.ScheduledNotificationScheduler
import com.gunjoron.patheyo.widget.WidgetRefreshScheduler
import com.gunjoron.patheyo.widget.WidgetUpdateWorker
import java.util.concurrent.TimeUnit

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {

            // ✅ FIX #NEW (v4): প্রতিটি ধাপ আলাদা try-catch(Throwable) দিয়ে সুরক্ষিত করা হলো,
            // এবং widget-রিফ্রেশ সংক্রান্ত ধাপগুলো সবার আগে আনা হলো। আগে একটা ধাপ (যেমন আজান
            // অ্যালার্ম শিডিউল করা) ব্যর্থ হলে এর পরের সব ধাপ (widget alarm reschedule সহ)
            // বাদ পড়ে যেত — মানে রিবুটের পর widget আর কখনো আপডেট হতো না, যতক্ষণ না অ্যাপ
            // ম্যানুয়ালি খোলা হয়। এখন প্রতিটি ধাপ স্বাধীন, একটা ব্যর্থ হলেও বাকিগুলো ঠিকই চলবে।

            // ১) সবচেয়ে গুরুত্বপূর্ণ — widget refresh alarm chain (AlarmManager)
            try { WidgetRefreshScheduler.scheduleAll(context) } catch (t: Throwable) {}

            // ২) widget-এর WorkManager ব্যাকআপ (AlarmManager চেইন ভেঙে গেলে এটা পুনরায় ঠিক করবে)
            try { WidgetRefreshScheduler.ensureBackupWork(context) } catch (t: Throwable) {}
            // ✅ v24: রিবুটের পর সাথে সাথে পুরো উইজেট রিসেট (তারিখ/হিজরি/ওয়াক্ত ঠিক করে রেন্ডার)
            try { WidgetRefreshScheduler.hardReset(context) } catch (t: Throwable) {}

            // ৩) আজান alarm reschedule
            try { AlarmScheduler.scheduleAllAlarms(context) } catch (t: Throwable) {}

            // ৪) জুমা/নোটিফিকেশন reschedule
            try { ScheduledNotificationScheduler.scheduleAllNotifications(context) } catch (t: Throwable) {}
            // ✅ FIX #NEW: নোটিফিকেশনের Doze-প্রতিরোধী হার্টবিট চেইনও রিবুট-এর পর আবার চালু করা
            try { ScheduledNotificationScheduler.scheduleHeartbeat(context) } catch (t: Throwable) {}

            try {
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    "ibadat_notif_check",
                    ExistingPeriodicWorkPolicy.KEEP,
                    PeriodicWorkRequestBuilder<IslamicNotificationWorker>(1, TimeUnit.HOURS).build()
                )
            } catch (t: Throwable) {}
        }
    }
}
