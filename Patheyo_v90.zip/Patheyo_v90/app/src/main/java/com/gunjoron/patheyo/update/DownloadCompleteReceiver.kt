package com.gunjoron.patheyo.update

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import com.gunjoron.patheyo.R

/** ডাউনলোড শেষ হলে সিস্টেম এটিকে কল করে (অ্যাপ বন্ধ থাকলেও) */
class DownloadCompleteReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return

        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        // অন্য কোনো ডাউনলোড হলে এড়িয়ে যাবে
        if (id == -1L || id != UpdatePrefs.getDownloadId(ctx)) return
        UpdatePrefs.setDownloadId(ctx, -1L)

        if (!UpdateDownloader.isSuccessful(ctx, id) || !UpdateDownloader.apkFile(ctx).exists()) {
            Toast.makeText(ctx, R.string.update_download_failed, Toast.LENGTH_LONG).show()
            return
        }

        val inForeground = ProcessLifecycleOwner.get().lifecycle.currentState
            .isAtLeast(Lifecycle.State.STARTED)

        if (inForeground) {
            // অ্যাপ সামনে আছে → সরাসরি Package Installer খুলবে
            ctx.startActivity(UpdateDownloader.buildInstallIntent(ctx))
        } else {
            // Android 10+ ব্যাকগ্রাউন্ড থেকে Activity চালু করতে দেয় না → নোটিফিকেশনে ট্যাপ করতে হবে
            NotificationHelper.showInstallReady(ctx)
        }
    }
}
