package com.gunjoron.patheyo.alarm

// app/src/main/java/com/gunjoron/patheyo/alarm/AlarmReliability.kt
//
// ✅ v44: সব ফোনে (বিশেষত Honor/Huawei সহ পুরনো OEM ফোনে) আজান বাজার জন্য দরকারি "ব্যাকগ্রাউন্ডে চলতে দেওয়া"
// সেটিংসগুলোর স্ট্যাটাস-চেক ও সেটিংস-স্ক্রিন খোলার এক জায়গার সহায়ক।
//
// মূল সমস্যা (আগে): OEM-এর সেটিংস খোলার আগে `resolveActivity()` দিয়ে চেক করা হতো। অ্যান্ড্রয়েড ১১+ এ
// "package visibility" নিয়মের কারণে অন্য কোম্পানির প্যাকেজ দেখা যায় না, তাই resolveActivity সবসময় null দিত →
// Honor/Huawei/Xiaomi-র সেটিংস স্ক্রিন কখনোই খুলত না। এখন সরাসরি startActivity() চেষ্টা করা হয়
// (ActivityNotFoundException/SecurityException ধরে পরেরটা চেষ্টা) — যেটা ভিজিবিলিটি নিয়মের আওতায় পড়ে না।

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

object AlarmReliability {

    /** ব্র্যান্ডভিত্তিক আগ্রাসী ব্যাকগ্রাউন্ড-ক্লিনার আছে এমন OEM কিনা */
    fun isAggressiveOem(): Boolean = oemFamily() != Oem.OTHER

    enum class Oem { HONOR_HUAWEI, XIAOMI, OPPO_REALME_ONEPLUS, VIVO, TRANSSION, SAMSUNG, ASUS, OTHER }

    fun oemFamily(): Oem {
        val m = (Build.MANUFACTURER ?: "").lowercase()
        val b = (Build.BRAND ?: "").lowercase()
        val all = "$m $b"
        return when {
            all.contains("honor") || all.contains("huawei") -> Oem.HONOR_HUAWEI
            all.contains("xiaomi") || all.contains("redmi") || all.contains("poco") -> Oem.XIAOMI
            all.contains("oppo") || all.contains("realme") || all.contains("oneplus") -> Oem.OPPO_REALME_ONEPLUS
            all.contains("vivo") || all.contains("iqoo") -> Oem.VIVO
            all.contains("tecno") || all.contains("infinix") || all.contains("itel") || all.contains("transsion") -> Oem.TRANSSION
            all.contains("samsung") -> Oem.SAMSUNG
            all.contains("asus") -> Oem.ASUS
            else -> Oem.OTHER
        }
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean = try {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(context.packageName)
    } catch (_: Throwable) { true }

    fun canUseFullScreenIntent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return true
        return try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.canUseFullScreenIntent()
        } catch (_: Throwable) { true }
    }

    /** ব্যাটারি অপ্টিমাইজেশন থেকে বাদ দেওয়ার সরাসরি পপআপ; ব্যর্থ হলে সাধারণ তালিকা-পেজ */
    fun openBatteryOptimization(activity: Activity) {
        try {
            activity.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${activity.packageName}")
            })
        } catch (_: Throwable) {
            try { activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (_: Throwable) { openAppDetails(activity) }
        }
    }

    fun openExactAlarmSettings(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
                return
            } catch (_: Throwable) { }
        }
        openAppDetails(activity)
    }

    fun openFullScreenIntentSettings(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply {
                    data = Uri.parse("package:${activity.packageName}")
                })
                return
            } catch (_: Throwable) { }
        }
        openAppDetails(activity)
    }

    // ───────────── v48: আজানের পপআপ আসার জন্য দরকারি সেটিংস ─────────────

    /**
     * Xiaomi/Redmi/Poco (MIUI/HyperOS): "লক স্ক্রিনে দেখানো" (op 10020) ও "ব্যাকগ্রাউন্ড থেকে পপআপ" (op 10021) চালু আছে কিনা।
     * @return true = দুটোই চালু, false = অন্তত একটা বন্ধ, null = জানা গেল না (অন্য ব্র্যান্ড / পড়া যায়নি)
     */
    fun xiaomiPopupAllowed(context: Context): Boolean? {
        if (oemFamily() != Oem.XIAOMI) return null
        return try {
            val ops = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val m = android.app.AppOpsManager::class.java.getMethod(
                "checkOpNoThrow", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, String::class.java
            )
            val uid = android.os.Process.myUid()
            val lockScreen = m.invoke(ops, 10020, uid, context.packageName) as Int
            val bgPopup = m.invoke(ops, 10021, uid, context.packageName) as Int
            lockScreen == android.app.AppOpsManager.MODE_ALLOWED && bgPopup == android.app.AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) { null }
    }

    /** "লক স্ক্রিনে দেখানো" / "ব্যাকগ্রাউন্ড পপআপ" অনুমতির পেজ — Xiaomi-তে সরাসরি, বাকিতে অ্যাপের পারমিশন/ইনফো পেজ */
    fun openPopupPermissionSettings(activity: Activity) {
        if (oemFamily() == Oem.XIAOMI) {
            val targets = listOf(
                "com.miui.permcenter.permissions.PermissionsEditorActivity",
                "com.miui.permcenter.permissions.AppPermissionsEditorActivity"
            )
            for (cls in targets) {
                try {
                    activity.startActivity(Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                        setClassName("com.miui.securitycenter", cls)
                        putExtra("extra_pkgname", activity.packageName)
                    })
                    return
                } catch (_: Throwable) { }
            }
        }
        openAppDetails(activity)
    }

    /** "নামাজের আজান" নোটিফিকেশন-চ্যানেলের সেটিংস (গুরুত্ব/লক-স্ক্রিন); নোটিফিকেশন পুরো বন্ধ থাকলে অ্যাপের নোটিফিকেশন-সেটিংস */
    fun openAzanChannelSettings(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val allOn = try { androidx.core.app.NotificationManagerCompat.from(activity).areNotificationsEnabled() } catch (_: Throwable) { true }
            try {
                activity.startActivity(
                    if (allOn) Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                        putExtra(Settings.EXTRA_CHANNEL_ID, AzanChannel.ID)
                    } else Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                    }
                )
                return
            } catch (_: Throwable) { }
        }
        openAppDetails(activity)
    }

    fun openAppDetails(activity: Activity) {
        try {
            activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", activity.packageName, null)))
        } catch (_: Throwable) { }
    }

    private fun c(pkg: String, cls: String) = Intent().setComponent(ComponentName(pkg, cls))

    /**
     * অটো-স্টার্ট / অ্যাপ-লঞ্চ / ব্যাকগ্রাউন্ড-রান সেটিংস। ফোনের ব্র্যান্ড অনুযায়ী আগে ওই ব্র্যান্ডের স্ক্রিন,
     * তারপর বাকিগুলো একটার পর একটা চেষ্টা। কোনোটাই না খুললে false (কল-কারী অ্যাপ-ইনফো পেজে পাঠাবে)।
     * resolveActivity() ইচ্ছাকৃতভাবে ব্যবহার করা হয়নি (ওপরের ব্যাখ্যা দেখুন)।
     */
    fun openOemBackgroundSettings(activity: Activity): Boolean {
        val honorHuawei = listOf(
            // Honor (MagicOS) — নিজস্ব hihonor প্যাকেজ
            c("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            c("com.hihonor.systemmanager", "com.hihonor.systemmanager.power.ui.HwPowerManagerActivity"),
            c("com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.process.ProtectActivity"),
            c("com.hihonor.systemmanager", "com.hihonor.systemmanager.appmanager.ui.AppManagerActivity"),
            // Huawei / পুরনো Honor (EMUI)
            c("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            c("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"),
            c("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            c("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")
        )
        val xiaomi = listOf(
            c("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            c("com.miui.securitycenter", "com.miui.powercenter.PowerSettings")
        )
        val oppo = listOf(
            c("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            c("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            c("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            c("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")
        )
        val vivo = listOf(
            c("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            c("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
            c("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
            c("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"),
            c("com.iqoo.secure", "com.iqoo.secure.safeguard.PurviewTabActivity")
        )
        val transsion = listOf(
            c("com.transsion.phonemanager", "com.itel.autobootmanager.activity.AutoBootMgrActivity"),
            c("com.transsion.phonemanager", "com.transsion.phonemanager.ui.PhoneManagerMainActivity")
        )
        val others = listOf(
            c("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
            c("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"),
            c("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"),
            c("com.meizu.safe", "com.meizu.safe.permission.PermissionMainActivity"),
            c("com.lenovo.security", "com.lenovo.security.purebackground.PureBackgroundActivity"),
            c("com.motorola.blur.batterysaver", "com.motorola.blur.batterysaver.BatteryDashboardActivity")
        )

        val ordered = when (oemFamily()) {
            Oem.HONOR_HUAWEI -> honorHuawei + xiaomi + oppo + vivo + transsion + others
            Oem.XIAOMI -> xiaomi + honorHuawei + oppo + vivo + transsion + others
            Oem.OPPO_REALME_ONEPLUS -> oppo + honorHuawei + xiaomi + vivo + transsion + others
            Oem.VIVO -> vivo + honorHuawei + xiaomi + oppo + transsion + others
            Oem.TRANSSION -> transsion + honorHuawei + xiaomi + oppo + vivo + others
            else -> others + honorHuawei + xiaomi + oppo + vivo + transsion
        }
        for (i in ordered) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(i)
                return true
            } catch (_: Throwable) { /* পরের অপশন */ }
        }
        return false
    }
}
