package com.gunjoron.patheyo.update

/**
 * আপডেটের তথ্য (update.json / ওয়েবসাইটের রিলিজ ফাইল / FCM পুশ — যেকোনো সূত্র থেকে)।
 *
 * v49: [codeKnown] = false মানে সূত্রে আসল versionCode নেই (যেমন GitHub Release থেকে বানানো ফাইল);
 * তখন ইনস্টল করা অ্যাপের সাথে versionName (যেমন 1.6.0) মিলিয়ে নতুন কি না ঠিক করা হয়।
 */
data class UpdateInfo(
    val versionCode: Long,
    val versionName: String,
    val apkUrl: String,
    val releaseNotes: String,
    val sizeMb: Int,
    val mandatory: Boolean,
    val codeKnown: Boolean = true
)
