package com.gunjoron.patheyo.update

import android.content.Context
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/** অ্যাপ বন্ধ থাকলেও ব্যাকগ্রাউন্ডে নিয়মিত আপডেট চেক করে নোটিফিকেশন দেয় */
class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val info = UpdateChecker.checkForUpdate(applicationContext) ?: return Result.success()

        // অ্যাপ এখন সামনে খোলা থাকলে নোটিফিকেশন লাগবে না (ডায়ালগ নিজেই দেখাবে)
        val inForeground = withContext(Dispatchers.Main) {
            ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        if (inForeground) return Result.success()

        if (UpdatePrefs.shouldPrompt(applicationContext, info) &&
            NotificationHelper.showUpdateAvailable(applicationContext, info)
        ) {
            UpdatePrefs.markPrompted(applicationContext, info)
            UpdatePrefs.setNotificationPending(applicationContext, true)
        }
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "patheyo_update_check"

        /** Application.onCreate()-এ একবার কল করুন */
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(6, TimeUnit.HOURS) // ✏️ কত ঘণ্টা পরপর চেক
                .setConstraints(
                    Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                )
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
