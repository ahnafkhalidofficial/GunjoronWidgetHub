import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.services)
}

// ✅ ইন-অ্যাপ আপডেট: keystore.properties থেকে সাইনিং তথ্য পড়া (ফাইলটি GitHub-এ আপলোড করবেন না)
val keystoreProps = Properties()
val keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) keystoreProps.load(FileInputStream(keystoreFile))

android {
    namespace = "com.gunjoron.patheyo"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.gunjoron.patheyo"
        minSdk = 24
        targetSdk = 37
        versionCode = 6
        versionName = "1.6.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // ✅ ইন-অ্যাপ আপডেট: সাইনিং কনফিগ
    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                storeFile = file(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")   // ✅ ইন-অ্যাপ আপডেট
            isMinifyEnabled = false
        }
    }

    @Suppress("DEPRECATION")
    aaptOptions {
        noCompress("mp3")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("com.google.firebase:firebase-config-ktx:21.6.3")
    // ✅ নতুন: FCM push (অ্যাপ বন্ধ থাকলেও আরবি তারিখ আপডেট করতে)
    implementation("com.google.firebase:firebase-messaging-ktx:24.1.0")
    // ✅ নতুন: Realtime Database (রিয়েল-টাইম push-based sync)
    implementation("com.google.firebase:firebase-database-ktx:21.0.0")
    
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    // ✅ ইন-অ্যাপ আপডেট: lifecycleScope ও ProcessLifecycleOwner-এর জন্য
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("com.google.android.material:material:1.11.0")
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}
