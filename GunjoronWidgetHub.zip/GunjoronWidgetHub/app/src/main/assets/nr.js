/*
 * nr.js — হাবের (hub.html) প্রিভিউ-ইঞ্জিন দিয়ে উইজেটের ছবি আঁকার স্ক্রিপ্ট।
 * হাবের নিজের কোড (WD_DESIGNS, liveTick, livePillApply, তারিখ-লেআউট…) হুবহু ব্যবহার হয়,
 * তাই ছবি প্রিভিউয়ের সাথে একই হয়। শুধু যে লেখাগুলো ফোনের ঘড়ি নিজে চালাবে
 * (ঘণ্টা, মিনিট, সেকেন্ড, টাইমার) সেগুলো ছবি থেকে সরিয়ে তাদের জায়গা মেপে নেটিভকে জানানো হয়।
 */
(function () {
    'use strict';
    if (window.__nrRender) return;

    // হাবের নিজের প্রতি-সেকেন্ডের আপডেট বন্ধ; আমরা নিজে একবার ডাকব
    var origTick = window.liveTick;
    window.liveTick = function () {};

    function ensureStyle() {
        if (document.getElementById('nr-style')) return;
        var st = document.createElement('style');
        st.id = 'nr-style';
        st.textContent =
            'html,body{background:transparent!important;margin:0!important;padding:0!important;overflow:hidden!important}' +
            'body>*:not(svg[width="0"]):not(#nr-root){display:none!important}' +
            '#nr-root{position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:2147483647;background:transparent}' +
            '#nr-root #wd-preview-wrap{position:absolute;left:0;top:0;width:100%;height:100%;display:block}' +
            '#nr-root .wd-frame-svg{position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible}';
        document.head.appendChild(st);
    }

    function whenLiveReady(cb, tries) {
        var ready = false;
        try { ready = !!(LIVE_NODES && LIVE_NODES.sec && LIVE_NODES.sec.length); } catch (e) { ready = false; }
        if (ready) return cb();
        if (tries <= 0) {
            try { liveInit(); } catch (e) {}
            return cb();
        }
        setTimeout(function () { whenLiveReady(cb, tries - 1); }, 100);
    }

    function loadFonts() {
        var loads = [];
        try {
            if (document.fonts && document.fonts.load) {
                ['40px "Bebas Neue"', '700 60px Gunjoron', '400 50px Gunjoron', '100px ClockSerif'].forEach(function (f) {
                    loads.push(document.fonts.load(f, '0123456789\u0986').catch(function () { return null; }));
                });
            }
        } catch (e) {}
        return Promise.all(loads);
    }

    // টেক্সটের n-তম অক্ষরের শুরুর বিন্দু (বেসলাইন), শিটের স্থানাঙ্কে
    function charInfo(el, idx) {
        var s = el.getStartPositionOfChar(idx);
        var m = el.getCTM();
        var p = new DOMPoint(s.x, s.y);
        if (m) p = p.matrixTransform(m);
        var cs = getComputedStyle(el);
        var k = m ? Math.sqrt(m.a * m.a + m.b * m.b) : 1;
        return { x: p.x, y: p.y, fs: parseFloat(cs.fontSize) * k, color: cs.fill };
    }

    function inCard(p, c) {
        return p.x >= c.x - 2 && p.x <= c.x + c.w + 2 && p.y >= c.y - 2 && p.y <= c.y + c.h + 2;
    }

    function run(cfg) {
        ensureStyle();

        var root = document.getElementById('nr-root');
        if (!root) {
            var wrap0 = document.getElementById('wd-preview-wrap');
            if (!wrap0) throw new Error('wd-preview-wrap পাওয়া যায়নি');
            root = document.createElement('div');
            root.id = 'nr-root';
            document.body.appendChild(root);
            root.appendChild(wrap0);
        }

        // অবস্থান ও থিম — হাবের গ্লোবাল স্টেটে বসানো
        liveLoc = { lat: cfg.lat, lng: cfg.lng };
        liveTimelineKey = null;
        var th = cfg.theme;
        if (th === 'nobg_light') { activeWidgetTheme = 'nobg'; activeNobgMode = 'light'; }
        else if (th === 'nobg') { activeWidgetTheme = 'nobg'; activeNobgMode = 'dark'; }
        else if (th === 'light' || th === 'custom' || th === 'glass') { activeWidgetTheme = th; }
        else { activeWidgetTheme = 'glass'; }
        wdCustomOpacity = cfg.customOpacity;
        wdCustomTone = cfg.customTone;
        wcSetFromHex(cfg.customBg);
        activeWidgetDesign = cfg.design;

        // উইজেটে কার্ডের চারপাশে ফাঁকা জায়গা কম (প্রিভিউয়ে ৬০ ইউনিট ছিল)
        var M = cfg.margin;
        window.wdCardGeom = function (d, v) {
            var c = WD_DESIGNS[d].cards[v];
            return { c: c, vx: c.x - M, vy: c.y - M, vw: c.w + 2 * M, vh: c.h + 2 * M };
        };

        whenLiveReady(function () {
            loadFonts().then(function () {
                try { go(cfg); } catch (e) { NR.fail(String((e && e.stack) || e)); }
            });
        }, 40);
    }

    function go(cfg) {
        var v = wdVariantKey();
        wdBuildPreviewWrap(cfg.design, v);
        if (WD_COPY_MODE) wdFillCopies();

        origTick(); // সব লেখা এখনকার সময় অনুযায়ী

        var now = new Date();
        var tl = liveGetTimeline(now);
        var i = 0;
        while (i < tl.length - 2 && now >= tl[i + 1].t) i++;
        var cur = tl[i], nxt = tl[i + 1];

        var g = wdCardGeom(cfg.design, v);
        var c = g.c;

        // যেগুলো ফোনের ঘড়ি নিজে চালাবে: জায়গা মেপে ছবির লেখা সরানো
        var out = [];
        var seen = {};
        // শট মোডে (প্রিভিউয়ের স্ক্রিনশট) সব লেখা ছবিতেই থাকে, কিছু সরানো হয় না
        (cfg.shot ? [] : ['hr', 'min', 'sec', 'cnt', 'cntRem']).forEach(function (role) {
            (LIVE_NODES[role] || []).forEach(function (el) {
                if (seen[role]) return;
                var text = el.textContent || '';
                if (!text.length) return;
                var p0;
                try { p0 = charInfo(el, 0); } catch (e) { return; }
                if (!inCard(p0, c)) return;
                var o = { role: role, x: p0.x, y: p0.y, fs: p0.fs, color: p0.color };
                if (role === 'cnt' || role === 'cntRem') {
                    // "HH:MM:SS" — ঘণ্টা ও কোলন ছবিতে থাকবে; "MM:SS" ঘড়ি চালাবে
                    var q;
                    try { q = charInfo(el, 3); } catch (e) { return; }
                    o.x = q.x; o.y = q.y;
                    el.textContent = text.slice(0, 3);
                } else {
                    el.textContent = '';
                }
                seen[role] = true;
                out.push(o);
            });
        });

        var res = {
            vx: g.vx, vy: g.vy, vw: g.vw, vh: g.vh,
            nowMs: now.getTime(),
            curStartMs: cur.t.getTime(),
            nextStartMs: nxt.t.getTime(),
            overlays: out
        };
        setTimeout(function () { NR.done(JSON.stringify(res)); }, 120);
    }

    window.__nrRender = function (cfg) {
        try { run(cfg); } catch (e) { NR.fail(String((e && e.stack) || e)); }
    };
})();
