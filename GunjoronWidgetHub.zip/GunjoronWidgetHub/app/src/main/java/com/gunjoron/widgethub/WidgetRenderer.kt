package com.gunjoron.widgethub

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/**
 * লুকানো WebView-তে হাবের (hub.html) প্রিভিউ-ইঞ্জিন চালিয়ে উইজেটের ছবি তোলে।
 * সব কাজ মেইন থ্রেডে; একসাথে একটাই কাজ চলে, বাকিগুলো সারিতে থাকে।
 */
class WidgetRenderer(context: Context) {

    class Req(
        val design: Int,
        val bmpW: Int,
        val bmpH: Int,
        val margin: Double,
        val settings: WidgetPrefs.Settings,
        val lat: Double,
        val lng: Double
    )

    /** ফোনের ঘড়ি যে লেখা নিজে চালাবে তার জায়গা (শিটের স্থানাঙ্কে, বেসলাইনসহ)। */
    class Overlay(val role: String, val x: Double, val y: Double, val fs: Double, val color: Int)

    class Result(
        val bitmap: Bitmap,
        val vx: Double, val vy: Double, val vw: Double, val vh: Double,
        val overlays: List<Overlay>,
        val curStartMs: Long,
        val nextStartMs: Long,
        val nowMs: Long
    )

    private class Job(val req: Req, val cb: (Result?) -> Unit)

    private val appCtx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Job>()
    private var current: Job? = null
    private var web: WebView? = null
    private var pageReady = false
    private var timeout: Runnable? = null
    private var dispose: Runnable? = null

    private val nrJs: String by lazy {
        appCtx.assets.open("nr.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    /** মেইন থ্রেড থেকে ডাকতে হবে। */
    fun render(req: Req, cb: (Result?) -> Unit) {
        dispose?.let { main.removeCallbacks(it) }
        dispose = null
        queue.addLast(Job(req, cb))
        ensureWeb()
        pump()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWeb() {
        if (web != null) return
        val w = WebView(appCtx)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        s.textZoom = 100
        s.useWideViewPort = false
        s.loadWithOverviewMode = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        w.addJavascriptInterface(NrBridge(this), "NR")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (pageReady) return
                view.evaluateJavascript(nrJs, null)
                pageReady = true
                pump()
            }
        }
        web = w
        pageReady = false
        w.loadUrl("file:///android_asset/hub.html#nr") // #nr: হাবের অ্যানিমেশন বন্ধ, শুধু ছবি আঁকার জন্য
    }

    private fun pump() {
        val w = web ?: return
        if (!pageReady || current != null) return
        val job = queue.removeFirstOrNull()
        if (job == null) {
            scheduleDispose()
            return
        }
        current = job
        val r = job.req

        w.measure(
            View.MeasureSpec.makeMeasureSpec(r.bmpW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(r.bmpH, View.MeasureSpec.EXACTLY)
        )
        w.layout(0, 0, r.bmpW, r.bmpH)

        val cfg = JSONObject()
        cfg.put("design", r.design)
        cfg.put("theme", r.settings.theme)
        cfg.put("customBg", r.settings.customBg)
        cfg.put("customOpacity", r.settings.customOpacity)
        cfg.put("customTone", r.settings.customTone)
        cfg.put("margin", r.margin)
        cfg.put("lat", r.lat)
        cfg.put("lng", r.lng)

        val t = Runnable { finish(null) }
        timeout = t
        main.postDelayed(t, JOB_TIMEOUT_MS)

        w.evaluateJavascript("window.__nrRender(" + cfg.toString() + ")", null)
    }

    // ---- NrBridge থেকে (মেইন থ্রেডে) ----
    internal fun postDone(json: String) {
        main.post {
            val job = current ?: return@post
            // লেআউট ও পেইন্ট থিতু হওয়ার জন্য অল্প অপেক্ষা
            main.postDelayed({ capture(job, json) }, SETTLE_MS)
        }
    }

    internal fun postFail(msg: String?) {
        main.post { finish(null) }
    }

    private fun capture(job: Job, json: String) {
        if (current !== job) return
        try {
            val o = JSONObject(json)
            val arr = o.getJSONArray("overlays")
            val list = ArrayList<Overlay>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                list.add(
                    Overlay(
                        e.getString("role"),
                        e.getDouble("x"), e.getDouble("y"), e.getDouble("fs"),
                        parseCssColor(e.optString("color", "rgb(255,255,255)"))
                    )
                )
            }
            val bmp = Bitmap.createBitmap(job.req.bmpW, job.req.bmpH, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.TRANSPARENT)
            web?.draw(Canvas(bmp))
            finish(
                Result(
                    bmp,
                    o.getDouble("vx"), o.getDouble("vy"), o.getDouble("vw"), o.getDouble("vh"),
                    list,
                    o.getLong("curStartMs"), o.getLong("nextStartMs"), o.getLong("nowMs")
                )
            )
        } catch (e: Throwable) {
            finish(null)
        }
    }

    private fun finish(res: Result?) {
        timeout?.let { main.removeCallbacks(it) }
        timeout = null
        val job = current ?: return
        current = null
        try {
            job.cb(res)
        } catch (e: Throwable) {
            // একটা উইজেটের ভুল বাকিগুলো আটকাবে না
        }
        pump()
    }

    private fun scheduleDispose() {
        if (dispose != null) return
        val d = Runnable {
            dispose = null
            if (current == null && queue.isEmpty()) {
                web?.destroy()
                web = null
                pageReady = false
            }
        }
        dispose = d
        main.postDelayed(d, IDLE_DISPOSE_MS)
    }

    private fun parseCssColor(s: String): Int {
        val nums = Regex("[0-9.]+").findAll(s).map { it.value.toDouble() }.toList()
        if (nums.size < 3) return Color.WHITE
        val a = if (nums.size >= 4) (nums[3] * 255).toInt() else 255
        return Color.argb(
            a.coerceIn(0, 255),
            nums[0].toInt().coerceIn(0, 255),
            nums[1].toInt().coerceIn(0, 255),
            nums[2].toInt().coerceIn(0, 255)
        )
    }

    companion object {
        private const val JOB_TIMEOUT_MS = 8000L
        private const val SETTLE_MS = 250L
        private const val IDLE_DISPOSE_MS = 20000L
    }
}

/** WebView-র JavaScript থেকে ডাকা হয় (window.NR)। আলাদা পাবলিক ক্লাস, যাতে রিফ্লেকশনে সমস্যা না হয়। */
class NrBridge(private val renderer: WidgetRenderer) {
    @JavascriptInterface
    fun done(json: String) {
        renderer.postDone(json)
    }

    @JavascriptInterface
    fun fail(msg: String?) {
        renderer.postFail(msg)
    }
}
