package com.gunjoron.widgethub

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * সব উইজেট নতুন করে আঁকার কেন্দ্র।
 *  - প্রতিটা উইজেটের ছবি WidgetRenderer থেকে নেওয়া হয় (হাবের প্রিভিউয়ের হুবহু)।
 *  - ঘণ্টা/মিনিট/সেকেন্ড ও টাইমার ফোনের ঘড়ির TextClock/Chronometer চালায়।
 *  - পরের ঘটনার (ওয়াক্ত বদল, ঘণ্টার সীমা, মধ্যরাত, দুপুর) সময়ে অ্যালার্ম বসে।
 */
object WidgetUpdater {

    private const val HOUR_MS = 3_600_000L
    private const val MAX_BMP_W = 1000.0

    private val main = Handler(Looper.getMainLooper())
    private var renderer: WidgetRenderer? = null
    private var running = false
    private var dirty = false
    private val waiters = ArrayList<() -> Unit>()

    private class Job(
        val design: Int,
        val id: Int,
        val areaW: Int,
        val areaH: Int,
        val dispW: Double,
        val dispH: Double,
        val req: WidgetRenderer.Req
    )

    private class Slot(val boxId: Int, val txId: Int, val serif: Boolean)

    /** যেকোনো থ্রেড থেকে ডাকা যায়। একসাথে অনেক অনুরোধ এলে একটা পাসে মিশে যায়। */
    fun request(ctx: Context, done: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        main.post {
            if (done != null) waiters.add(done)
            if (running) {
                dirty = true
            } else {
                running = true
                pass(app)
            }
        }
    }

    /** অ্যাপ চালু থাকার সময় ভারী কাজ এড়াতে কিছুক্ষণ পরে। */
    fun requestDelayed(ctx: Context, delayMs: Long) {
        val app = ctx.applicationContext
        main.postDelayed({ request(app) }, delayMs)
    }

    private fun pass(ctx: Context) {
        dirty = false
        val mgr = AppWidgetManager.getInstance(ctx)
        val settings = WidgetPrefs.load(ctx)
        val loc = WidgetPrefs.location(ctx)

        val jobs = ArrayList<Job>()
        for (design in 1..3) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, Designs.providerClass(design)))
            for (id in ids) jobs.add(makeJob(ctx, mgr, design, id, settings, loc.first, loc.second))
        }
        if (jobs.isEmpty()) {
            cancelAlarm(ctx)
            complete(ctx)
            return
        }

        val r = renderer ?: WidgetRenderer(ctx).also { renderer = it }
        val events = ArrayList<Long>()
        var left = jobs.size
        for (j in jobs) {
            r.render(j.req) { res ->
                if (res != null) {
                    try {
                        apply(ctx, mgr, j, res, events)
                    } catch (e: Throwable) {
                        // একটা উইজেট ব্যর্থ হলে আগের ছবি থেকে যায়
                    }
                }
                left--
                if (left == 0) {
                    scheduleNext(ctx, events)
                    complete(ctx)
                }
            }
        }
    }

    private fun complete(ctx: Context) {
        if (dirty) {
            pass(ctx)
            return
        }
        running = false
        val list = ArrayList(waiters)
        waiters.clear()
        for (w in list) {
            try { w() } catch (e: Throwable) { }
        }
    }

    private fun makeJob(
        ctx: Context, mgr: AppWidgetManager, design: Int, id: Int,
        settings: WidgetPrefs.Settings, lat: Double, lng: Double
    ): Job {
        val spec = Designs.spec(design)
        val density = ctx.resources.displayMetrics.density
        val o = mgr.getAppWidgetOptions(id)
        val portrait = ctx.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
        var wDp = if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        var hDp = if (portrait) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        if (wDp <= 0) wDp = spec.defaultWDp
        if (hDp <= 0) hDp = spec.defaultHDp

        val areaW = max(1, (wDp * density).roundToInt())
        val areaH = max(1, (hDp * density).roundToInt())

        val m = Designs.margin(settings.theme)
        val vw = spec.cardW + 2 * m
        val vh = spec.cardH + 2 * m
        val aspect = vw / vh

        val dispW: Double
        val dispH: Double
        if (areaW.toDouble() / areaH > aspect) {
            dispH = areaH.toDouble()
            dispW = dispH * aspect
        } else {
            dispW = areaW.toDouble()
            dispH = dispW / aspect
        }

        val k = min(1.0, MAX_BMP_W / dispW)
        val bmpW = max(64, (dispW * k).roundToInt())
        val bmpH = max(32, (bmpW / aspect).roundToInt())

        val req = WidgetRenderer.Req(design, bmpW, bmpH, m, settings, lat, lng)
        return Job(design, id, areaW, areaH, dispW, dispH, req)
    }

    private fun slot(design: Int, role: String): Slot? = when (design) {
        1 -> when (role) {
            "hr" -> Slot(R.id.box_hr, R.id.tx_hr, false)
            "min" -> Slot(R.id.box_min, R.id.tx_min, false)
            "sec" -> Slot(R.id.box_sec, R.id.tx_sec, false)
            "cnt" -> Slot(R.id.box_cnt, R.id.tx_cnt, false)
            else -> null
        }
        2 -> if (role == "cnt") Slot(R.id.box_cnt, R.id.tx_cnt, false) else null
        3 -> when (role) {
            "hr" -> Slot(R.id.box_hr, R.id.tx_hr, true)
            "min" -> Slot(R.id.box_min, R.id.tx_min, true)
            "sec" -> Slot(R.id.box_sec, R.id.tx_sec, true)
            "cntRem" -> Slot(R.id.box_rem, R.id.tx_rem, false)
            else -> null
        }
        else -> null
    }

    private fun apply(
        ctx: Context, mgr: AppWidgetManager, j: Job,
        res: WidgetRenderer.Result, events: MutableList<Long>
    ) {
        val rv = RemoteViews(ctx.packageName, Designs.layout(j.design))
        rv.setImageViewBitmap(R.id.bg, res.bitmap)

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, open)

        val scale = j.dispW / res.vw
        val offX = (j.areaW - j.dispW) / 2.0
        val offY = (j.areaH - j.dispH) / 2.0
        val bebas: Typeface = try { ctx.resources.getFont(R.font.bebas_neue) } catch (e: Throwable) { Typeface.DEFAULT }
        val serif: Typeface = try { ctx.resources.getFont(R.font.clock_serif) } catch (e: Throwable) { Typeface.DEFAULT }

        val nowWall = System.currentTimeMillis()
        val nowReal = SystemClock.elapsedRealtime()

        for (o in res.overlays) {
            val s = slot(j.design, o.role) ?: continue
            val px = (o.fs * scale).toFloat()
            val paint = Paint()
            paint.typeface = if (s.serif) serif else bebas
            paint.textSize = px
            val ascent = -paint.fontMetrics.ascent
            val left = (offX + (o.x - res.vx) * scale).roundToInt()
            val top = (offY + (o.y - res.vy) * scale - ascent).roundToInt()

            rv.setViewVisibility(s.boxId, View.VISIBLE)
            rv.setViewPadding(s.boxId, max(0, left), max(0, top), 0, 0)
            rv.setTextViewTextSize(s.txId, TypedValue.COMPLEX_UNIT_PX, px)
            rv.setTextColor(s.txId, o.color)

            when (o.role) {
                "cnt" -> {
                    // ঘণ্টার অংশ ছবিতে; ঘণ্টার ভেতরের মিনিট:সেকেন্ড Chronometer গুনবে
                    val elapsed = nowWall - res.curStartMs
                    val within = ((elapsed % HOUR_MS) + HOUR_MS) % HOUR_MS
                    rv.setChronometer(s.txId, nowReal - within, null, true)
                    events.add(res.curStartMs + (Math.floorDiv(elapsed, HOUR_MS) + 1) * HOUR_MS)
                }
                "cntRem" -> {
                    val rem = res.nextStartMs - nowWall
                    val within = ((rem % HOUR_MS) + HOUR_MS) % HOUR_MS
                    rv.setChronometerCountDown(s.txId, true)
                    rv.setChronometer(s.txId, nowReal + within, null, true)
                    val k = Math.floorDiv(rem, HOUR_MS)
                    var t = res.nextStartMs - k * HOUR_MS
                    if (t < nowWall + 1500) t += HOUR_MS
                    events.add(min(t, res.nextStartMs))
                }
            }
        }

        events.add(res.nextStartMs)
        mgr.updateAppWidget(j.id, rv)
    }

    // ---------- অ্যালার্ম ----------

    private fun alarmIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, RefreshReceiver::class.java).setAction(RefreshReceiver.ACTION_REFRESH)
        return PendingIntent.getBroadcast(ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun cancelAlarm(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(ctx))
    }

    private fun scheduleNext(ctx: Context, events: List<Long>) {
        val now = System.currentTimeMillis()
        val all = ArrayList<Long>(events)

        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_MONTH, 1)
        all.add(c.timeInMillis + 1000)              // মধ্যরাত — তারিখ বদলায়
        c.add(Calendar.HOUR_OF_DAY, 12)
        all.add(c.timeInMillis + 1000)              // দুপুর — AM/PM বদলায়
        c.add(Calendar.DAY_OF_MONTH, -1)
        all.add(c.timeInMillis + 1000)              // আজকের দুপুর
        all.add(now + 30 * 60_000L)                 // নিরাপত্তা: অন্তত প্রতি ৩০ মিনিটে

        var at = Long.MAX_VALUE
        for (t in all) if (t > now + 1500 && t < at) at = t

        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmIntent(ctx)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
