package com.gunjoron.widgethub

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** অ্যালার্ম ও সিস্টেম ঘটনায় (বুট, সময়/তারিখ/টাইমজোন/ভাষা বদল, অ্যাপ আপডেট) উইজেট রিফ্রেশ। */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        WidgetUpdater.request(context) { pending?.finish() }
    }

    companion object {
        const val ACTION_REFRESH = "com.gunjoron.widgethub.REFRESH"
    }
}
