package com.gunjoron.widgethub

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * হাবের JavaScript থেকে ডাকা হয়: window.AndroidWidgetBridge.*
 * হাব যে তিনটি মেথড ডাকে: saveWidgetSettings, pinWidgetToHomeScreen, refreshWidgetNow।
 */
class WidgetBridge(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val syncRunnable = Runnable { WidgetUpdater.request(ctx) }

    @JavascriptInterface
    fun saveWidgetSettings(json: String?) {
        if (json == null) return
        if (WidgetPrefs.saveJson(ctx, json)) {
            // কালার হুইল টানার সময় বারবার আঁকা এড়াতে ০.৮ সেকেন্ড অপেক্ষা
            main.removeCallbacks(syncRunnable)
            main.postDelayed(syncRunnable, 800)
        }
    }

    /** হাবের প্রিভিউ ও ডিজাইনের স্ক্রিনশটের তালিকা (JSON)। */
    @JavascriptInterface
    fun getPreviewShots(): String = try { PreviewShots.json(ctx) } catch (e: Throwable) { "{}" }

    @JavascriptInterface
    fun pinWidgetToHomeScreen() {
        main.post {
            val design = WidgetPrefs.load(ctx).design
            val cls = Designs.providerClass(design)
            val mgr = AppWidgetManager.getInstance(ctx)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(ctx, cls), null, null)
            } else {
                Toast.makeText(ctx, R.string.toast_pin_unsupported, Toast.LENGTH_LONG).show()
            }
        }
    }

    @JavascriptInterface
    fun refreshWidgetNow() {
        main.post {
            Toast.makeText(ctx, R.string.toast_refreshed, Toast.LENGTH_SHORT).show()
            WidgetUpdater.request(ctx)
        }
    }
}
