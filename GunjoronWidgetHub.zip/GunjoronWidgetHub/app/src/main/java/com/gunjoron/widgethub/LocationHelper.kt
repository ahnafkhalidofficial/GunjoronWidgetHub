package com.gunjoron.widgethub

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper

/** নামাজের সময়ের হিসাবের জন্য অবস্থান। অনুমতি না থাকলে ঢাকা। */
object LocationHelper {

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun refresh(ctx: Context) {
        if (!hasPermission(ctx)) return
        val app = ctx.applicationContext
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return

        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        best?.let { store(app, it) }

        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, object : LocationListener {
                    override fun onLocationChanged(location: Location) { store(app, location) }
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            // অবস্থান না পেলে সংরক্ষিত/ডিফল্ট অবস্থানই চলবে
        }
    }

    private fun store(ctx: Context, l: Location) {
        val old = WidgetPrefs.location(ctx)
        WidgetPrefs.saveLocation(ctx, l.latitude, l.longitude)
        // প্রায় ৫ কিমি-র বেশি সরলে নামাজের সময় বদলায় — উইজেট নতুন করে আঁকা হবে
        val dLat = Math.abs(old.first - l.latitude)
        val dLng = Math.abs(old.second - l.longitude)
        if (dLat > 0.05 || dLng > 0.05) WidgetUpdater.requestDelayed(ctx, 8000)
    }
}
