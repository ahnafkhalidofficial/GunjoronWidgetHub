package com.gunjoron.widgethub

import android.appwidget.AppWidgetProvider

/** তিনটি ডিজাইনের মাপ ও সংযোগ। কার্ডের মাপ হাবের WD_DESIGNS থেকে নেওয়া। */
object Designs {
    class Spec(
        val cardW: Double,
        val cardH: Double,
        val defaultWDp: Int,   // লঞ্চার মাপ না জানালে ধরে নেওয়া
        val defaultHDp: Int
    )

    private val specs = mapOf(
        1 to Spec(1114.25, 608.16, 250, 137),
        2 to Spec(1114.25, 445.15, 250, 100),
        3 to Spec(981.41, 465.35, 250, 118)
    )

    fun spec(design: Int): Spec = specs[design] ?: specs.getValue(1)

    fun providerClass(design: Int): Class<out AppWidgetProvider> = when (design) {
        2 -> Widget2Provider::class.java
        3 -> Widget3Provider::class.java
        else -> Widget1Provider::class.java
    }

    fun layout(design: Int): Int = when (design) {
        2 -> R.layout.widget_d2
        3 -> R.layout.widget_d3
        else -> R.layout.widget_d1
    }

    /** কাস্টম রঙের প্যানেল কার্ডের চেয়ে ২৩ ইউনিট বড় (হাবের WD_BG_PAD); অন্যগুলোয় সামান্য ফাঁক। */
    fun margin(theme: String): Double = if (theme == "custom") 23.0 else 3.0
}
