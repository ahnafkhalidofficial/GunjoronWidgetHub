package com.gunjoron.widgethub

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * হাবের প্রিভিউ ও ডিজাইনের স্ক্রিনশট: ৩ ডিজাইন × ৪ ভেরিয়েন্ট = ১২টি PNG।
 * রোজ রাত ১২টায় (আর অবস্থান বদলালে) নতুন করে তৈরি হয়; হাব শুধু ছবি দেখায়, ভারী SVG আঁকে না।
 * কাস্টম রঙ: ট্রান্সপারেন্ট ভেরিয়েন্টের ছবির পেছনে হাব নিজেই রঙের প্যানেল বসায়।
 */
object PreviewShots {
    private const val SHOT_W = 840
    private const val MARGIN = 60.0          // হাবের WD_MARGIN-এর সমান — ফ্রেমের হিসাব মেলে
    private const val PAUSE_MS = 150L        // দুই ছবির মাঝে অ্যাপকে দম নেওয়ার সুযোগ
    private val VARIANTS = listOf("glass", "light", "nobgDark", "nobgLight")
    private val THEME_FOR = mapOf(
        "glass" to "glass", "light" to "light", "nobgDark" to "nobg", "nobgLight" to "nobg_light"
    )

    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private var running = false

    /** হাবে নতুন তালিকা পাঠানোর কলব্যাক (মেইন থ্রেডে ডাকা হয়)। */
    @Volatile
    var listener: ((String) -> Unit)? = null

    private fun dir(ctx: Context): File = File(ctx.filesDir, "previews").apply { mkdirs() }

    private fun tagNow(ctx: Context): String {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val loc = WidgetPrefs.location(ctx)
        return day + "_" + Math.round(loc.first * 10) + "_" + Math.round(loc.second * 10)
    }

    private fun fileName(design: Int, variant: String, tag: String) = "d${design}_${variant}_$tag.png"

    private fun readDone(ctx: Context): String = try {
        File(dir(ctx), "done.txt").readText().trim()
    } catch (e: Exception) {
        ""
    }

    private fun allExist(ctx: Context, tag: String): Boolean {
        val d = dir(ctx)
        for (design in 1..3) for (v in VARIANTS) if (!File(d, fileName(design, v, tag)).exists()) return false
        return true
    }

    /** হাবের জন্য তালিকা: আজকের ছবি থাকলে সেটা, না থাকলে আগের সম্পূর্ণ সেট। */
    fun json(ctx: Context): String {
        val d = dir(ctx)
        val tags = listOf(tagNow(ctx), readDone(ctx)).filter { it.isNotEmpty() }
        val files = JSONObject()
        for (design in 1..3) for (v in VARIANTS) {
            val f = tags.map { File(d, fileName(design, v, it)) }.firstOrNull { it.exists() }
            if (f != null) files.put("$design-$v", Uri.fromFile(f).toString())
        }
        return JSONObject().put("files", files).toString()
    }

    /** আজকের স্ক্রিনশট না থাকলে তৈরি করে। যেকোনো থ্রেড থেকে ডাকা যায়। */
    fun ensure(ctx: Context) {
        val app = ctx.applicationContext
        main.post {
            if (running) return@post
            val want = tagNow(app)
            if (readDone(app) == want && allExist(app, want)) return@post
            running = true

            // বর্তমান থিমের ভেরিয়েন্ট আগে, যাতে প্রিভিউ সবচেয়ে আগে আসে
            val first = when (WidgetPrefs.load(app).theme) {
                "light" -> "light"
                "nobg_light" -> "nobgLight"
                "glass" -> "glass"
                else -> "nobgDark"
            }
            val order = listOf(first) + VARIANTS.filter { it != first }
            val steps = ArrayList<Pair<Int, String>>()
            for (v in order) for (design in 1..3) steps.add(Pair(design, v))
            runStep(app, want, steps, 0, 0)
        }
    }

    private fun runStep(app: Context, want: String, steps: List<Pair<Int, String>>, i: Int, okCount: Int) {
        if (i >= steps.size) {
            finish(app, want, okCount == steps.size)
            return
        }
        val design = steps[i].first
        val variant = steps[i].second
        val spec = Designs.spec(design)
        val aspect = (spec.cardW + 2 * MARGIN) / (spec.cardH + 2 * MARGIN)
        val bmpH = Math.round(SHOT_W / aspect).toInt()
        val loc = WidgetPrefs.location(app)
        val st = WidgetPrefs.Settings(THEME_FOR.getValue(variant), design, "#1E293B", 90, "auto")
        val req = WidgetRenderer.Req(design, SHOT_W, bmpH, MARGIN, st, loc.first, loc.second, true)

        WidgetUpdater.sharedRenderer(app).render(req) { res ->
            if (res == null) {
                main.postDelayed({ runStep(app, want, steps, i + 1, okCount) }, PAUSE_MS)
            } else {
                val bmp = res.bitmap
                io.execute {
                    val ok = save(app, bmp, fileName(design, variant, want))
                    bmp.recycle()
                    main.post {
                        if (i == 2) notifyHub(app) // বর্তমান ভেরিয়েন্টের ৩ ডিজাইন তৈরি — হাবে সাথে সাথে দেখানো
                        main.postDelayed(
                            { runStep(app, want, steps, i + 1, okCount + if (ok) 1 else 0) }, PAUSE_MS
                        )
                    }
                }
            }
        }
    }

    private fun save(app: Context, bmp: Bitmap, name: String): Boolean = try {
        val d = dir(app)
        val tmp = File(d, "$name.tmp")
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        tmp.renameTo(File(d, name))
    } catch (e: Throwable) {
        false
    }

    private fun finish(app: Context, want: String, ok: Boolean) {
        running = false
        if (ok) {
            try {
                File(dir(app), "done.txt").writeText(want)
                // পুরনো দিনের ছবি মুছে ফেলা
                dir(app).listFiles()?.forEach { f ->
                    if (f.name != "done.txt" && !f.name.endsWith("_$want.png")) f.delete()
                }
            } catch (e: Throwable) {
            }
        }
        notifyHub(app)
    }

    private fun notifyHub(app: Context) {
        val l = listener ?: return
        try {
            l(json(app))
        } catch (e: Throwable) {
        }
    }
}
