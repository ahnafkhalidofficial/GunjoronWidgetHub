package com.gunjoron.widgethub

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle

/** তিন ডিজাইনের উইজেটের সাধারণ আচরণ: যেকোনো ঘটনায় সব উইজেট নতুন করে আঁকা। */
open class BaseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        WidgetUpdater.request(context) { pending?.finish() }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        val pending = goAsync()
        WidgetUpdater.request(context) { pending?.finish() }
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.request(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        WidgetUpdater.request(context)
    }
}

class Widget1Provider : BaseWidgetProvider()
class Widget2Provider : BaseWidgetProvider()
class Widget3Provider : BaseWidgetProvider()
