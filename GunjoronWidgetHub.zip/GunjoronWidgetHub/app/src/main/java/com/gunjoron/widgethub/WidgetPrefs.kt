package com.gunjoron.widgethub

import android.content.Context
import org.json.JSONObject

/** হাব থেকে আসা সেটিংস ও অবস্থান সংরক্ষণ। */
object WidgetPrefs {
    private const val FILE = "widget_hub"
    private const val KEY_SETTINGS = "settings"
    private const val KEY_LAT = "lat"
    private const val KEY_LNG = "lng"

    // ঢাকা — অবস্থান না পেলে এটাই ধরা হয় (হাবের LIVE_DEFAULT_LOC-এর মতো)
    const val DEFAULT_LAT = 23.8103
    const val DEFAULT_LNG = 90.4125

    class Settings(
        val theme: String,        // glass | light | nobg | nobg_light | custom
        val design: Int,          // 1..3
        val customBg: String,     // #RRGGBB
        val customOpacity: Int,   // 10..100
        val customTone: String    // auto | dark | light
    )

    private val THEMES = setOf("glass", "light", "nobg", "nobg_light", "custom")
    private val TONES = setOf("auto", "dark", "light")
    private val HEX = Regex("^#[0-9A-Fa-f]{6}$")

    fun defaults() = Settings("glass", 1, "#1E293B", 90, "auto")

    fun load(ctx: Context): Settings {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_SETTINGS, null)
        return if (raw == null) defaults() else parse(raw) ?: defaults()
    }

    /** হাবের saveWidgetSettings(json) থেকে। সফল হলে true। */
    fun saveJson(ctx: Context, json: String): Boolean {
        val s = parse(json) ?: return false
        val o = JSONObject()
        o.put("theme", s.theme)
        o.put("design", s.design)
        o.put("customBg", s.customBg)
        o.put("customOpacity", s.customOpacity)
        o.put("customTone", s.customTone)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_SETTINGS, o.toString()).apply()
        return true
    }

    private fun parse(json: String): Settings? {
        return try {
            val o = JSONObject(json)
            val d = defaults()
            val theme = o.optString("theme", d.theme).let { if (it in THEMES) it else d.theme }
            val design = o.optInt("design", d.design).let { if (it in 1..3) it else d.design }
            val bg = o.optString("customBg", d.customBg).let { if (HEX.matches(it)) it.uppercase() else d.customBg }
            val op = o.optInt("customOpacity", d.customOpacity).let { if (it in 10..100) it else d.customOpacity }
            val tone = o.optString("customTone", d.customTone).let { if (it in TONES) it else d.customTone }
            Settings(theme, design, bg, op, tone)
        } catch (e: Exception) {
            null
        }
    }

    fun saveLocation(ctx: Context, lat: Double, lng: Double) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_LAT, lat.toString())
            .putString(KEY_LNG, lng.toString())
            .apply()
    }

    fun location(ctx: Context): Pair<Double, Double> {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val lat = sp.getString(KEY_LAT, null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lng = sp.getString(KEY_LNG, null)?.toDoubleOrNull() ?: DEFAULT_LNG
        return Pair(lat, lng)
    }
}
